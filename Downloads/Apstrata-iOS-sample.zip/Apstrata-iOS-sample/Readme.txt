Readme.txt

Important - you must use the developers workbench to add the places schema and enter your account's auth key and secret to the constants.h file 

Go the docs folder and open the tutorial pdfs for more detailed instructions.


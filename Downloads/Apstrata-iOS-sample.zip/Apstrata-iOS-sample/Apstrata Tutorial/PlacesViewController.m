//
//  PlacesViewController.m
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/25/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//

#import "PlacesViewController.h"
#import "apstrata.h"
#import "Constants.h"
#import "JSON.h"
#import "PlaceCell.h"
#import "AddEditPlaceViewController.h"

@interface PlacesViewController ()

@end

@implementation PlacesViewController

@synthesize tableView, items;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated {
    [self getPlaces];
	[self.tableView reloadData];
	[super viewWillAppear:animated];
}

- (void)viewDidUnload
{
    [self setTableView:nil];
	[super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)dealloc {
    [tableView release];
    [super dealloc];
}


-(void) getPlaces {
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *files = [[NSMutableDictionary alloc] init];
    
    ApstrataiPhoneClient *client = [[ApstrataiPhoneClient alloc] initWithURL: URL key: AUTHKey secret: SECRET authMode: SIMPLE];
    
    NSString* methodName = @"Query";
    [parameters setObject:@"apsdb.schema = \"place\""  forKey: @"apsdb.query"];
    [parameters setObject:@"place_title<String:ASC>" forKey:@"apsdb.sort"];
    [parameters setObject:@"place_title, place_address1, place_city, place_state, place_zip" forKey: @"apsdb.queryFields"];
    
    NSString *jsonString = [client callAPIJson: (NSString *)methodName params:parameters files: files];
    
    SBJSON *parser = [[SBJSON alloc] init];
    NSDictionary *results = [parser objectWithString:jsonString error:nil];
    
    NSDictionary *responseDict = [results objectForKey:@"response"];
    NSDictionary *resultDict = [responseDict objectForKey:@"result"];
    self.items = [resultDict objectForKey:@"documents"];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [items count];
}

#pragma mark - Table view delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"PlaceCell";
    PlaceCell *cell = (PlaceCell *)[self.tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Configure the cell...
    NSDictionary *place = [items objectAtIndex:indexPath.row];
    cell.placeLabel.text = [place valueForKey:@"place_title"];
    cell.addressLabel.text = [place valueForKey:@"place_address1"];
    cell.cszLabel.text = [NSString stringWithFormat:@"%@, %@ %@",[place valueForKey:@"place_city"],[place valueForKey:@"place_state"], [place valueForKey:@"place_zip"]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (editingStyle == UITableViewCellEditingStyleDelete)
	{
        [self deletePlace:indexPath];
        [self.items removeObjectAtIndex:indexPath.row];
        [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
    }
}

- (void) deletePlace:(NSIndexPath *)indexPath {
    NSDictionary *place = [self.items objectAtIndex:indexPath.row];
    NSString *documentKey = [place valueForKey:@"key"];
    
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *files = [[NSMutableDictionary alloc] init];
    ApstrataiPhoneClient *client = [[ApstrataiPhoneClient alloc] initWithURL: URL key: AUTHKey secret: SECRET authMode: SIMPLE];
    NSString* methodName = @"DeleteDocument";
    [parameters setObject:documentKey  forKey: @"apsdb.documentKey"];
    
    NSString *jsonString = [client callAPIJson: (NSString *)methodName params:parameters files: files];
    NSLog(@"deletePlace json string: %@",jsonString);
    
    SBJSON *parser = [[SBJSON alloc] init];
    NSDictionary *results = [parser objectWithString:jsonString error:nil];
    for (id key in results)
    {
        NSLog(@"results key: %@, value: %@", key, [results objectForKey:key]);
    }
    
    NSString *statusCodeString = [results valueForKeyPath:@"response.metadata.statusCode"];
    NSInteger statusCode = [statusCodeString intValue];
    NSLog(@"Status Code: %i",statusCode);
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"EditLocationSegue"])
    {
        
        AddEditPlaceViewController *detailViewController =
        [segue destinationViewController];
        
        NSIndexPath *myIndexPath = [self.tableView
                                    indexPathForSelectedRow];
        
        detailViewController.mode = @"Edit";
        detailViewController.navigationItem.title = @"Edit Location";
        detailViewController.place = [items objectAtIndex:myIndexPath.row];
    }
}
 

@end


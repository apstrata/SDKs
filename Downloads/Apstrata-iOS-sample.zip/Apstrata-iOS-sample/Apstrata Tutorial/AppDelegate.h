//
//  AppDelegate.h
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/24/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

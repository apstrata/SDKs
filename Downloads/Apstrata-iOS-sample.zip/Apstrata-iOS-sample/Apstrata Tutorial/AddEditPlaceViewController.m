//
//  AddEditPlaceViewController.m
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/25/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//


#import "AddEditPlaceViewController.h"
#import "apstrata.h"
#import "Constants.h"
#import "JSON.h"
#import "UIImage+Resize.h"

@interface AddEditPlaceViewController ()

@end

@implementation AddEditPlaceViewController
@synthesize placeTextField;
@synthesize addressTextField;
@synthesize cityTextField;
@synthesize stateTextField;
@synthesize zipTextField;
@synthesize place;
@synthesize mode;
@synthesize picker, photoImage, photoLabel;

BOOL photoAdded;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    picker = [[UIImagePickerController alloc] init];
    if ([mode isEqualToString:@"Edit"]) {
        placeTextField.text = [place valueForKey:@"place_title"];
        addressTextField.text = [place valueForKey:@"place_address1"];
        cityTextField.text = [place valueForKey:@"place_city"];
        stateTextField.text = [place valueForKey:@"place_state"];
        zipTextField.text = [place valueForKey:@"place_zip"];
        
        [self getFile];
    }

    
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [self setPlaceTextField:nil];
    [self setAddressTextField:nil];
    [self setCityTextField:nil];
    [self setStateTextField:nil];
    [self setZipTextField:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [placeTextField release];
    [addressTextField release];
    [cityTextField release];
    [stateTextField release];
    [zipTextField release];
    [super dealloc];
}

-(IBAction) textFieldDoneEditing:(id)sender {
	[sender resignFirstResponder];
}

- (BOOL) checkDuplicate {
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *files = [[NSMutableDictionary alloc] init];
    ApstrataiPhoneClient *client = [[ApstrataiPhoneClient alloc] initWithURL: URL key: AUTHKey secret: SECRET authMode: SIMPLE];
    
    NSString *query = [NSString stringWithFormat:@"apsdb.schema = \"place\" AND place_title = \"%@\"",placeTextField.text];
    NSString *methodName = @"Query";
  
    [parameters setObject:query forKey: @"apsdb.query"];
    [parameters setObject:@"place_title<String:ASC>" forKey:@"apsdb.sort"];
    [parameters setObject:@"place_title" forKey: @"apsdb.queryFields"];
    [parameters setObject:@"TRUE" forKey:@"apsdb.count"];
    NSString *jsonString = [client callAPIJson: (NSString *)methodName params:parameters files: files];
    
    SBJSON *parser = [[SBJSON alloc] init];
    NSDictionary *results = [parser objectWithString:jsonString error:nil];
    NSString *countString = [results valueForKeyPath:@"response.result.count"];
    NSInteger count = [countString intValue];
    if (count > 0)
        return TRUE;
    else
        return FALSE;
}

- (void)addLocation
{
    if (self.checkDuplicate) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Duplicate"
                                                        message:[NSString stringWithFormat:@"Location %@ already exists",placeTextField.text]                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
        return;
    }
    if ([placeTextField.text length] == 0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Required"
                                                        message:[NSString stringWithFormat:@"Must enter a place"]                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    NSDictionary *files = [[NSMutableDictionary alloc] init]; // Files to upload (if any)
    if (self.photoImage != nil)
    {
        NamedFileData *namedFileDataImg = [[NamedFileData alloc] init];
        NSData *fileData = [NSData dataWithData: UIImagePNGRepresentation(self.photoImage)];
        [namedFileDataImg setFileData:fileData];
        [namedFileDataImg setFileName:placeTextField.text];
        NSMutableArray* fileDataArray = [NSMutableArray arrayWithObject:namedFileDataImg];
        [files setValue: fileDataArray forKey:@"place_image"];
    }
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
    ApstrataiPhoneClient *client = [[ApstrataiPhoneClient alloc] initWithURL: URL key: AUTHKey secret: SECRET authMode: SIMPLE];
    
    NSString* methodName = @"SaveDocument";
    [parameters setObject: @"place" forKey: @"apsdb.schema"];
    [parameters setObject: placeTextField.text forKey: @"place_title"];
    [parameters setObject: addressTextField.text forKey: @"place_address1"];
    [parameters setObject: cityTextField.text forKey: @"place_city"];
    [parameters setObject: stateTextField.text forKey: @"place_state"];
    [parameters setObject: zipTextField.text forKey: @"place_zip"];
    NSString *jsonString = [client callAPIJson: (NSString *)methodName params:parameters files: files];
    
    SBJSON *parser = [[SBJSON alloc] init];
    NSDictionary *results = [parser objectWithString:jsonString error:nil];
    NSString *statusCodeString = [results valueForKeyPath:@"response.metadata.statusCode"];
    NSInteger statusCode = [statusCodeString intValue];
    NSLog(@"Status Code: %i",statusCode);
    
    if (statusCode == FAILED)
    {
        NSString *errorCode = [results valueForKeyPath:@"response.metadata.errorCode"];
        NSString *errorDetail = [results valueForKeyPath:@"response.metadata.errorDetail"];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:errorCode
                                                        message:errorDetail                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
        return;
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Saved"
                                                    message:@"added new location"                                                       delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles: nil];
    [alert show];
    return;
}

- (void)updateLocation
{
    NSMutableDictionary *files = [[NSMutableDictionary alloc] init];
    if (self.photoImage != nil)
    {
        NamedFileData *namedFileDataImg = [[NamedFileData alloc] init];
        NSData *fileData = [NSData dataWithData: UIImagePNGRepresentation(self.photoImage)];
        [namedFileDataImg setFileData:fileData];
        [namedFileDataImg setFileName:placeTextField.text];
        NSMutableArray* fileDataArray = [NSMutableArray arrayWithObject:namedFileDataImg];
        [files setValue: fileDataArray forKey:@"place_image"];
    }
    
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
    ApstrataiPhoneClient *client = [[ApstrataiPhoneClient alloc] initWithURL: URL key: AUTHKey secret: SECRET authMode: SIMPLE];
        
    // pmc todo - add logic to make sure values are not null.  othriwse set them to blank empty string
    NSString *documentKey = [place valueForKey:@"key"];
    NSString* methodName = @"SaveDocument";
    [parameters setObject: @"place" forKey: @"apsdb.schema"];
    [parameters setObject: documentKey forKey: @"apsdb.documentKey"];
    [parameters setObject: placeTextField.text forKey: @"place_title"];
    [parameters setObject: addressTextField.text forKey: @"place_address1"];
    [parameters setObject: cityTextField.text forKey: @"place_city"];
    [parameters setObject: stateTextField.text forKey: @"place_state"];
    [parameters setObject: zipTextField.text forKey: @"place_zip"];
    
    NSString *jsonString = [client callAPIJson: (NSString *)methodName params:parameters files: files];
    NSLog(@"Json Result: %@",jsonString);
    
    SBJSON *parser = [[SBJSON alloc] init];
    NSDictionary *results = [parser objectWithString:jsonString error:nil];
    NSString *statusCodeString = [results valueForKeyPath:@"response.metadata.statusCode"];
    NSInteger statusCode = [statusCodeString intValue];
    NSLog(@"Status Code: %i",statusCode);
    
    if (statusCode == FAILED)
    {
        NSString *errorCode = [results valueForKeyPath:@"response.metadata.errorCode"];
        NSString *errorDetail = [results valueForKeyPath:@"response.metadata.errorDetail"];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:errorCode
                                                        message:errorDetail                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
        return;
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Saved"
                                                    message:@"updated location"                                                       delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles: nil];
    [alert show];
    return;
    
}



- (IBAction)savePlace:(id)sender {
/*
    if (self.photoImage == nil)
    {
        self.photoImage = [UIImage imageNamed:@"camera_icon.jpg"];
//        self.photoImage = [UIImage imageWithContentsOfFile:@"camera_icon.jpg"];
        self.addPhotoButton.imageView.image = [photoImage thumbnailImage:85 transparentBorder:5 cornerRadius:5 interpolationQuality:kCGInterpolationDefault];
    }
*/
    if ([mode isEqualToString:@"Edit"])
        [self updateLocation];
    else
        [self addLocation];
}


-(IBAction)addPhotoButtonPressed {
    [self addPhoto];
}

-(void)addPhoto {
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		
		UIActionSheet *actionSheet = [[UIActionSheet alloc]
									  initWithTitle:@"Add Photo for Location"
									  delegate:self
									  cancelButtonTitle:@"Cancel"
									  destructiveButtonTitle:nil
									  otherButtonTitles:@"Use Camera", @"Choose From Library", nil];
		[actionSheet showInView:self.view];
		[actionSheet release];
	}
	else if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentModalViewController:picker animated:YES];
		//        [picker release];
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Error accessing photo library"
                              message:@"Device does not support a photo library"
                              delegate:nil
                              cancelButtonTitle:@"Drat!"
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
}

#pragma mark -
#pragma mark Image Picker

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	if (buttonIndex == 0) {
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
	}
	else if (buttonIndex == 1) {
		picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
	}
	else if (buttonIndex == 2) {
		NSLog(@"Cancel");
		return;
		//		picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
	}
	
	picker.delegate = self;
	picker.allowsEditing = YES;
	[self presentModalViewController:picker animated:YES];
}


-(void)imagePickerController:(UIImagePickerController *)thePicker
didFinishPickingMediaWithInfo:(NSDictionary *)info {
	//addPhoto = YES;
	[thePicker dismissModalViewControllerAnimated:YES];
	
	self.photoImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
	if (self.photoImage == NULL)
    {
        NSLog(@"No Photo image returned");
    }
    
    photoAdded = FALSE;
    
	self.photoLabel.text = @"Change Photo";
	self.addPhotoButton.imageView.image = [photoImage thumbnailImage:85 transparentBorder:5 cornerRadius:5 interpolationQuality:kCGInterpolationDefault];
}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)thePicker {
    [thePicker dismissModalViewControllerAnimated:YES];
}



- (void) uploadPhoto {
    NSLog(@"ready to upload photo");
    
    // pmc todo - refactor this code to prep an image for upload into another method
    NamedFileData *namedFileDataImg = [[NamedFileData alloc] init];
    NSData *fileData = [NSData dataWithData: UIImagePNGRepresentation(self.photoImage)];
    [namedFileDataImg setFileData:fileData];
    [namedFileDataImg setFileName:@"file001.jpeg"];
    NSMutableArray* fileDataArray = [NSMutableArray arrayWithObject:namedFileDataImg];
    
    NSMutableDictionary *files = [[NSMutableDictionary alloc] init];
    [files setValue: fileDataArray forKey:@"photo_image"];
    
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
        
    ApstrataiPhoneClient *client = [[ApstrataiPhoneClient alloc] initWithURL: URL key: AUTHKey secret: SECRET authMode: SIMPLE];
    
    NSString* methodName = @"SaveDocument";
    [parameters setObject:@"photos"  forKey: @"apsdb.schema"];
    [parameters setObject:self.placeTextField.text forKey: @"photo_title"];
    
    NSString *jsonString = [client callAPIJson: (NSString *)methodName params:parameters files: files];
    NSLog(@"File Upload Json Result: %@",jsonString);  
}

- (void)getFile {
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
    [parameters removeAllObjects];
    ApstrataiPhoneClient *client = [[ApstrataiPhoneClient alloc] initWithURL: URL key: AUTHKey secret: SECRET authMode: SIMPLE];
    
    NSString *documentKey = [place valueForKey:@"key"];
    NSString *fileName = placeTextField.text;
    NSString *path = @"";
    
    NSString *methodName = @"GetFile";
    [parameters setObject: documentKey forKey: @"apsdb.documentKey"];
    [parameters setObject: fileName forKey: @"apsdb.fileName"];
    [parameters setObject: @"place_image" forKey: @"apsdb.fieldName"];
    
    NSData *photoData = [client callAPIFile: methodName params:parameters path:path];
    NSLog(@"length of image file = %i",[photoData length]);
    
    if ([photoData length] < 2000)
    {
        self.addPhotoButton.imageView.image = [UIImage imageNamed:@"camera_icon.jpg"];
    }
    else
    {
        self.photoImage = [UIImage imageWithData:photoData];
        self.addPhotoButton.imageView.image = photoImage;
//        self.addPhotoButton.imageView.image = [photoImage thumbnailImage:85 transparentBorder:5 cornerRadius:5 interpolationQuality:kCGInterpolationDefault];
        
    }

}


    
@end

//
//  Constants.h
//  Apstrata
//

// apstrata
#define URL     @"http://sandbox.apstrata.com/apsdb/rest"
#define AUTHKey @"R2ECAA860F"
#define SECRET  @"C43E4B0E5EBB458BA2C5B98C84A5542F"
//#define AUTHKey @"[your authkey]"
//#define SECRET  @"[your secret]"

// statusCode
#define SUCCESS 200
#define FAILED  400


//
//  apstrata.cpp
//  apstrato
//
//  Created by Dani Mezher on 4/20/12.
//  Copyright (c) 2012 USJ. All rights reserved.
//

#include "apstrata.h"
#include <fstream>
using namespace std;
#include <CommonCrypto/CommonDigest.h>
#include <CommonCrypto/CommonHMAC.h>

@implementation NamedFileData

@synthesize fileName;
@synthesize fileData;

@end

@implementation ApstrataiPhoneClient

-(NSString*) timeStamp{
    NSDate *date = [NSDate date];
    NSTimeInterval ti = [date timeIntervalSince1970];
 	return [NSString stringWithFormat:@"%f",ti];
}

-(NSString*) hexToString:(unsigned char const *)bytes length:(int)length{
    NSMutableString *string=[[NSMutableString alloc] init];
    for(int i=0;i<length;++i){
        [string appendFormat:@"%02X",(unsigned int) bytes[i]];
    }
    return string;
}

-(NSString *) encodeValue:(NSString*)value {
    /*
	NSMutableString * output = [NSMutableString string];
    unsigned char const * source = (unsigned char const *) [value cStringUsingEncoding:NSUTF8StringEncoding];
    int sourceLen = strlen((const char *)source);
    for (int i = 0; i < sourceLen; ++i) {
        const unsigned char thisChar = source[i];
        if (thisChar == ' '){
            [output appendString:@"%%20"];
        } else if (thisChar=='*'){
            [output appendString:@"*"];
        } else if (thisChar == '.' || thisChar == '-' || thisChar == '_' || thisChar == '~' || 
                   (thisChar >= 'a' && thisChar <= 'z') ||
                   (thisChar >= 'A' && thisChar <= 'Z') ||
                   (thisChar >= '0' && thisChar <= '9')) {
            [output appendFormat:@"%c", thisChar];
        } else {
            [output appendFormat:@"%%%02X", thisChar];
        }
    }
    return output;
	 */
	CFStringRef urlString = CFURLCreateStringByAddingPercentEscapes(
																	NULL,
																	(__bridge CFStringRef)value,
																	NULL,
																	(CFStringRef)@"!*'\"();:@&=+$,/?%#[]% ",
																	kCFStringEncodingUTF8 );
	return (__bridge NSString *)urlString;
}


-(id) initWithURL:(NSString*) _baseUrl key:(NSString *) _key authMode:(AuthMode) _authMode{
    self=[super init];
    if (self){
        APSTRATA_PREFIX=[[NSString alloc] initWithString:@"apsws."];
        USER=[APSTRATA_PREFIX stringByAppendingString:@"user"];
        TIME_STAMP=[APSTRATA_PREFIX stringByAppendingString:@"time"];
        SIGNATURE= [APSTRATA_PREFIX stringByAppendingString:@"authSig"];
        SIGNATURE_MODE= [APSTRATA_PREFIX stringByAppendingString:@"authMode"];
        RESPONSE_TYPE_PARAM = [APSTRATA_PREFIX stringByAppendingString:@"responseType"];
        RESPONSE_TYPE_XML	= [[NSString alloc] initWithString:@"xml"];
        RESPONSE_TYPE_JSON	= [[NSString alloc] initWithString:@"json"];
        baseUrl = _baseUrl;
		key = _key;
		authMode = _authMode;   
        user=nil;
        secret=nil;
    }
    return self;
}

-(id) initWithURL:(NSString*) _baseUrl key:(NSString *) _key user:(NSString*)_user password:(NSString *)_password authMode:(AuthMode) _authMode{
    self=[super init];
    if (self){
        if (!(self = [self initWithURL:_baseUrl key:_key authMode:_authMode])) return nil;
        user = _user;
        unsigned char md5Buffer[CC_MD5_DIGEST_LENGTH];
        CC_MD5([_password cStringUsingEncoding:NSASCIIStringEncoding],_password.length,md5Buffer);
        secret = [self hexToString:md5Buffer length:CC_MD5_DIGEST_LENGTH];
    }
    return self;
}

-(id) initWithURL:(NSString*)_baseUrl key:(NSString *)_key secret:(NSString*)_secret authMode:(AuthMode) _authMode{
    self=[super init];
    if (self){
        if (!(self = [self initWithURL:_baseUrl key:_key authMode:_authMode])) return nil;
        secret = _secret;
    }
    return self;
}

-(NSString*) getLevel1SignatureForKey:(NSString*) authenticationKey secretAccessKey:(NSString*)secretAccessKey action:(NSString*) action time:(NSString *) timeStamp{
    NSString* stringToSign=[timeStamp stringByAppendingFormat:@"%@%@%@",authenticationKey,action,secretAccessKey];
    unsigned char md5Buffer[CC_MD5_DIGEST_LENGTH];
    CC_MD5([stringToSign cStringUsingEncoding:NSASCIIStringEncoding],stringToSign.length,md5Buffer);
    return [self hexToString:md5Buffer length:CC_MD5_DIGEST_LENGTH];
}

-(NSString*) getLevel2SignatureForKey:(NSString*) privateAccessKey parameters:(NSDictionary*) parameters files:(NSDictionary*) files baseURL:(NSString*) baseURL{
    NSMutableArray *treeSet=[[NSMutableArray alloc] init];
    for(NSString *encodedKey in [parameters allKeys]){
        NSString *encodedValue=[self encodeValue:[parameters objectForKey:encodedKey]];
        [treeSet addObject:[NSString stringWithFormat:@"%@=%@",encodedKey,encodedValue]];
    }    
	
	bool isMultiPart = (files != nil && files.count > 0);
    if(isMultiPart){
        for (NSString* fieldName in [files allKeys])
        {
            NSString* encodedKey =[self encodeValue:fieldName];
            NSArray* fieldFiles = [files objectForKey:fieldName];
            for (NSString *file in fieldFiles) {
                ifstream fis([file cStringUsingEncoding:NSUTF8StringEncoding],ios::binary);
                unsigned char buffer[4096];
                unsigned char md5Buffer[CC_MD5_DIGEST_LENGTH];
                CC_MD5_CTX ctx;
                CC_MD5_Init(&ctx);
                streamsize readCount;
                do{
                    fis.read((char*) buffer,4096*sizeof(unsigned char));
                    readCount=fis.gcount();
                    CC_MD5_Update(&ctx, buffer, readCount);
                }
                while(readCount>0);
                CC_MD5_Final(md5Buffer, &ctx);					
                NSString* hashedValue =[self hexToString:md5Buffer length:CC_MD5_DIGEST_LENGTH];
                NSString *value =[self encodeValue:hashedValue];
                [treeSet addObject:[NSString stringWithFormat:@"%@=%@",encodedKey,value]];
            }
        }
    }	
	
	NSArray *sortedTreeSet = [treeSet sortedArrayUsingSelector:@selector(compare:)];
    NSMutableString *stBuilder=[[NSMutableString alloc] init];
    for(int i=0;i<[sortedTreeSet count];++i){
        if (i)
            [stBuilder appendString:@"&"];
        NSString *s=[sortedTreeSet objectAtIndex:i];
        [stBuilder appendString:s];
    }
    NSString* stringToSign = [NSString stringWithFormat:@"POST\n%@\n%@",[self encodeValue:baseURL],stBuilder];
	NSLog(@"string to sign: %@",stringToSign);
    unsigned char cHMAC[CC_SHA1_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA1, [privateAccessKey cStringUsingEncoding:NSASCIIStringEncoding], privateAccessKey.length, 
           [stringToSign cStringUsingEncoding:NSASCIIStringEncoding],stringToSign.length, cHMAC);
    return [self hexToString:cHMAC length:CC_SHA1_DIGEST_LENGTH];
}
/*
-(NSString*) getFullApiUrlWithQueryParameters:(NSString*) action parameters:(NSDictionary*) parameters files:(NSDictionary *)files {
    NSString* timeStamp = [self timeStamp];
    
    NSMutableArray * stringedParams=[[[NSMutableArray alloc] init] autorelease];
    NSMutableString *url = [NSMutableString stringWithFormat:@"%@/%@/%@",baseUrl,key,action];
    
    [stringedParams addObject:[NSString stringWithFormat:@"%@=%@",TIME_STAMP,timeStamp]];
    
    if (user != nil) {
        [stringedParams addObject:[NSString stringWithFormat:@"%@=%@",USER,user]];//[self encodeValue:fieldName]
    }
    
   
    
    NSString *signature;
    // if secret is null then trying to do anonymous access
    if (secret != nil) {
        if (authMode == COMPLEX) {
            // grouping all parameters for signature level 2
            NSMutableDictionary* allParams=[NSMutableDictionary dictionaryWithDictionary:parameters];
            [allParams setObject:timeStamp forKey:TIME_STAMP];
            if (user != nil) {
                [allParams setObject:user forKey:USER];
            }
            
        
            signature =[self getLevel2SignatureForKey:secret parameters:allParams files:files baseURL:url];
        } else if (authMode == SIMPLE) {
            NSString* authKey = key;
            if (user != nil) {
                authKey = user;
            }
            signature = [self getLevel1SignatureForKey:authKey secretAccessKey:secret action:action time:timeStamp];
            [stringedParams addObject:[NSString stringWithFormat:@"%@=simple",SIGNATURE_MODE]];
            
        } else {
            // TODO: token based, add it as a cookie or param
            @throw @"token based auth not yet supported";
        }
        [stringedParams addObject:[NSString stringWithFormat:@"%@=%@",SIGNATURE,signature]];
    }
    [url appendString:@"?"];
    for (NSString *p in stringedParams) {
        [url appendString:p];
        [url appendString:@"&"];
    }
    return url;
}
*/
-(NSString*) getFullApiUrl:(NSString *) action parameters:(NSDictionary *) parameters files:(NSDictionary *) files{
	//return @"https://test-apps.apstrata.com/apsdb/rest/WC7A01F4C8/asdf?apsws.time=1342103295.925683&apsws.authSig=D1A09DAAB376032B1160D43AD2BCD2AA9FC873E24E630000C09F2A1D48D4FFBF&";
    NSString* timeStamp =[self timeStamp];
    NSMutableArray *stringedParams=[[NSMutableArray alloc] init];
    NSMutableString *url=[NSMutableString stringWithFormat:@"%@/%@/%@",baseUrl,key,action];
	//return url;
    [stringedParams addObject:[NSString stringWithFormat:@"%@=%@",TIME_STAMP,timeStamp]];
    if (user != nil) {
        [stringedParams addObject:[NSString stringWithFormat:@"%@=%@",USER,user]];
    }
	for (NSString* param in parameters) {
		
		[stringedParams addObject:[NSString stringWithFormat:@"%@=%@",[self encodeValue:param], [self encodeValue:[parameters objectForKey:param]]]];
	}
	
        /*	
         * TODO: add the run as user option to the call api options	
         if (this.runAsUser != null) {
         stringedParams.add(Constants.RUN_AS_USER + "=" + this.runAsUser);
         }
         */
    NSString* signature = nil;
		// if secret is null then trying to do anonymous access
    if (secret != nil) {
        if (authMode == COMPLEX) {
				// grouping all parameters for signature level 2
			
            NSMutableDictionary* allParams=[NSMutableDictionary dictionaryWithDictionary:parameters];
            //[allParams setObject:[NSString stringWithFormat:@"%ld",timeStamp] forKey:TIME_STAMP];
			[allParams setObject:[NSString stringWithFormat:@"%@",timeStamp] forKey:TIME_STAMP];
            if (user != nil) {
                [allParams setObject:user forKey:USER];
            }
                
                /*
                 * TODO: add the run as user option to the call api options	
                 if (this.runAsUser != null) {
                 allParams.add(new BasicNameValuePair(RUN_AS_USER, this.runAsUser));
                 }
                 */
			
            signature =[self getLevel2SignatureForKey:secret parameters:allParams files:files baseURL:url];
        } else {
            if (authMode == SIMPLE) {
				NSString *authKey = key;
				if (user != nil) {
					authKey = user;
				}
				signature = [self getLevel1SignatureForKey:authKey secretAccessKey:secret action:action time:timeStamp];
                [stringedParams addObject:[NSString stringWithFormat:@"%@=simple",SIGNATURE_MODE]];
				
			} else {
				// TODO: token based, add it as a cookie or param
				@throw @"token based auth not yet supported";
			}
		}
		[stringedParams addObject:[NSString stringWithFormat:@"%@=%@", SIGNATURE,signature]];
		}
		
		[url appendString:@"?"];
		for (NSString* param in stringedParams) {
			[url appendString:[param stringByAppendingString:@"&"]];
		}
		NSLog(@"built apstrata url: %@",url);
	NSString* rr = [NSString stringWithString:url];
	return rr;
	}

-(NSData*) getDataResponse:(NSString *)fullURL parameters:(NSDictionary*)parameters files:(NSDictionary *)files{
	//fullURL = @"https://test-apps.apstrata.com/apsdb/rest/WC7A01F4C8/Query?apsws.time=1342454494.688846&apsdb.query=apsdb.documentKey%3D%22E86902C9400ABC982DFF28C16B1FA876%22&apsdb.queryFields=%2A&apsws.responseType=json&apsws.authSig=FC9416ABED1DFC0CA79E11095B70AF12662C928949630000C06F701FD8D3FFBF";
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:fullURL]];
    [request setHTTPMethod:@"POST"];
    NSString* stringBoundary=@"0xApStrATAStRiNGbOuNdArY";
    [request setValue:[NSString stringWithFormat:@"multipart/form-data; boundary=%@", stringBoundary] forHTTPHeaderField:@"Content-type"];
    NSMutableData *postBody = [NSMutableData data];
    
    BOOL isMultiPart=(files!=nil && [files count]>0);
    if (isMultiPart) {
        if (parameters!=nil){
            for (NSString *_key in [parameters allKeys]) {
                NSString *value=[parameters objectForKey:_key];
                // create data
                
                [postBody appendData:[[NSString stringWithFormat:@"--%@\r\n", stringBoundary] dataUsingEncoding:NSUTF8StringEncoding]];
                [postBody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n",_key] dataUsingEncoding:NSUTF8StringEncoding]];
                [postBody appendData:[value dataUsingEncoding:NSUTF8StringEncoding]];
                [postBody appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
            }
        }
        if (files != nil){
            for(NSString *_key in [files allKeys]){
                
                // We first verify the type of element that is contained in the dictionary.
                // The possible types are NSString (file path) or NSData (file content)
                NSArray *values=[files objectForKey:_key];
                BOOL isData = false;
                if ([values count] > 0) {
                    
                    isData = [[values objectAtIndex:0] isKindOfClass:[NamedFileData class]];
                }
                              
                // If we are dealing with file pathes
                if (!isData) {
                    for(NSString *fileName in values){
                        
                        // extract the actual file name from fileName variable (i.e. remove path info)
                        NSRange lastIndexOfSlash = [fileName rangeOfString:@"/" options:NSBackwardsSearch];
                        NSString *fileNameWithoutPath = fileName;
                        if (lastIndexOfSlash.location > 0) {
                            fileNameWithoutPath = [fileName substringFromIndex:lastIndexOfSlash.location + 1];
                        }
                        
                        NSData *fileData = [NSData dataWithContentsOfFile:fileName];
                        
                        // Add to body
                        [self addToBody:_key postBody:postBody stringBoundary:stringBoundary fileName:fileNameWithoutPath fileData:fileData];
                    }
                }else {
                    
                    // We are dealing with data, i.e. the files are already loaded and passed to the SDK
                    for(NamedFileData* namedFileData in values){
                        
                        NSString* fileName = [namedFileData fileName];
                        NSData* fileData = [namedFileData fileData];
                        
                        // Add to body
                        [self addToBody:_key postBody:postBody stringBoundary:stringBoundary fileName:fileName fileData:fileData];
                    }
                }
            }
        }
        // final boundary
        [postBody appendData:[[NSString stringWithFormat:@"--%@--\r\n", stringBoundary] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    else {
        //        if (parameters != null) {
        //            httpPost.setEntity(new UrlEncodedFormEntity(parameters));
        //        }	
    }
    [request setHTTPBody:postBody];    
    // pointers to some necessary objects
    NSURLResponse* response;
    NSError* error;
    
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    if (responseData == nil)
    {
        return nil;
    }
    else {
        NSLog(@"success invoking apstrata at %@, response: %@",fullURL,[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding]);
    }
    return responseData;
}

-(void) addToBody: (NSString*) _key postBody:(NSMutableData*) postBody  stringBoundary: (NSString*) stringBoundary fileName: (NSString*) fileName fileData: (NSData*) fileData {
    
    // media part
    [postBody appendData:[[NSString stringWithFormat:@"--%@\r\n", stringBoundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [postBody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n",_key,fileName]
                          dataUsingEncoding:NSUTF8StringEncoding]];
    // [postBody appendData:[@"Content-Type: ****** \r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [postBody appendData:[@"Content-Transfer-Encoding: binary\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    // add it to body
    [postBody appendData:fileData];
    [postBody appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
}

-(NSString*) getStringResponse:(NSString*) fullURL parameters:(NSDictionary*) parameters files:(NSDictionary*) files {
    NSData *responseData = [self getDataResponse:fullURL parameters:parameters files:files];
    if (responseData==nil)
        return nil;
    return [[NSString alloc] initWithBytes:[responseData bytes] length:[responseData length] encoding:NSUTF8StringEncoding];
}

-(NSString*) callAPIMethod:(NSString*) methodName parameters:(NSDictionary *)params files:(NSDictionary *)files {
    NSString* response;
	@try {
		//NSString* apiUrl =[self getFullApiUrlWithQueryParameters:methodName parameters:params files:files];
        NSString* apiUrl = [self getFullApiUrl:methodName parameters:params files:files];
		return [self getStringResponse:apiUrl parameters:params files:files];
	}
	@catch (NSException * e) {
		response = @"{ { metadata : { status : 'failure', errorDetail:";
		response = [response stringByAppendingString : [e reason]];
		response = [response stringByAppendingString : @"} } }"];   
		NSLog (@"callApiMethod caught exception ", [e reason]);
		return response;
	}
	
}

-(NSDictionary *) setApiParam:(NSDictionary *)params name:(NSString*)paramName value:(NSString*) paramValue {
    NSMutableDictionary* paramsUpdated=[NSMutableDictionary dictionaryWithDictionary:params];
    [paramsUpdated setObject:paramValue forKey:paramName];
    return paramsUpdated;
}

-(NSString*) callAPI:(NSString *)method parameters:(NSDictionary *)params files:(NSDictionary *)files{
    //return @"sdf";
	NSString *apiUrl=[self getFullApiUrl:method parameters:params files:files];
	//NSString *apiUrl=[self getTest:method parameters:params files:files];
	//return apiUrl;
    return [self getStringResponse:apiUrl parameters:params files:files];
}

-(NSString*) callAPIJson:(NSString*) methodName  params:(NSDictionary *)params files:(NSDictionary *)files{
	//return @"sss";
    NSDictionary* paramsUpdated=[self setApiParam:params name:RESPONSE_TYPE_PARAM value:RESPONSE_TYPE_JSON];
    return [self callAPI:methodName parameters:paramsUpdated files:files];
}

-(NSString*) callAPIXML:(NSString*) methodName  params:(NSDictionary *)params files:(NSDictionary *)files{
    NSDictionary* paramsUpdated=[self setApiParam:params name:RESPONSE_TYPE_PARAM value:RESPONSE_TYPE_XML];
    return [self callAPI:methodName parameters:paramsUpdated files:files];
}


-(NSData*)callAPIFile:(NSString *)methodName params:(NSDictionary *)params path:(NSString *)path{
    NSString *apiURL=[self getFullApiUrl:methodName parameters:params files:nil];
    NSData *data=[self getDataResponse:apiURL parameters:params files:nil];
    if (path != NULL && ([path length] != 0)) {
        [data writeToFile:path atomically:NO];
    }
    
    return data;
}



@end

//
//  AddEditPlaceViewController.h
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/25/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddEditPlaceViewController : UIViewController <UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIAlertViewDelegate, UIActionSheetDelegate>
@property (retain, nonatomic) IBOutlet UITextField *placeTextField;
@property (retain, nonatomic) IBOutlet UITextField *addressTextField;
@property (retain, nonatomic) IBOutlet UITextField *cityTextField;
@property (retain, nonatomic) IBOutlet UITextField *stateTextField;
@property (retain, nonatomic) IBOutlet UITextField *zipTextField;

@property (nonatomic, retain) IBOutlet UIButton *addPhotoButton;
@property (nonatomic, retain) UIImagePickerController *picker;
@property (nonatomic, retain) UIImage *photoImage;
@property (nonatomic, retain) IBOutlet UILabel *photoLabel;

@property (retain, nonatomic) NSDictionary *place;
@property (retain, nonatomic) NSString *mode;

- (IBAction) textFieldDoneEditing:(id)sender;
- (IBAction) savePlace:(id)sender;
- (IBAction) addPhotoButtonPressed;

- (void) addPhoto;
- (void) uploadPhoto;
- (void) getFile;

@end

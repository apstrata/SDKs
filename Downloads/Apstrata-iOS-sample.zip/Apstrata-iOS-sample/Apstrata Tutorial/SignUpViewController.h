//
//  SignUpViewController.h
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/24/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController
@property (retain, nonatomic) IBOutlet UITextField *loginTextField;
@property (retain, nonatomic) IBOutlet UITextField *nameTextField;
@property (retain, nonatomic) IBOutlet UITextField *emailTextField;
@property (retain, nonatomic) IBOutlet UITextField *passwordTextField;
@property (retain, nonatomic) IBOutlet UITextField *confirmPasswordTextField;

- (IBAction)signupButtonPressed:(id)sender;
- (IBAction)textFieldDoneEditing:(id)sender;

@end

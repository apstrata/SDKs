//
//  PlaceCell.m
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/25/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//

#import "PlaceCell.h"

@implementation PlaceCell
@synthesize placeLabel;
@synthesize addressLabel;
@synthesize cszLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [placeLabel release];
    [addressLabel release];
    [cszLabel release];
    [super dealloc];
}
@end

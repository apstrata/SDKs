//
//  PlacesViewController.h
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/25/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlacesViewController : UIViewController  <UITableViewDelegate, UITableViewDataSource> {
    
    UITableView *tableView;
	NSMutableArray *items;
}

@property (nonatomic, retain) NSMutableArray *items;
@property (retain, nonatomic) IBOutlet UITableView *tableView;

- (void)getPlaces;
- (void)deletePlace:(NSIndexPath *)indexPath;

@end

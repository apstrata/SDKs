//
//  SignUpViewController.m
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/24/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//

#import "SignUpViewController.h"
#import "apstrata.h"
#import "Constants.h"
#import "JSON.h"

@interface SignUpViewController ()

@end

@implementation SignUpViewController
@synthesize loginTextField;
@synthesize nameTextField;
@synthesize emailTextField;
@synthesize passwordTextField;
@synthesize confirmPasswordTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [self setLoginTextField:nil];
    [self setNameTextField:nil];
    [self setEmailTextField:nil];
    [self setPasswordTextField:nil];
    [self setConfirmPasswordTextField:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [loginTextField release];
    [nameTextField release];
    [emailTextField release];
    [passwordTextField release];
    [confirmPasswordTextField release];
    [super dealloc];
}

-(IBAction) textFieldDoneEditing:(id)sender {
	[sender resignFirstResponder];
}

- (IBAction)signupButtonPressed:(id)sender {
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init]; // API parameters
    NSDictionary *files = [[NSMutableDictionary alloc] init]; // Files to upload (if any)

    // Apstrata API connection client
    ApstrataiPhoneClient *client = [[ApstrataiPhoneClient alloc] initWithURL: URL key: AUTHKey secret: SECRET authMode: SIMPLE];
    
    NSString* methodName = @"SaveUser"; // Apstrata API method to call

    // set parameter values to populate user fields with screen values
    [parameters setObject: loginTextField.text forKey: @"login"];
    [parameters setObject: passwordTextField.text forKey: @"password"];
    [parameters setObject: nameTextField.text forKey: @"name"];
    [parameters setObject: emailTextField.text forKey: @"email"];
    
    // Call API method with parameters and return JSON response
    NSString *jsonString = [client callAPIJson: (NSString *)methodName params:parameters files: files];
    
    // Parse json response
    SBJSON *parser = [[SBJSON alloc] init];
    NSDictionary *results = [parser objectWithString:jsonString error:nil];
    NSString *statusCodeString = [results valueForKeyPath:@"response.metadata.statusCode"];
    NSInteger statusCode = [statusCodeString intValue];
    
    // if response failed display alert with message
    if (statusCode == FAILED)
    {
        NSString *errorCode = [results valueForKeyPath:@"response.metadata.errorCode"];
        NSString *errorDetail = [results valueForKeyPath:@"response.metadata.errorDetail"];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:errorCode
                                                        message:errorDetail                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
        return;
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"New User Signed Up"
                                                        message:[NSString stringWithFormat:@"New user %@ signed up", loginTextField.text]                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
    }
    [self performSegueWithIdentifier: @"SignUpSegue" sender: self];
}


@end

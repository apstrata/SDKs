//
//  PlaceCell.h
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/25/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlaceCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *placeLabel;
@property (retain, nonatomic) IBOutlet UILabel *addressLabel;
@property (retain, nonatomic) IBOutlet UILabel *cszLabel;

@end

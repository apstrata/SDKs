//
//  LoginViewController.m
//  Apstrata Tutorial
//
//  Created by Peter Chmiel on 9/24/12.
//  Copyright (c) 2012 CEC. All rights reserved.
//

#import "LoginViewController.h"
#import "apstrata.h"
#import "Constants.h"
#import "JSON.h"

@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize loginTextField;
@synthesize passwordTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [self setLoginTextField:nil];
    [self setPasswordTextField:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [loginTextField release];
    [passwordTextField release];
    [super dealloc];
}

-(IBAction) textFieldDoneEditing:(id)sender {
	[sender resignFirstResponder];
}

- (IBAction)loginButtonPressed:(id)sender {
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init]; // API parameters
    NSDictionary *files = [[NSMutableDictionary alloc] init]; // Files to upload (if any)
    
    // Apstrata API connection client with additional user and password values to verify user
    ApstrataiPhoneClient *client = [[ApstrataiPhoneClient alloc] initWithURL: URL key: AUTHKey user:loginTextField.text password:passwordTextField.text authMode: COMPLEX];
    
    NSString* methodName = @"VerifyCredentials"; // Apstrata API method to call
    
    // Call API method with parameters and return JSON response
    NSString *jsonString = [client callAPIJson: (NSString *)methodName params:parameters files: files];
    
    // Parse json response
    SBJSON *parser = [[SBJSON alloc] init];
    NSDictionary *results = [parser objectWithString:jsonString error:nil];
    NSString *statusCodeString = [results valueForKeyPath:@"response.metadata.statusCode"];
    NSInteger statusCode = [statusCodeString intValue];
    
    // if response failed display alert with message
    if (statusCode == FAILED)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Login Failed"
                                                        message:@"User and password not found"                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
        return;
    }
    
    [self performSegueWithIdentifier: @"LoginSegue" sender: self];
 
}
@end

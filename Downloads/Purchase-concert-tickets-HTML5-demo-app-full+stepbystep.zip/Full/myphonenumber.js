//constructor
var MyPhoneNumberPlugin = {
	getMyPhoneNumber: function(onSuccess, onError) {
		//console.log("at getMyPhoneNumber");
		return cordova.exec(onSuccess, onError, "MyPhoneNumberPlugin", "getMyPhoneNumber", []);
	}
}

/****************************************************************************
 * This object implements helper functions that are required by all views.
 * Custom views should extend this object in order to use its helper functions
 *****************************************************************************/

define(["dojo/_base/declare", "dojo/_base/window", "dojo/dom-class"],
    function(declare, win, domClass) {
 
        return declare(null, {
        	/********************************************************************************************************************
        	 * Function that pushes data into a template (primitive implementation) by replacing placeholders with their 
        	 * corresponding values.
        	 * For example, assume an html snippet with the place holders ${a} and ${b} and an object {a: AAA, b: BBB}.
        	 * Calling this function and passing the html snippet and the object previsouly mentioned will result in a new
        	 * html snippet in which the ${a} placeholder is replaced with the value AAA and the ${b} place holder is replaced 
        	 * with the value BBB 
        	 ********************************************************************************************************************/
            substitute: function(template, obj) {
                return template.replace(/\$\{([^\s\:\}]+)(?:\:([^\s\:\}]+))?\}/g, function(match, key){
                    return obj[key];
                });
            }
        });
	}
);
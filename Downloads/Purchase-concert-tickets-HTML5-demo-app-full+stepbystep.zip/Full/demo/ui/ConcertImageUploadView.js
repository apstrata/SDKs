/**************************************************************************************************
 * This widget is responsible for uploading a new concert image after entering its details, such as
 * title, description, and tags.
 * It extends ScrollableView from dojo package and ViewMixin from demo package.
 * Phonegap does not know how to interpret the html file input. Hence, we could not use apstrata's javescript
 * SDK to upload the file by posting an html form that contains an html file input. Instead we had to use
 * phonegap's file transfer API.
 **************************************************************************************************/

define(["dojo/ready", "dojo/_base/declare", "dojo/io-query", "dojo/dom", "dojo/dom-style", "dojo/dom-attr", "dojo/_base/lang", "dojo/Deferred", "dojox/mobile/ContentPane", "dojox/mobile/ScrollableView", "dojox/mobile/ProgressIndicator", "apstrataDemo/ui/ViewMixin", "apstrata/sdk/ClientWrapper", "dojo/text!./templates/ConcertImageUploadView.html"],
    function(ready, declare, ioQuery, dom, domStyle, domAttr, lang, Deferred, ContentPane, ScrollableView, ProgressIndicator, ViewMixin, ClientWrapper, ConcertImageUploadViewTemplate){
        return declare([ScrollableView, ViewMixin], {

			// Html snippet of the view
			templateString: ConcertImageUploadViewTemplate,
			     
			// The connection object used to retrieve and post data to apstrata  	
        	connection: null,
        	
        	// The label of the back button indicating the view to go to when it is clicked
        	backButtonLabel: null,
        	
        	// The id of the view to go to when the back button is clicked
        	backButtonTarget: null,
        	
        	// The document key of the concert at hand
        	concertDocumentKey: null,
        	
        	// The title of the concert at hand
        	concertTitle: null,
        	
        	// The uri of the image returned by phonegap as a result of selecting an image from the device's photo gallery
        	imageUri: null,
        	
        	// Progress indicator widget reference variable. It is implemented as an instance variable of the view since 
        	// when phonegap finishes the upload, it calls a callback function where the progress indicator should be removed.
        	// Hence the instantiation of the progress indicator and its removal do not happen in the same function.  
        	prog: null,
        	
			constructor: function(params, node) {
				if (params) {
					if (params.connection) {
						this.connection = params.connection;
					}					
	
					if (params.backButtonLabel) {
						this.backButtonLabel = params.backButtonLabel;
					}					

					if (params.backButtonTarget) {
						this.backButtonTarget = params.backButtonTarget;
					}					
				}
				
				// Instantiate a progress indicator to use while the file is being uploaded. 
				// It is instantiated in the constructor so that we use the same instance 
				// when more than one image are uploaded consecutively.
				this.prog = new ProgressIndicator({size:40, center:true, removeOnStop: true});								
				
				this.inherited(arguments);
			},
			
			initialize: function(concertDocumentKey, concertTitle) {
				var self = this;
				
				// Destory the content of the view so that we rebuild it based on the provided concert document key and title
				this.destroyDescendants();
				
				// Preserve the concert document key and title as instance variables to be used in other functions
				this.concertDocumentKey = concertDocumentKey;
				this.concertTitle = concertTitle;
				
				// Define the values required for the html template substitution of place holders		
				var values = {
					documentKey: this.concertDocumentKey,
					title: this.concertTitle,
					backButtonLabel: this.backButtonLabel,
					backButtonTarget: this.backButtonTarget
				};
				
				// Intatiate a content pane and initialize it with the html template of the view 
				// after replacing the place holders with their corresponding values.
				var contentPane = new ContentPane({content: self.substitute(self.templateString, values), parseOnLoad: true});
				
				// Wait until the DOM of the pane is ready and widgets are created   
				ready(function() {
					// Add the pane to the view
					contentPane.placeAt(self.containerNode);
					contentPane.startup();
				});
							
  			},
  			
  			/***********************************************************************************
  			 * Callback function that gets called by phonegap upon the 
  			 * successful selection of an image from the device's photo gallery.
  			 * Phonegap passes the uri of the selected image as a parameter to this function
  			 ***********************************************************************************/
  			onImageSelectionSuccess: function(imageUri) {
  				this.imageUri = imageUri;
  				
  				var node = dom.byId("selectedImage"); 
				node.src = imageUri;
				
				node = dom.byId("selectedImageDiv");
				domStyle.set(node, "display", "block");	
						
			},
  			
  			/***********************************************************************************
  			 * Callback function that gets called by phonegap upon the 
  			 * failure of selecting an image from the device's photo gallery.
  			 * Phonegap passes the error message as a parameter to this function
  			 ***********************************************************************************/
  			onImageSelectionFail: function(message) {
				alert('Error while selecting image: ' + message);
			},
  			
  			/****************************************************************************
  			 * Function that handles the event of clicking on the button designated 
  			 * to choose an image residing on the device
  			 ****************************************************************************/
  			selectImage: function() {
  				// Set reference variables to phonegap's enumerators used to control the image selection from the device
  				var imageSource = navigator.camera.PictureSourceType;
				var destinationType = navigator.camera.DestinationType;
				var encodingType = navigator.camera.EncodingType;

				// Open the photo gallery on the device and set the success and failure callback functions that gets called when the image selection is done	
				navigator.camera.getPicture(lang.hitch(this, this.onImageSelectionSuccess), lang.hitch(this, this.onImageSelectionFail), { quality: 50, 
			        destinationType: destinationType.FILE_URI,
			        sourceType: imageSource.PHOTOLIBRARY,
			        encodingType: encodingType.JPEG });
				
  			},
  			
  			/******************************************************************
  			 * Callback function that gets called by phonegap when it is 
  			 * successfully done with the transfer of the file
  			 ******************************************************************/
  			onUploadSuccess: function(r) {
  				// Stop and remove the progress indicator
	        	this.prog.stop();
	        	
				alert("Operation succeeded!");
				
				console.log("Code = " + r.responseCode);
				console.log("Response = " + r.response);
  			},
  			
  			/********************************************************
  			 * Callback function that gets called by phonegap 
  			 * when it fails to transfer the file
  			 ********************************************************/
  			onUploadFailure: function(error) {
  				// Stop and remove the progress indicator
		    	this.prog.stop();
		    	
				alert("Operation failed! Please try again.");
  			},
  			
  			/*
  			 * 
  			 */
  			uploadImage: function() {
  				var self = this;
				
				
				//**************************************************************************************************************************************************
				/*******************************************************
				* Upload image in the browser and not from a mobile device
				********************************************************/

  				// Add the progress indicator to the DOM and start it
  		    	this.prog.placeAt(this.containerNode);
  		  		this.prog.start();
				
				// Instantiate an apstrata client, which will be used to execute the query
  		        var client = new ClientWrapper(this.connection);
  		    
  		    	// Issue a call to the apstrata client to save a document with the image being attached
	  			client.call("SaveDocument", {}, dom.byId("uploadImageForm"), {method:"POST"}).then(
					function(response) {
			        	self.prog.stop();
			        	
						alert("Operation succeeded!");
						
						console.log("Code = " + r.responseCode);
						console.log("Response = " + r.response);
					}, 
					function(response) {
				    	self.prog.stop();
				    	
						alert("Operation failed! Please try again.");
					}
				);
				
				return;
				
				//**************************************************************************************************************************************************
				
				
				
				
				
				//****************************************************************************************************************
				// The following code is meant to be used for mobile devices
				// You can enable it by just removing the return statemtent just above
				
  				// Check that an image has been chosen by the user before starting the file transfer operation
  				var imageSrc = domAttr.get(dom.byId("selectedImage"), "src");
  				if (!imageSrc) {
  					alert("Please choose an image to upload.");
  					return;
  				}
  				
  				// Get the title, description and tags of the image as entered by the user
  				var title = dom.byId("title").value;
  				var description = dom.byId("description").value;
  				var tags = dom.byId("tags").value; 
  	
  				// Add the progress indicator to the DOM and start it
  		    	this.prog.placeAt(this.containerNode);
  		  		this.prog.start();

				// Transform the image uri into a physical path on the device
				window.resolveLocalFileSystemURI(self.imageUri,
					/********************************************************************************
					 * Function that gets called by phonegap upon the successful
					 * transformation of the selected image uri into a physical path on the device. 
					 * Phonegap passes the file name and full path in an object
					 * as a parameter to this function.
					 ********************************************************************************/ 
					function(fileEntry) {
  				
			  			// Define the file upload attributes 
			  			var options = new FileUploadOptions();
			            options.fileKey = "picture";
			            options.fileName = fileEntry.name;
			            options.mimeType = "image/jpeg";
			
						// Define extra parameters to send in the file upload request
			            var params = new Object();
			            params["apsdb.schema"] = "concert_image";
			            params.concert = self.concertDocumentKey;
			            if (title) { 
			            	params.title = title;
			            }
			            if (description) {
			            	params.description = description;
			            }
			            if (tags) {
			            	params.tags = tags;
			            }
			            options.params = params;
			            
			            // Build the apstrata SaveDocument API url that will be used to transfer the file by phonegap
			            var uploadUrl = self.connection.sign("SaveDocument", "").url;
			            
			            console.log(uploadUrl);
			
						// Instantiate a phonegap FileTransfer object and initiate an upload 
						// by providing the selected image full path, the apstrata SaveDocument url, 
						// and the success and failure callback functions that get called when done transferring the file
			            var ft = new FileTransfer();
			            ft.upload(fileEntry.fullPath, uploadUrl, lang.hitch(self, self.onUploadSuccess), lang.hitch(self, self.onUploadFailure), options);
			            
				}, 
				/***********************************************************************
				 * Function that gets called by phonegap when it fails to
				 * transform the selected image uri into a physical path on the device 
				 ***********************************************************************/ 
				function(evt) {
					self.prog.stop();
					alert("Error reading the image file: " + evt.target.error.code);
				});
				
  			}	
			
  			
        });
    }  			
);
/**************************************************************************************************
 * This widget is responsible for displaying the details of a certain concert, 
 * along with the abilitu to buy tickets for the concert and to view the concert gallery.
 * It extends ScrollableView from dojo package and ViewMixin from demo package
 **************************************************************************************************/

define(["dojo/ready", "dojo/_base/declare", "dojo/_base/window", "dijit/registry", "dojo/dom", "dojo/dom-style", "dojo/io-query", "dojo/Deferred", "dojox/mobile/ContentPane", "dojox/mobile/Tooltip", "dojox/mobile/ScrollableView", "dojox/mobile/ProgressIndicator", "apstrataDemo/ui/ViewMixin", "apstrata/sdk/ClientWrapper", "apstrataDemo/ui/ConcertGalleryView", "apstrataDemo/ui/ConcertTicketsBuyingView", "dojo/text!./templates/ConcertDetailsView.html"],
    function(ready, declare, win, registry, dom, domStyle, ioQuery, Deferred, ContentPane, Tooltip, ScrollableView, ProgressIndicator, ViewMixin, ClientWrapper, ConcertGalleryView, ConcertTicketsBuyingView, ConcertDetailsViewTemplate){
        return declare([ScrollableView, ViewMixin], {

			// Html snippet of the view
			templateString: ConcertDetailsViewTemplate,
			       	
			// The connection object used to retrieve and post data to apstrata
        	connection: null,
        	
        	// The label of the back button indicating the view to go to when it is clicked
        	backButtonLabel: null,
        	
        	// The id of the view to go to when the back button is clicked
        	backButtonTarget: null,
        	
        	// The document key of the concert at hand
        	concertDocumentKey: null,
        	
        	// The title of the concert at hand
        	concertTitle: null,
        	
        	// The ticket price in LL of the concert at hand
        	concertTicketPriceLL: null,
        	
        	// The label of the view, which gets displayed as the label of the back button in the view transitioned to from this one
        	viewLabel: "Details", 
        	
			constructor: function(params, node) {
				if (params) {
					if (params.connection) {
						this.connection = params.connection;
					}					
	
					if (params.backButtonLabel) {
						this.backButtonLabel = params.backButtonLabel;
					}					

					if (params.backButtonTarget) {
						this.backButtonTarget = params.backButtonTarget;
					}					
				}
				
				this.inherited(arguments);
			},
			
			initialize: function(documentKey) {
				var self = this;
				
				var deferred = new Deferred();
				
				// Preserve the concert document key as an instance variable of the view
				this.concertDocumentKey = documentKey;
				
				// Destory the content of the view so that we rebuild it based on the provided concert document key
				this.destroyDescendants();

				// Display a progress indicator since calls to apstrata are asynchronous				
				var prog = new ProgressIndicator({size:40, center:true, removeOnStop: true});
  		    	prog.placeAt(this.containerNode);
  		  		prog.start();
  		  		
  		  		// Define the parameters of the query used to get all the details of a concert
  		  		var queryParams = {
					"apsdb.query" : "apsdb.documentKey = \"" + documentKey + "\"", 
					"apsdb.queryFields" : "*"   		        	
  		        };
  		        
  		        // Instantiate a new apstrata client, which will be used to execute the query
  		        var client = new ClientWrapper(this.connection);
  		    
  		    	// Issue a call to the apstrata client to execute the query
	  			client.call("Query", queryParams, null, {method:"GET"}).then(
						/**********************************************************************
						 * Function that gets called upon the successful execution of the query.
						 * This function is given the apstrata Query API response as parameter.
						 **********************************************************************/
	  					function(response) {		

							// Stop and remove the progress indicator									
							prog.stop();
							
							// Preserve the concert title and ticket price as instance variables of the view
							self.concertTitle = response.result.documents[0].title;
							self.concertTicketPriceLL = response.result.documents[0].ticketPriceLL;

							// Define the parameters required to build the concert image url
							var pictureUrl = self.connection.sign("GetFile", ioQuery.objectToQuery({
								"apsdb.documentKey": documentKey,
								"apsdb.fieldName": "picture",
								"apsdb.fileName": response.result.documents[0].picture
							})).url;

							// Get the concert document reference and place it in a variable 
							// that will be used to substitute placeholders in the template of the view 
							var templateFiller = response.result.documents[0];
							templateFiller.date = templateFiller.date.split("T")[0]; 
							templateFiller.backButtonLabel = self.backButtonLabel;
							templateFiller.backButtonTarget = self.backButtonTarget;
							templateFiller.pictureUrl = pictureUrl;
							
							// Intatiate a content pane and initialize it with the html template of the view 
							// after replacing the place holders with their corresponding values.
							var contentPane = new ContentPane({content: self.substitute(self.templateString, templateFiller), parseOnLoad: true});
							
							// Wait until the DOM of the pane is ready and widgets are created 
							ready(function() {
								// Add the pane to the view
								contentPane.placeAt(self.containerNode);
								contentPane.startup();
								deferred.resolve();	
							});
									  						
	  					},
	  					/**********************************************************************
						 * Function that gets called upon failing to execute the query.
						 * This function is given the apstrata Query API response as parameter.
						 **********************************************************************/
	  					function(response) {
	  						
	  						//handle errors in this case
	  						
	  						prog.stop();
	  						
	  						deferred.reject();
	  					}
	  			);
	  			
	  			return deferred;
				
  			},
  			
  			
  			/*****************************************************************************************
  			 * Function that handles the event of clicking on the button designated for buying tickets
  			 *****************************************************************************************/
  			buyTickets: function() {
  				
  				// Check if the view for buying tickets has already been instantiated. If not, then instantiate one.
	  			var concertTicketsBuyingView = registry.byId(apstrata.apConfig.views.concertTicketsId);
	  			if (!concertTicketsBuyingView) {
	  				concertTicketsBuyingView = new ConcertTicketsBuyingView({id: apstrata.apConfig.views.concertTicketsId, keepScrollPos: true, connection: this.connection, backButtonLabel: this.viewLabel, backButtonTarget: apstrata.apConfig.views.concertDetailsId});
	  				concertTicketsBuyingView.placeAt(win.body());
	  				concertTicketsBuyingView.startup();
	  			}
	  			
	  			// Transition to the instantiated view
	  			this.performTransition(apstrata.apConfig.views.concertTicketsId, 1, "slide", null, null);
	  			
	  			// Initialize the instantiated view with needed attributes of the concert at hand
	  			concertTicketsBuyingView.initialize(this.concertDocumentKey, this.concertTitle, this.concertTicketPriceLL);  				
  			}, 
  			
  			/***********************************************************************************************
  			 * Function that handles the event of clicking on the button designated for viewing the gallery
  			 ***********************************************************************************************/
  			viewGallery: function() {
  				
  				// Check if the gallery view has already been instantiated. If not, then instantiate one.
	  			var concertGalleryView = registry.byId(apstrata.apConfig.views.concertGalleryId);
	  			if (!concertGalleryView) {
	  				concertGalleryView = new ConcertGalleryView({id: apstrata.apConfig.views.concertGalleryId, keepScrollPos: true, connection: this.connection, backButtonLabel: this.viewLabel, backButtonTarget: apstrata.apConfig.views.concertDetailsId});
	  				concertGalleryView.placeAt(win.body());
	  				concertGalleryView.startup();
	  			}
	  			
	  			// Transition to the instantiated view
	  			this.performTransition(apstrata.apConfig.views.concertGalleryId, 1, "slide", null, null);
	  			
	  			
	  			// Initialize the instantiated view with needed attributes of the concert at hand
	  			concertGalleryView.initialize(this.concertDocumentKey, this.concertTitle);
  			}
			
        });
    }  			
);
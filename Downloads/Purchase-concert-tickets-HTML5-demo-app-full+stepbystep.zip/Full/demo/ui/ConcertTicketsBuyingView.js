/**************************************************************************************************
 * This widget is responsible for displaying a form where the user can choose to buy concert tickets
 * by entering his/her full name and the number of tickets to buy
 * It extends ScrollableView from dojo package and ViewMixin from demo package
 **************************************************************************************************/

define(["dojo/ready", "dojo/_base/declare", "dojo/dom", "dojo/io-query", "dojo/Deferred", "dojox/mobile/ContentPane", "dojox/mobile/Tooltip", "dojox/mobile/ScrollableView", "dojox/mobile/ProgressIndicator", "apstrataDemo/ui/ViewMixin", "apstrata/sdk/ClientWrapper", "apstrataDemo/util/Twitter", "dojo/text!./templates/ConcertTicketsBuyingView.html"],
    function(ready, declare, dom, ioQuery, Deferred, ContentPane, Tooltip, ScrollableView, ProgressIndicator, ViewMixin, ClientWrapper, Twitter, ConcertTicketsBuyingViewTemplate){
        return declare([ScrollableView, ViewMixin], {

			// Html snippet of the view
			templateString: ConcertTicketsBuyingViewTemplate,
			       	
			// The connection object used to retrieve and post data to apstrata
        	connection: null,
        	
        	// The label of the back button indicating the view to go to when it is clicked
        	backButtonLabel: null,
        	
        	// The id of the view to go to when the back button is clicked
        	backButtonTarget: null,
        	
        	// The document key of the concert at hand
        	concertDocumentKey: null,
        	
        	// The title of the concert at hand
        	concertTitle: null,
        	
        	// The ticket price in LL of the concert at hand
        	concertTicketPriceLL: null,
        	
			constructor: function(params, node) {
				if (params) {
					if (params.connection) {
						this.connection = params.connection;
					}					
	
					if (params.backButtonLabel) {
						this.backButtonLabel = params.backButtonLabel;
					}					

					if (params.backButtonTarget) {
						this.backButtonTarget = params.backButtonTarget;
					}					
				}
				
				this.inherited(arguments);
			},
			
			initialize: function(documentKey, title, ticketPriceLL) {
				var self = this;
				
				// Preserve the concert document key, title and ticket price as instance variables of the view
				this.concertDocumentKey = documentKey;
				this.concertTitle = title;
				this.concertTicketPriceLL = ticketPriceLL;
				
				// Destory the content of the view so that we rebuild it based on the provided concert attributes
				this.destroyDescendants();

				// Define the values required for the html template substitution of place holders				
				var values = {
					title: this.concertTitle,
					backButtonLabel: this.backButtonLabel,
					backButtonTarget: this.backButtonTarget
				};
							
				// Intatiate a content pane and initialize it with the html template of the view 
				// after replacing the place holders with their corresponding values.
				var contentPane = new ContentPane({content: self.substitute(self.templateString, values), parseOnLoad: true});
				
				// Wait until the DOM of the pane is ready and widgets are created  
				ready(function() {
					// Add the pane to the view
					contentPane.placeAt(self.containerNode);
					contentPane.startup();
				});
				
  			},
  			
  			/****************************************************************************
  			 * Function that handles the event of clicking on the button designated for 
  			 * decrementing the number of tickets to buy by one
  			 ****************************************************************************/
  			decrementNumberOfTickets: function(e) {
  				var node = dom.byId("numberOfTickets");
  				if (node.value && node.value > 1) {
  					node.value = parseInt(node.value) - 1;
  					this.setTotalPrice(node.value);
  				}
  			},
  			
  			/****************************************************************************
  			 * Function that handles the event of clicking on the button designated for 
  			 * incrementing the number of tickets to buy by one
  			 ****************************************************************************/  			
  			incrementNumberOfTickets: function(e) {
  				var node = dom.byId("numberOfTickets");
  				if (node.value) {
  					node.value = parseInt(node.value) + 1;
  					this.setTotalPrice(node.value);
  				} else {
  					node.value = 1;
  					this.setTotalPrice(node.value);
  				}
  			}, 
  			
  			/****************************************************************************
  			 * Function that handles the event of manually typing a value in the textbox 
  			 * designated for the number of tickets to buy 
  			 ****************************************************************************/  			
  			validateNumberOfTickets: function(e) {  
  				var node = dom.byId("numberOfTickets");
  				var value = parseInt(node.value);
  				if (!value) {
  					alert("Invalid number of tickets!");
  					node.value = 1;
  					this.setTotalPrice(node.value);
  				} else {
  					this.setTotalPrice(value);
  				}
  			},

			/****************************************************************************
			 * Function that calculates the total price based on the number of tickets
			 * to buy multiplied by the ticket price.
			 * This function gets called every time the number of tickets is incremented
			 * or decremented or manually typed or changed
			 ****************************************************************************/
  			setTotalPrice: function(numberOfTickets) {
  				var ticketPrice = parseInt(this.concertTicketPriceLL);
  				dom.byId("totalPrice").innerText = ticketPrice * numberOfTickets;
  			},
  			
  			
  			/*****************************************************************************
  			 * Function that handled the event of clicking on the button designated for
  			 * proceeding with the purchase of tickets. 
  			 * This function calls an apstrata backend scipt that does the job
  			 *****************************************************************************/
  			buyTickets: function() {
  				var self = this;
  	
  				// Get the line number of the device from the application configuration object.
  				// This line number has been detected upon the launch of the application (in file index.html)
  				var msisdn = apstrata.apConfig.phoneNumber;
  				
  				// Read the number of tickets entered by the user
  				var quantity = parseInt(dom.byId("numberOfTickets").value);
  				
  				// Read the tickets holder full name entered by the user
  				var fullName = dom.byId("fullName").value;
  				
  				// Validate that the number of tickets has been entered by the user
  				if (!quantity) {
  					alert("Please make sure that the number of tickets to buy is specified.");
  					return;
  				}
  				
  				// Validate that the tickets holder full name has been entered by the user 
  				if (!fullName) {
  					alert("Please make sure that the full name is specified.");
  					return;  					
  				}
  				
  				// Define the parameters required by the apstrata backend script that does the purchase operation
  				var params = { 
  					"apsdb.scriptName":  "app.buyTickets", 
  					"unitPrice": this.concertTicketPriceLL, 
  					"quantity" : quantity, 
  					"concertTitle": this.concertTitle, 
  					"fullName": fullName,
  					"msisdn" : msisdn  
  				};
  				
  				// Display a progress indicator since calls to apstrata are asynchronous	
  				var prog = new ProgressIndicator({size:40, center:true, removeOnStop: true});
  		    	prog.placeAt(this.containerNode);
  		  		prog.start();
  				
  				// Instantiate a new apstrata client, which will be used to execute the backend script
  				var client = new ClientWrapper(this.connection);
  		    
  		    	// Issue a call to the apstrata client to execute the backend script
	  			client.call("RunScript", params, null, {method:"POST"}).then(
	  					/************************************************************************
						 * Function that gets called upon the successful execution of the script.
						 * This function is given the apstrata RunScript API response as parameter.
						 ************************************************************************/
	  					function(response) {	
	  						
	  						// Stop and remove the progress indicator		
							prog.stop();
							
							// The RunScript API might have succeeded as a call to apstrata;
							// However, the business logic within the script might lead to a 
							// failure due to some validation rules or other rules that are not
							// respected or applied. That is why we have to check the status of
							// the script execution and not only the status of the RunScript API call
							if (response.result.status == "success") {
								alert("Operation succeeded!");
								
								// Instantiate a twitter utility object, get the authentication code and secret
								// associated with the line number of the device and tweet a message that the person
								// with the entered full name is going to the concert at hand
								var twitter = new Twitter({connection: self.connection});
								twitter.getAuthorizationTokenAndSecret(msisdn).then( function(authorization) {
									twitter.tweet(authorization.token, authorization.secret, fullName, self.concertTitle);
								});
								
							} else {
								alert("Operation failed! Please try again.");
							} 							
									  						
	  					},
	  					function(response) {
	  						
	  						//handle errors in this case
	  						
	  						// Stop and remove the progress indicator	
	  						prog.stop();
	  						
	  						alert("Operation failed! Please try again.");
	  						
	  					}
	  			);
  	  				
  			}
  			
        });
    }  			
);
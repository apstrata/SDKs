/**************************************************************************************************
 * This widget is responsible for displaying a gallery of concert images uploaded by users. It also
 * provides the ability to upload new images.
 * It extends ScrollableView from dojo package and ViewMixin from demo package
 **************************************************************************************************/

define(["dojo/ready", "dojo/_base/window", "dojo/_base/lang", "dojox/gesture/swipe", "dojo/_base/declare", "dijit/registry", "dojo/dom", "dojo/dom-style", "apstrataDemo/ui/ConcertCarousel", "dojox/mobile/ContentPane", "dojox/mobile/View", "apstrataDemo/ui/ViewMixin", "apstrata/sdk/ClientWrapper", "apstrataDemo/ui/ConcertImageUploadView", "dojo/text!./templates/ConcertGalleryView.html"],
    function(ready, win, lang, swipe, declare, registry, dom, domStyle,ConcertCarousel, ContentPane, ScrollableView, ViewMixin, ClientWrapper, ConcertImageUploadView, ConcertGalleryViewTemplate){
        return declare([ScrollableView, ViewMixin], {

			// Html snippet of the view
			templateString: ConcertGalleryViewTemplate,
			
			// The connection object used to retrieve and post data to apstrata
        	connection: null,
        	
        	// The label of the back button indicating the view to go to when it is clicked
        	backButtonLabel: null,
        	
        	// The id of the view to go to when the back button is clicked
        	backButtonTarget: null,
        	
        	// The document key of the concert at hand
        	concertDocumentKey: null,
        	
        	// The title of the concert at hand
        	concertTitle: null,
        	
        	// The carousel widget used to display the galley in the view
        	carousel: null,
        	
        	// The label of the view, which gets displayed as the label of the back button in the view transitioned to from this one
        	viewLabel: "Gallery", 
        	
			constructor: function(params, node) {
				if (params) {
					if (params.connection) {
						this.connection = params.connection;
					}					
	
					if (params.backButtonLabel) {
						this.backButtonLabel = params.backButtonLabel;
					}					

					if (params.backButtonTarget) {
						this.backButtonTarget = params.backButtonTarget;
					}					
				}
								
				this.inherited(arguments);
			},
			
			initialize: function(concertDocumentKey, concertTitle) {
				var self = this;
				
				// Destory the content of the view so that we rebuild it based on the provided concert attributes
				this.destroyDescendants();

				// Preserve the concert document key and title as instance variables of the view				
				this.concertDocumentKey = concertDocumentKey;
				this.concertTitle = concertTitle;
								
				// Define the values required for the html template substitution of place holders
				var values = {
					backButtonLabel: this.backButtonLabel,
					backButtonTarget: this.backButtonTarget,
					title: concertTitle
				};
				
				// Intatiate a content pane and initialize it with the html template of the view 
				// after replacing the place holders with their corresponding values.
				var contentPane = new ContentPane({content: self.substitute(self.templateString, values), parseOnLoad: true}); 
				
				// Wait until the DOM of the pane is ready and widgets are created  
				ready(function() {
					// Add the pane to the view
					contentPane.placeAt(self.containerNode);
					contentPane.startup();

					// Instantiate the carousel widget used to display the gallery
	  				self.carousel = new ConcertCarousel({connection: self.connection, numVisible: 4, navButton: true, height: "100px", title: "Image Gallery", selectedImageNodeId: "selectedGalleryImage", pageNumberIndicatorNodeId: "pageNumber"}, "imageCarousel");
	  				self.carousel.startup();
	  				// Initialize the carousel with images corresponding to the concert at hand
		  			self.carousel.initialize(concertDocumentKey);

					// Define the handler for the swipe event on the selected image		  			
		  			swipe.end(dom.byId("selectedGalleryImage"), lang.hitch(self.carousel, self.carousel.onSwipeImage));
				});
				
			},
			
			/*****************************************************************************
			 * Function that handles the event of clicking on the button designated for 
			 * doing a full text search on the tags associated with the uploaded images
			 *****************************************************************************/
			search: function(e) {
				// Read the search keyword entered by the user
				var searchText = dom.byId("searchText").value;
				
				// Reinitialize the gallery carousel widget with filtered images from the search results
				this.carousel.initialize(this.concertDocumentKey, searchText);
			},
			
			/*************************************************************************
			 * Function that handles the event of clicking on the button designated
			 * for uploading a new image to the gallery
			 **************************************************************************/
			uploadImage: function(e) {	
				
				// Check if the image upload view has already been instantiated. If not, then instantiate one.		
	  			var concertImageUploadView = registry.byId(apstrata.apConfig.views.concertImageUploaderId);
	  			if (!concertImageUploadView) {
	  				concertImageUploadView = new ConcertImageUploadView({id: apstrata.apConfig.views.concertImageUploaderId, keepScrollPos: true, connection: this.connection, backButtonLabel: this.viewLabel, backButtonTarget: apstrata.apConfig.views.concertGalleryId});
	  				concertImageUploadView.placeAt(win.body());
	  				concertImageUploadView.startup();
	  			}
	  			
	  			// Transition to the instantiated view
	  			this.performTransition(apstrata.apConfig.views.concertImageUploaderId, 1, "slide", null, null);
	  			
	  			// Initialize the instantiated view with needed attributes of the concert at hand
	  			concertImageUploadView.initialize(this.concertDocumentKey, this.concertTitle);				
			}
	
        });
    }  			
);
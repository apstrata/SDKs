apstrata.apConfig = {};

// apstrata.sdk related
apstrata.apConfig["apstrata.sdk"] = {
    "Connection" : {
        credentials: {
            key: 'T170B23254'
        },

        serviceURL: 'http://apstrata.touch.com.lb/apsdb/rest',
        
        
        defaultStore: '',
        timeout: 30000
    }
};

// IDs of the views to be used in the application
apstrata.apConfig.views = {
	concertsId : "concerts",
	concertDetailsId : "concertDetails",
	concertTicketsId : "concertTickets",
	concertGalleryId : "concertGallery",
	concertImageUploaderId : "concertImageUploader"
}






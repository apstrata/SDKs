/****************************************************************************
 * This object provides some helper functions required by the 
 * demo application to interact with the twitter service through the 
 * apstrata APIs
 ***************************************************************************/

define(["dojo/_base/declare", "dojo/Deferred", "apstrata/sdk/ClientWrapper"],
    function(declare, Deferred, ClientWrapper){
        return declare(null, {
        	
        	// The connection object used to retrieve and post data to apstrata
        	connection: null,

			// Consumer key and secret obtained by creating a new twitter application
			// They are required to call any of the twitter APIs.
        	consumerKey: "VZSaDoqSgDSzAOQjnnDhw",
        	consumerSecret: "nUjEPLTwaAiWjFgC5x6SrilI4yW86Fy6RnI0V3o",
			
			constructor: function(params) {
				if (params && params.connection) {
					this.connection = params.connection;
				}
				
				this.inherited(arguments);
			},
			
			/***************************************************************************************
			 * Function to get the authorization token and secret for a certain line number. 
			 * They are required to call any twitter API. Every user will have a unique token 
			 * and secret. When obtained for the first time, they will be saved in a document in 
			 * apstrata identidied by the user's line number. All this is done in an apstrata 
			 * backend script.
			 ***************************************************************************************/
  			getAuthorizationTokenAndSecret: function(msisdn) {
  				var self = this;
  				
  				var deferred = new Deferred;
  				
  				// Define the parameters of the query that gets the 
  				// document in which the access tokan and secret of the 
  				// provided line number are stored
  				var params = { 
  					"apsdb.query" : "apsdb.documentKey= \"twitter_" + msisdn + "\"", 
  					"apsdb.queryFields" : "token_" + this.consumerKey + ", secret_" + this.consumerKey 
  				};
  				
  				// Instantiate a new apstrata client, which will be used to execute the query
  				var client = new ClientWrapper(this.connection);
  				
  				// Issue a call to the apstrata client to execute the query
	  			client.call("Query", params, null, {method:"GET"}).then(
	  					/**********************************************************************
						 * Function that gets called upon the successful execution of the query.
						 * This function is given the apstrata Query API response as parameter.
						 **********************************************************************/
	  					function(response) {		
								var authorization = {};
								
								// Check if the document containing the access token and secret for the provided line number exists in the apstrata store
								if (response.result.documents.length > 0) {
									authorization.token = response.result.documents[0]["token_" + self.consumerKey];
									authorization.secret = response.result.documents[0]["secret_" + self.consumerKey];
									deferred.resolve(authorization);
								} else {
									// If the document does not exist, then generate the access token and secret for the first time									
									self.generateAuthorizationTokenAndSecret(msisdn, deferred);
								}				
	  					},
	  					/**********************************************************************
						 * Function that gets called upon failing to execute the query.
						 * This function is given the apstrata Query API response as parameter.
						 **********************************************************************/
	  					function(response) {
	  						
	  						//handle errors in this case
	  						alert(response.metadata.errorCode + ": " + response.metadata.errorDetail);
	  						deferred.reject(response.metadata);
	  						
	  					}
	  			);
	  			
	  			return deferred;
  			},
  			
  			/**********************************************************************************
  			 * This function generates an access token ad secret for the provided line number
  			 * by running an apstrata backend script
  			 **********************************************************************************/
  			generateAuthorizationTokenAndSecret: function(msisdn, deferred) {
  				var self = this;
  				
  				// Define the parameters required to run the script
				params = {
					"apsdb.scriptName":  "social.twitter.integrate", 
					"command" : "getRequestToken", 
					"requester": msisdn,
					"consumerKey": this.consumerKey,
					"consumerSecret": this.consumerSecret
				};
				
				// Instantiate a new apstrata client, which will be used to run the script
  				var client = new ClientWrapper(this.connection);
  				
  				// Issue a call to the apstrata client to execute the backend script
				client.call("RunScript", params, null, {method:"GET"}).then(
					/***************************************************************************
					 * Function that gets called upon the success of the RunScript apstrata API
					 ***************************************************************************/ 
					function(response) {
						// Check the result of the script execution. Although the RunScript API might have succeeded,
						// but the script execution might have failed due to some business login and validation rules.
						if (response.result.status == "success") {
							// The script returns a twitter authorization url, where the user is requested 
							// to allow the created twitter application (identified by concumer key and secret) 
							// to tweet on his behalf. Once he does that,
							// twitter will generate access token and secret and the apstrata script will 
							// save them in a document identified by the user line number. When the apstrata
							// script calls twitter to get access token and secret, it provides a callback
							// url to itself. Twitter redirects to this callback url when the user grants access.
							// That is how the script gets to save the access token and secret in a document.  
							var authorizationUrl = response.result.authorizationAndSecret.authorizationUrl;
	
							// Use the phonegap childbrowser plugin to navigate to the authorization url 
							// where the user is requested to grant access to the twitter application.
							// The childbrowser plugin is used to avoif loosing the application context, like
							// we do when using a regular window.open() javascript call. The user can close the 
							// childbrowser window when done, and he will be returned to the concerts application
							//window.plugins.childBrowser.showWebPage(authorizationUrl, { showLocationBar: true });
							window.open(authorizationUrl, "_blank");	
							
						} else {
							alert(response.errorDetails);
							deferred.reject(response.errorDetails);											
						}
					}, 
					/***************************************************************************
					 * Function that gets called upon the failure of the RunScript apstrata API
					 ***************************************************************************/ 
					function(response) {
						alert(response.metadata.errorCode + ": " + response.metadata.errorDetail);
						deferred.reject(response.metadata);
					}
				);
			},
			
			
			/*************************************************************************************************************
			 * Function that tweets a message on behalf of the user identified by the provided access token and secret.
			 * Again, we use an apstrata backend script to establish that
			 *************************************************************************************************************/
			tweet: function(authorizationToken, authorizationSecret, fullName, concertTitle) {
				var self = this;
  				
  				// Define the parameters required by the script to tweet a certain message
  				params = {  
  					"apsdb.scriptName": "social.twitter.api", 
    				"consumerKey": this.consumerKey, 
    				"consumerSecret": this.consumerSecret, 
    				"accessToken": authorizationToken, 
    				"accessTokenSecret": authorizationSecret, 
    				"tweetString": fullName + " is going to the concert \"" + concertTitle + "\"", 
				    "command": "tweet" 
				};
  				
				// Instantiate a new apstrata client, which will be used to run the script
  				var client = new ClientWrapper(this.connection);
  				
  				// Issue a call to the apstrata client to execute the backend script
				client.call("RunScript", params, null, {method:"POST"}).then(
					/***************************************************************************
					 * Function that gets called upon the success of the RunScript apstrata API
					 ***************************************************************************/ 
					function(response) {
						// Check the result of the script execution. Although the RunScript API might have succeeded,
						// but the script execution might have failed due to some business login and validation rules.
						if (response.result.metadata.status && response.result.metadata.status == "failure") {
							alert(response.errorDetails);
							deferred.reject(response.errorDetails);											
						}
					},
					/***************************************************************************
					 * Function that gets called upon the failure of the RunScript apstrata API
					 ***************************************************************************/ 
					function(response) {
						alert(response.metadata.errorCode + ": " + response.metadata.errorDetail);
						deferred.reject(response.metadata);
					}
				);
			}
		
		
		});
    }
);
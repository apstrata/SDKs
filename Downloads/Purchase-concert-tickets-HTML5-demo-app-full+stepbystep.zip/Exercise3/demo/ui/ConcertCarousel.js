/**************************************************************************************************
 * This widget is responsible for displaying an image stripe of the concert at hand.
 * It extends the Carousel widget from the dojo package.
 **************************************************************************************************/

define(["dojo/_base/declare", "dijit/registry", "dojox/gesture/swipe", "dojo/Deferred", "dojo/_base/lang", "dojo/dom", "dojo/dom-style", "dojo/io-query", "dojox/mobile/ProgressIndicator", "dojox/mobile/Carousel", "dojox/mobile/SwapView", "dojox/mobile/CarouselItem", "dojox/mobile/ContentPane", "dojox/mobile/ScrollableView", "apstrataDemo/ui/ViewMixin", "apstrata/sdk/ClientWrapper", "dojo/text!./templates/ConcertGalleryView.html"],
    function(declare, registry, swipe, Deferred, lang, dom, domStyle, ioQuery, ProgressIndicator, Carousel, SwapView, CarouselItem, ContentPane, ScrollableView, ViewMixin, ClientWrapper, ConcertGalleryViewTemplate){
        return declare([Carousel], {

			// The connection object used to retrieve and post data to apstrata
        	connection: null,
        	
        	// The current page number
        	pageNumber: null,
        	
        	// The selected image number
        	imageNumber: null,
        	
        	// The number of results to return per page
        	resultsPerPage: null,
        	
        	// The document key of the concert at hand
        	concertDocumentKey: null,
        	
        	// The search keyword used to filter the concert images
        	searchText: null,
        	
        	// The number of total pages for the gallery
        	totalPages: null,
        	
        	// The number of total images for the gallery
        	totalCount: null,
        	
        	// The number of images in the current page. This is not always equal to the number of results per page. The last page might have less images that the number of results per page.
        	pageCount: null,
        	
        	// The id of the node designated to display the image that has been selected in the stripe
        	selectedImageNodeId: null,
        	
        	// The id of the node designated to display the current page number out of the total number of pages
        	pageNumberIndicatorNodeId: null,
        	
			constructor: function(params, node) {
				this.inherited(arguments);
				
				if (params) {
					if (params.connection) {
						this.connection = params.connection;
					}				
					
					if (params.selectedImageNodeId) {
						this.selectedImageNodeId = params.selectedImageNodeId;
					}	
					
					if (params.pageNumberIndicatorNodeId) {
						this.pageNumberIndicatorNodeId = params.pageNumberIndicatorNodeId;
					}
				}
				
			},
			
			initialize: function(concertDocumentKey, searchText) {
				
				/********************************************************************************************
				 * EXERCISE
				 * 
				 * 1.	Explore the body of this function to understand what member variables are preserved 
				 * 		and how getting the results of the first page of images is called 
				 ********************************************************************************************/
				
				// Destory the content of the images stripe so that we rebuild it based on the provided concert document key and search keyword
				this.destroyDescendants();
				
				// Preserve some attributes as instance variables of the view
				this.resultsPerPage = this.numVisible;
				this.pageNumber = 1;
				this.concertDocumentKey = concertDocumentKey;
				this.searchText = searchText;
				
				// Get the page results for the page number set in this.pageNumber
				this.getPageResults();
  			},

			/****************************************************************************
			 * Function that handles the event of clicking on the button designated to
			 * get the next batch of images and display them in the stripe
			 ****************************************************************************/  			
  			onNextBtnClick: function(e) {
  				if (this.pageNumber < this.totalPages) {
	  				this.destroyDescendants();
	  				this.pageNumber = this.pageNumber + 1;
	  				this.getPageResults();
  				}
  			},
  			
  			
			/****************************************************************************
			 * Function that handles the event of clicking on the button designated to
			 * get the previous batch of images and display them in the stripe
			 ****************************************************************************/  			
  			onPrevBtnClick: function(e) {
  				if (this.pageNumber > 1) {
  					this.destroyDescendants();
  					this.pageNumber = this.pageNumber - 1;
  					this.getPageResults();  					
  				}
  			}, 
  			
  			
			/******************************************************************************
			 * Function that handles the event of clicking on an image in the image stripe
			 ******************************************************************************/  			
  			onClick: function(e) {
  				//Check that an image is clicked and not the previous/next button
  				if (e.target.src) {
  					dom.byId(this.selectedImageNodeId).src = e.target.src;
  					this.imageNumber = parseInt(e.target.id);
  				}
  			},
  			
  			
			/******************************************************************************
			 * Function that handles the event of swiping left or right on the image stripe
			 ******************************************************************************/  			
  			onSwipePage: function(e) {
  				// Check if the swipe was to the left 
  				if (e.dx < 0) {
  					this.onNextBtnClick();
  				} else {
  					this.onPrevBtnClick();	
  				}
  			},
  			
  			
			/**********************************************************************************************************************
			 * Function that handles the event of swiping left or right on the selected image node.
			 * If the last image in the stripe is selected, then the next page is requested when swiping left on the image.
			 * If the first image in the stripe is selected, then the previous page is requested when swiping right on the image.
			 ***********************************************************************************************************************/  			
  			onSwipeImage: function(e) {
  				// Check if the swipe was to the left
  				if (e.dx < 0) {
  					if (this.imageNumber < (this.pageCount - 1)) {
  						this.imageNumber = this.imageNumber + 1;
  						this.onClick({target: {src: this.getItemWidgetByIndex(this.imageNumber).src, id: this.imageNumber}});
  					} else {
  						this.onNextBtnClick();
  					}
  				} else {
  					if (this.imageNumber > 0) {
  						this.imageNumber = this.imageNumber - 1;
  						this.onClick({target: {src: this.getItemWidgetByIndex(this.imageNumber).src, id: this.imageNumber}});
  					} else {
  						this.onPrevBtnClick();
  					}
  				}
  			},
  			
  			/******************************************************************************
  			 * Function that handles querying apstrata for the images of a certain page
  			 ******************************************************************************/
  			getPageResults: function() {
  				var self = this;
  				
  				var deferred = new Deferred();
				
  		        // Display a progress indicator since calls to apstrata are asynchronous	
  		        var prog = new ProgressIndicator({size:40, center:true, removeOnStop: true});
  		    	prog.placeAt(this.domNode);
  		  		prog.start();
  		  		

  		        /***************************************************************************************************
  		         * EXERCISE:
  		         * 
  		         * 1. 	Define the set of parameters to be sent to the Query API as a JSON object
  		         * 			{
  		         * 				"apsdb.query" : "apsdb.schema = \"concert_image\" and concert = \"" + this.concertDocumentKey + "\"", 
  		         *	 			"apsdb.queryFields" : "apsdb.documentKey, title, picture",
  		         * 				"apsdb.pageNumber": this.pageNumber,
  		         * 				"apsdb.resultsPerPage": this.resultsPerPage,
  		         * 				"apsdb.sort": "apsdb.creationTime<date:DESC>",
  		         * 				"apsdb.count": true	
  		         * 			}
  		         * 
  		         * 2. 	Instantiate an apstrata client passing the "connection" member variable as parameter.
  		         * 		The client will be used to invoke API calls, in this case a call to the Query API
  		         * 
  		         * 3.	Issue a call to the Query API using the instantiated client object while 
  		         * 		passing the parameters defined above
  		         * 
  		         * 		1.	Define a function that gets called by the client upon the success of the Query API. 
  		         * 			This function takes the response of the Query API request as parameter.
  		         * 			Assuming that the response parameter name is "response", then the list of concerts images
  		         * 			is returned as response.result.documents, which is an array containing images JSON objects
  		         * 
  		         * 			Body of the function:
  		         * 
  		         * 			1. 	Calculate total number of pages
  		         * 			
  		         * 					self.totalPages = Math.ceil(response.result.count / self.resultsPerPage)
  		         * 
  		         * 			2.	Set the page indicator in the html 
  		         * 					
  		         * 					dom.byId(self.pageNumberIndicatorNodeId).innerText = "Page " + self.pageNumber + " of " + self.totalPages;
  		         * 
  		         * 				Check the ConcertGalleryView.html template for details on the node with the id="pageNumber"
  		         * 
  		         * 			3.	Instantiate a SwapView widget and place it as a child of the carousel
  		         * 
  		         * 			4.	For each image document do the following:
  		         * 
  		         * 				1.	Get the image url using the connection object
  		         * 
  		         * 						var imageUrl = self.connection.sign("GetFile", ioQuery.objectToQuery({
				 *							"apsdb.documentKey": "<document key of the image document>",
				 *							"apsdb.fieldName": "picture",
				 *							"apsdb.fileName": <The value of the field named picture in the image document>
				 *						})).url;
				 * 
				 * 				2.	Instantiate a CarouselItem widget while passing the following JSON as parameter
				 * 
				 * 						{
				 * 							id: <index of the image document in the array of documents returned>, 
				 * 							src: imageUrl, 
				 * 							value: <title of the image>, 
				 * 							footerText: <title of the image>
				 * 						}
				 * 
				 * 				3.	Set the style of the instantiated CarouselItem
				 * 						
				 * 						domStyle.set(item.domNode, "float", "left");
				 *		        		domStyle.set(item.domNode, "margin", "0 10px");
				 *		        		domStyle.set(item.domNode, "height", "75px");
				 * 
				 * 					where "item" is the variable name holding a reference to the instantiated CarouselItem widget
				 * 
				 * 				4. Place the instantiated CarouselItem in the SwapView instance that was created above
				 * 
				 * 						item.placeAt(swapView.containerNode);
				 *		        	
				 * 			5.	Resolve the deferred initially returned by the current getPageResults function of the carousel
  		         * 
  		         * 				deferred.resolve()
				 * 						
  		         *
  		         ******************************************************************************************************/
  		  		
	  			return deferred;
  				
  			}
  			
  			
  			
        });
    }  			
);				


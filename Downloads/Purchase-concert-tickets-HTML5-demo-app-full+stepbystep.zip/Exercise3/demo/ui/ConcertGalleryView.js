/**************************************************************************************************
 * This widget is responsible for displaying a gallery of concert images uploaded by users. It also
 * provides the ability to upload new images.
 * It extends ScrollableView from dojo package and ViewMixin from demo package
 **************************************************************************************************/

define(["dojo/ready", "dojo/_base/window", "dojo/_base/lang", "dojox/gesture/swipe", "dojo/_base/declare", "dijit/registry", "dojo/dom", "dojo/dom-style", "apstrataDemo/ui/ConcertCarousel", "dojox/mobile/ContentPane", "dojox/mobile/View", "apstrataDemo/ui/ViewMixin", "apstrata/sdk/ClientWrapper", "dojo/text!./templates/ConcertGalleryView.html"],
    function(ready, win, lang, swipe, declare, registry, dom, domStyle,ConcertCarousel, ContentPane, ScrollableView, ViewMixin, ClientWrapper, ConcertGalleryViewTemplate){
        return declare([ScrollableView, ViewMixin], {

			// Html snippet of the view
			templateString: ConcertGalleryViewTemplate,
			
			// The connection object used to retrieve and post data to apstrata
        	connection: null,
        	
        	// The label of the back button indicating the view to go to when it is clicked
        	backButtonLabel: null,
        	
        	// The id of the view to go to when the back button is clicked
        	backButtonTarget: null,
        	
        	// The document key of the concert at hand
        	concertDocumentKey: null,
        	
        	// The title of the concert at hand
        	concertTitle: null,
        	
        	// The carousel widget used to display the galley in the view
        	carousel: null,
        	
        	// The label of the view, which gets displayed as the label of the back button in the view transitioned to from this one
        	viewLabel: "Gallery", 
        	
			constructor: function(params, node) {
				if (params) {
					if (params.connection) {
						this.connection = params.connection;
					}					
	
					if (params.backButtonLabel) {
						this.backButtonLabel = params.backButtonLabel;
					}					

					if (params.backButtonTarget) {
						this.backButtonTarget = params.backButtonTarget;
					}					
				}
								
				this.inherited(arguments);
			},
			
			initialize: function(concertDocumentKey, concertTitle) {
				var self = this;
				
				// Destory the content of the view so that we rebuild it based on the provided concert attributes
				this.destroyDescendants();

				// Preserve the concert document key and title as instance variables of the view				
				this.concertDocumentKey = concertDocumentKey;
				this.concertTitle = concertTitle;
								
				// Define the values required for the html template substitution of place holders
				var templateFiller = {
					backButtonLabel: this.backButtonLabel,
					backButtonTarget: this.backButtonTarget,
					title: concertTitle
				};
				
				// Intatiate a content pane and initialize it with the html template of the view 
				// after replacing the place holders with their corresponding values.
				var contentPane = new ContentPane({content: self.substitute(self.templateString, templateFiller), parseOnLoad: true}); 
				
				// Wait until the DOM of the pane is ready and widgets are created  
				ready(function() {
					// Add the pane to the view
					contentPane.placeAt(self.containerNode);
					contentPane.startup();

					/*********************************************************************************************************
					 * EXERCISE
					 * 
					 * 1.	Instantiate a ConcertCarousel widget and have its reference stored in a member variable,
					 * 		while passing the following JSON as parameter
					 * 
					 * 			{
					 * 				connection: self.connection,
					 * 				numVisible: 4,
					 * 				navButton: true,
					 * 				height: "100px",
					 * 				title: "Image Gallery",
					 * 				selectedImageNodeId: "selectedGalleryImage",
					 * 				pageNumberIndicatorNodeId: "pageNumber"
					 * 			}
					 * 
					 * 		as well as the id of the DOM node at which the carousel will be placed, in this case "imageCarousel"
					 * 
					 * 		Check the ConcertGalleryView.html template for the DOM node with id="imageCarousel"
					 *  
					 * 2.	Render the concert carousel widget by calling its startup() function
					 * 
					 * 3.	Initialize the concert carousel with content by calling its initialize() function while 
					 * 		passing the current concert document key as parameter (the name of the parameter to pass
					 * 		in this case is concertDocumentKey) 
					 *********************************************************************************************************/
					 

					// Define the handler for the swipe event on the selected image		  			
		  			swipe.end(dom.byId("selectedGalleryImage"), lang.hitch(self.carousel, self.carousel.onSwipeImage));
				});
				
			},
			
			/*****************************************************************************
			 * Function that handles the event of clicking on the button designated for 
			 * doing a full text search on the tags associated with the uploaded images
			 *****************************************************************************/
			search: function(e) {
				// Read the search keyword entered by the user
				var searchText = dom.byId("searchText").value;
				
				// Reinitialize the gallery carousel widget with filtered images from the search results
				this.carousel.initialize(this.concertDocumentKey, searchText);

			},
			
			/*************************************************************************
			 * Function that handles the event of clicking on the button designated
			 * for uploading a new image to the gallery
			 **************************************************************************/
			uploadImage: function(e) {	
				
			}
	
        });
    }  			
);
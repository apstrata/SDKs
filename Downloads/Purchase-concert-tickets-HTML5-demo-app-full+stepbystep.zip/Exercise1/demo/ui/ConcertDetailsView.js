/**************************************************************************************************
 * This widget is responsible for displaying the details of a certain concert, 
 * along with the abilitu to buy tickets for the concert and to view the concert gallery.
 * It extends ScrollableView from dojo package and ViewMixin from demo package
 **************************************************************************************************/

define(["dojo/ready", "dojo/_base/declare", "dojo/_base/window", "dijit/registry", "dojo/dom", "dojo/dom-style", "dojo/io-query", "dojo/Deferred", "dojox/mobile/ContentPane", "dojox/mobile/Tooltip", "dojox/mobile/ScrollableView", "dojox/mobile/ProgressIndicator", "apstrataDemo/ui/ViewMixin", "apstrata/sdk/ClientWrapper","dojo/text!./templates/ConcertDetailsView.html"],
    function(ready, declare, win, registry, dom, domStyle, ioQuery, Deferred, ContentPane, Tooltip, ScrollableView, ProgressIndicator, ViewMixin, ClientWrapper, ConcertDetailsViewTemplate){
        return declare([ScrollableView, ViewMixin], {

			// Html snippet of the view
			templateString: ConcertDetailsViewTemplate,
			       	
			// The connection object used to retrieve and post data to apstrata
        	connection: null,
        	
        	// The label of the back button indicating the view to go to when it is clicked
        	backButtonLabel: null,
        	
        	// The id of the view to go to when the back button is clicked
        	backButtonTarget: null,
        	
        	// The document key of the concert at hand
        	concertDocumentKey: null,
        	
        	// The title of the concert at hand
        	concertTitle: null,
        	
        	// The ticket price in LL of the concert at hand
        	concertTicketPriceLL: null,
        	
        	// The label of the view, which gets displayed as the label of the back button in the view transitioned to from this one
        	viewLabel: "Details", 
        	
			constructor: function(params, node) {
				if (params) {
					if (params.connection) {
						this.connection = params.connection;
					}					
	
					if (params.backButtonLabel) {
						this.backButtonLabel = params.backButtonLabel;
					}					

					if (params.backButtonTarget) {
						this.backButtonTarget = params.backButtonTarget;
					}					
				}
				
				this.inherited(arguments);
			},
			
			initialize: function(documentKey) {
				var self = this;
				
				var deferred = new Deferred();
				
				// Preserve the concert document key as an instance variable of the view
				this.concertDocumentKey = documentKey;
				
				// Destory the content of the view so that we rebuild it based on the provided concert document key
				this.destroyDescendants();

				// Display a progress indicator since calls to apstrata are asynchronous				
				var prog = new ProgressIndicator({size:40, center:true, removeOnStop: true});
  		    	prog.placeAt(this.containerNode);
  		  		prog.start();
  		  		
  		  		
  		  		/********************************************************************************************************
				 * EXERCISE
				 * 
				 * 1. 	Define the set of parameters to be sent to the Query API as a JSON object 
				 * 		in order to get the details of a concert
  		         * 		
  		         * 			{
  		         * 				"apsdb.query" : "apsdb.documentKey = \"" + documentKey + "\"", 
  		         *	 			"apsdb.queryFields": "*"
  		         * 			}
  		         * 
  		         * 2. 	Instantiate an apstrata client passing the "connection" member variable as parameter.
  		         * 		The client will be used to invoke API calls, in this case a call to the Query API
  		         * 
  		         * 3.	Issue a call to the Query API using the instantiated client object while 
  		         * 		passing the parameters defined above
  		         * 
  		         * 		1.	Define a function that gets called by the client upon the success of the Query API. 
  		         * 			This function takes the response of the Query API request as parameter.
  		         * 			Assuming that the response parameter name is "response", then the concert details 
  		         * 			are returned as response.result.documents[0]
  		         * 
  		         * 			Body of the function:
				 *
				 * 
				 * 				1. Get the url of the concert main image using the connection object 
				 * 
				 * 						var pictureUrl = self.connection.sign("GetFile", ioQuery.objectToQuery({
				 *								"apsdb.documentKey": documentKey,
				 *								"apsdb.fieldName": "picture",
				 *								"apsdb.fileName": response.result.documents[0].picture
				 *						})).url;
				 * 
				 * 				
				 * 
				 * 				2. 	Declare and define a JSON object whose values will be used to substitute placeholders in the
				 * 					template of the view. This object will be initially initialized with values from the concert document
				 * 					returned by the Query API
				 * 
				 * 						var templateFiller = response.result.documents[0];
				 *						templateFiller.date = templateFiller.date.split("T")[0]; 
				 *						templateFiller.backButtonLabel = self.backButtonLabel;
				 *						templateFiller.backButtonTarget = self.backButtonTarget;
				 *						templateFiller.pictureUrl = pictureUrl;
				 * 
				 * 
				 * 
				 * 				3.	Instantiate a ContentPane widget while passing the substituted template of the view 
				 * 					as its content and specifying to parse the content on load
				 * 
				 *						var contentPane = new ContentPane({content: self.substitute(self.templateString, templateFiller), parseOnLoad: true});
				 * 
				 *				4.	Wait until the DOM of the instantiated content pane is parsed and its children widgets are ready
				 * 					before you place the instantiated ContentPane in the container node of the view and render it. Also 
				 * 					resolve the deferred that was initially returned by the current initialize function of the view
				 * 
				 * 						ready(function() {
				 * 							cp.placeAt(self.containerNode);
				 * 							cp.startup();
				 * 							deferred.resolve();
				 * 						}
				 * 
				 * 					where "cp" is a variable holding a reference to the instantiated ContentPane widget
				 * 		 
				 ********************************************************************************************************/
  		  		
  		  		
	  			return deferred;
				
  			},
  			
  			
  			/*****************************************************************************************
  			 * Function that handles the event of clicking on the button designated for buying tickets
  			 *****************************************************************************************/
  			buyTickets: function() {
  				
  			}, 
  			
  			/***********************************************************************************************
  			 * Function that handles the event of clicking on the button designated for viewing the gallery
  			 ***********************************************************************************************/
  			viewGallery: function() {
  				
  			}
			
        });
    }  			
);
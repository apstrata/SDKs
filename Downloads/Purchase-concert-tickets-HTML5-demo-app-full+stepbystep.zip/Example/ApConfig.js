apstrata.apConfig = {};

// apstrata.sdk related
apstrata.apConfig["apstrata.sdk"] = {
    // apstrata.ui related
    "apstrata.ui": {
        "widgets.Login" : {
            autoLogin: false
        }
    },
 
    // apstrata.sdk related
    "apstrata.sdk": {
        "Connection" : {
            credentials: {
                key: "T170B23254",
                secret: "",
                username: "",
                password: ""
            },
            serviceURL: 'https://apstrata.touch.com.lb/apsdb/rest',
            defaultStore: '',
            timeout: 10000
        }
    }
};

/**************************************************************************************************
 * This widget is responsible for displaying a form where the user can choose to buy concert tickets
 * by entering his/her full name and the number of tickets to buy
 * It extends ScrollableView from dojo package and ViewMixin from demo package
 **************************************************************************************************/

define(["dojo/ready", "dojo/_base/declare", "dojo/dom", "dojo/io-query", "dojo/Deferred", "dojox/mobile/ContentPane", "dojox/mobile/Tooltip", "dojox/mobile/ScrollableView", "dojox/mobile/ProgressIndicator", "apstrataDemo/ui/ViewMixin", "apstrata/sdk/ClientWrapper", "dojo/text!./templates/ConcertTicketsBuyingView.html"],
    function(ready, declare, dom, ioQuery, Deferred, ContentPane, Tooltip, ScrollableView, ProgressIndicator, ViewMixin, ClientWrapper, ConcertTicketsBuyingViewTemplate){
        return declare([ScrollableView, ViewMixin], {

			// Html snippet of the view
			templateString: ConcertTicketsBuyingViewTemplate,
			       	
			// The connection object used to retrieve and post data to apstrata
        	connection: null,
        	
        	// The label of the back button indicating the view to go to when it is clicked
        	backButtonLabel: null,
        	
        	// The id of the view to go to when the back button is clicked
        	backButtonTarget: null,
        	
        	// The document key of the concert at hand
        	concertDocumentKey: null,
        	
        	// The title of the concert at hand
        	concertTitle: null,
        	
        	// The ticket price in LL of the concert at hand
        	concertTicketPriceLL: null,
        	
			constructor: function(params, node) {
				if (params) {
					if (params.connection) {
						this.connection = params.connection;
					}					
	
					if (params.backButtonLabel) {
						this.backButtonLabel = params.backButtonLabel;
					}					

					if (params.backButtonTarget) {
						this.backButtonTarget = params.backButtonTarget;
					}					
				}
				
				this.inherited(arguments);
			},
			
			initialize: function(documentKey, title, ticketPriceLL) {
				var self = this;
				
				// Preserve the concert document key, title and ticket price as instance variables of the view
				this.concertDocumentKey = documentKey;
				this.concertTitle = title;
				this.concertTicketPriceLL = ticketPriceLL;
				
				// Destory the content of the view so that we rebuild it based on the provided concert attributes
				this.destroyDescendants();
				
				/********************************************************************************************************
				 * EXERCISE
				 * 
				 * 1. 	Declare and define a JSON object whose values will be used to substitute placeholders in the
				 * 		template of the view
				 * 
				 * 		{
				 * 			title: this.concertTitle,
				 * 			backButtonLabel: this.backButtonLabel,
				 * 			backButtonTarget: this.backButtonTarget
				 * 		}
				 * 
				 * 2.	Instantiate a ContentPane widget while passing the substituted template of the view 
				 * 		as its content and specifying to parse the content on load
				 * 
				 * 		Check the initialize() function of the ConcertDetailsView for an example
				 * 
				 * 3.	Wait until the DOM of the instantiated content pane is parsed and its children widgets are ready
				 * 		before you place the instantiated ContentPane in the container node of the view and render it
				 * 
				 * 			ready(function() {
				 * 				cp.placeAt(self.containerNode);
				 * 				cp.startup();
				 * 			}
				 * 
				 * 		where "cp" is a variable holding a reference to the instantiated ContentPane widget
				 * 		 
				 ********************************************************************************************************/

				
  			},
  			
  			/****************************************************************************
  			 * Function that handles the event of clicking on the button designated for 
  			 * decrementing the number of tickets to buy by one
  			 ****************************************************************************/
  			decrementNumberOfTickets: function(e) {
  				var node = dom.byId("numberOfTickets");
  				if (node.value && node.value > 1) {
  					node.value = parseInt(node.value) - 1;
  					this.setTotalPrice(node.value);
  				}
  			},
  			
  			/****************************************************************************
  			 * Function that handles the event of clicking on the button designated for 
  			 * incrementing the number of tickets to buy by one
  			 ****************************************************************************/  			
  			incrementNumberOfTickets: function(e) {
  				var node = dom.byId("numberOfTickets");
  				if (node.value) {
  					node.value = parseInt(node.value) + 1;
  					this.setTotalPrice(node.value);
  				} else {
  					node.value = 1;
  					this.setTotalPrice(node.value);
  				}
  			}, 
  			
  			/****************************************************************************
  			 * Function that handles the event of manually typing a value in the textbox 
  			 * designated for the number of tickets to buy 
  			 ****************************************************************************/  			
  			validateNumberOfTickets: function(e) {  
  				var node = dom.byId("numberOfTickets");
  				var value = parseInt(node.value);
  				if (!value) {
  					alert("Invalid number of tickets!");
  					node.value = 1;
  					this.setTotalPrice(node.value);
  				} else {
  					this.setTotalPrice(value);
  				}
  			},

			/****************************************************************************
			 * Function that calculates the total price based on the number of tickets
			 * to buy multiplied by the ticket price.
			 * This function gets called every time the number of tickets is incremented
			 * or decremented or manually typed or changed
			 ****************************************************************************/
  			setTotalPrice: function(numberOfTickets) {
  				var ticketPrice = parseInt(this.concertTicketPriceLL);
  				dom.byId("totalPrice").innerText = ticketPrice * numberOfTickets;
  			},
  			
  			
  			/*****************************************************************************
  			 * Function that handled the event of clicking on the button designated for
  			 * proceeding with the purchase of tickets. 
  			 * This function calls an apstrata backend scipt that does the job
  			 *****************************************************************************/
  			buyTickets: function() {
  				var self = this;
  	
  				// Get the line number of the device from the application configuration object.
  				// This line number has been detected upon the launch of the application (in file index.html)
  				var msisdn = apstrata.apConfig.phoneNumber;
  				
  				// Read the number of tickets entered by the user
  				var quantity = parseInt(dom.byId("numberOfTickets").value);
  				
  				// Read the tickets holder full name entered by the user
  				var fullName = dom.byId("fullName").value;
  				
  				// Validate that the number of tickets has been entered by the user
  				if (!quantity) {
  					alert("Please make sure that the number of tickets to buy is specified.");
  					return;
  				}
  				
  				// Validate that the tickets holder full name has been entered by the user 
  				if (!fullName) {
  					alert("Please make sure that the full name is specified.");
  					return;  					
  				}

  				// Display a progress indicator since calls to apstrata are asynchronous	
  				var prog = new ProgressIndicator({size:40, center:true, removeOnStop: true});
  		    	prog.placeAt(this.containerNode);
  		  		prog.start();
  		  		
  		  		
  		  		/***************************************************************************************************
  		  		 * EXERCISE
  		  		 * 
  		         * 1. 	Define the set of parameters to be sent to the RunScript API as a JSON object
  		         * 			{
  		         * 				"apsdb.scriptName":  "app.buyTickets",
  		         *	 			"unitPrice": this.concertTicketPriceLL,
  		         * 				"quantity" : quantity, 
  		         * 				"concertTitle": this.concertTitle,
  		         * 				"fullName": fullName,
  		         * 				"msisdn" : msisdn 
  		         * 			}
  		         * 
  		         * 2. 	Instantiate an apstrata client passing the "connection" member variable as parameter.
  		         * 		The client will be used to invoke API calls, in this case a call to the RunScript API
  		         * 
  		         * 3.	Issue a call to the RunScript API using the instantiated client object while 
  		         * 		passing the parameters defined above
  		         * 
  		         * 		1.	Define a function that gets called by the client upon the success of the RunScript API. 
  		         * 			This function takes the response of the RunScript API request as parameter.
  		         *
  		         * 			Body of the function:
  		         * 
  		         * 			if (response.result.status == "success") {
				 *				alert("Operation succeeded!");								
				 *			} else {
				 *				alert("Operation failed! Please try again.");
				 *			} 
				 * 
				 * 			where "response" is the name of the parameter recieved by the success function
  		  		 * 
  		  		 ***************************************************************************************************/
  	  				
  			}
  			
        });
    }  			
);
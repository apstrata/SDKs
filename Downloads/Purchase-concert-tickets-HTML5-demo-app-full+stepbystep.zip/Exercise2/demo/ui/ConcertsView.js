/***************************************************************************
 * This widget is responsible for displaying the list of available concerts.
 * It is also responsible for handling the touch event on a selected concert. 
  * It extends ScrollableView from dojo package.
 ***************************************************************************/
define(["dojo/_base/declare", "dojo/_base/window", "dojo/_base/lang", "dojo/Deferred", "dojox/mobile/ScrollableView", "dojox/mobile/Heading", "dojox/mobile/ToolBarButton", "dojox/mobile/RoundRectList", "dojox/mobile/ListItem", "dojox/mobile/ProgressIndicator", "apstrata/sdk/ClientWrapper", "apstrataDemo/ui/ConcertDetailsView", "dijit/registry", "dojo/dom", "dojo/dom-style"],
    function(declare, win, lang, Deferred, ScrollableView, Heading, ToolBarButton, RoundRectList, ListItem, ProgressIndicator, ClientWrapper, ConcertDetailsView, registry, dom, domStyle){
        return declare([ScrollableView], {
        	
        	// The connection object used to get the list of concerts from apstrata
        	connection: null,
        	
        	// The label of the view that gets displayed in the heading
        	viewLabel: "Concerts",
			
			constructor: function(params, node) {
				if (params && params.connection) {
					this.connection = params.connection;
				}
				
				this.inherited(arguments);
			},
			
			startup: function() {
				this.inherited(arguments);
				this.initialize();
			},
			
			initialize: function() {
				var self = this;
				
				var deferred = new Deferred();
				
				// Destroy the existing content of the view
				this.destroyDescendants();
					
				// Display a progress indicator since the call to apstrata to get the list of concerts is asynchronous 			
  				var prog = new ProgressIndicator({size:40, center:true, removeOnStop: true});
  		    	prog.placeAt(this.containerNode);
  		  		prog.start();

				// Add a heading to the view with the label "Concerts"
  		        var heading = new Heading({
  		            label: this.viewLabel
  		        });
  		        heading.placeAt(this.containerNode);
  		        heading.startup();
  		        
  		        // Add a refresh button to the heading of the view
  		        var refresh = new ToolBarButton({label: "Refresh"});
  		        domStyle.set(refresh.domNode, "float", "right");
  		        refresh.placeAt(heading.containerNode);
  		        refresh.onClick = lang.hitch(this, this.initialize);
  		        refresh.startup();
  		        
				// Define the parameters of the apstrata query used to get the list of concerts 
  		        var queryParams = {
					"apsdb.query" : "apsdb.schema = \"concert\" ", 
					"apsdb.queryFields" : "title, apsdb.documentKey"   		        	
  		        };
  		        
  		        // Instantiate an apstrata client, which will be used to execute the query
  		        var client = new ClientWrapper(this.connection);
  		    
  		    	// Issue a call to the apstrata client to execute the query
	  			client.call("Query", queryParams, null, {method:"GET"}).then(
	  					/**********************************************************************
	  					 * Function that gets called upon the successful execution of the query.
	  					 * This function is given the apstrata Query API response as parameter.
	  					 **********************************************************************/
	  					function(response) {
	  						// Stop and remove the progress indicator		
							prog.stop();
							
							// Instantiate a list widget and add it to the view
							var list = new RoundRectList();
			  		        list.placeAt(self.containerNode);
  		        
  		        			// For each of the concerts, instantiate a list item widget and add it to the list.
  		        			// The document key of the concert is set as id of the widget and its dom node, 
  		        			// so that we can identify the concert being touched or tapped on. Also, set the 
  		        			// handler function that gets called when the list item is tapped on. 
  		        			var concerts = response.result.documents;
	  						for (var i = 0; i < concerts.length; i++) {
	  							var concert = new ListItem({
	  								transition: "slide",
	  								moveTo: "#",
	  								id: concerts[i]["apsdb.documentKey"],
	  		  		                label: concerts[i].title,
	  		  		                onTouchStart: function(e) {
	  		  		                	self.handleSelection(e);
	  		  		                }
	  		  		            });
	  		  		            concert.placeAt(list.containerNode);
	  						}
	  						
	  						list.startup();	
	  						
	  						deferred.resolve();
	  						
	  					},
	  					/**********************************************************************
	  					 * Function that gets called upon the failure of the query execution.
	  					 * This function is given the apstrata Query API response as parameter.
	  					 **********************************************************************/
	  					function(response) {

	  						//handle errors in this case
	  						
	  						// Stop and remove the progress indicator	
	  						prog.stop();
	  						
	  						deferred.reject();
	  					}
	  			);
	  			
	  			return deferred;
			}, 
	  		
	  		/***********************************************************************************
	  		 * Function that handles the event of selecting a concert to view its details.
	  		 ***********************************************************************************/
	  		handleSelection: function(e) {
	  			
	  			// Check if the concert details view has already been instantiated. If not, then instantiate one.
	  			var concertDetailsView = registry.byId(apstrata.apConfig.views.concertDetailsId);
	  			if (!concertDetailsView) {
	  				concertDetailsView = new ConcertDetailsView({id: apstrata.apConfig.views.concertDetailsId, connection: this.connection, backButtonLabel: this.viewLabel, backButtonTarget: apstrata.apConfig.views.concertsId});
	  				concertDetailsView.placeAt(win.body());
	  				concertDetailsView.startup();
	  			}
	  			
	  			// Transition to the concert details view
	  			this.performTransition(apstrata.apConfig.views.concertDetailsId, 1, "slide", null, null);	
	  			
	  			// Initialize the concert details view by sending the selected concert document key as parameter. 
	  			// Note that the id of the list item representing a concert has been set to the document key of the concert in thte initialise function.
	  			concertDetailsView.initialize(e.currentTarget.id);
	  			
	  		}
		
		});
    }
);
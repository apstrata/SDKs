//
//  apstrata.h
//  apstrato
//
//

#import <Foundation/Foundation.h>

enum AuthMode{
    SIMPLE,COMPLEX
};

@interface ApstrataHelper : NSObject

+ (NSString *)generateSecretFromPassword:(NSString *)_password;

@end

@interface NamedFileData : NSObject

@property (copy) NSString* fileName;
@property (copy) NSData* fileData;
@end

@interface ApstrataiPhoneClient : NSObject{
    NSString* baseUrl;
    NSString* key;
    NSString* user;
    enum AuthMode authMode;
    NSString* secret;
    
    NSString* APSTRATA_PREFIX;
    NSString* USER;
    
    NSString* TIME_STAMP;
    NSString* SIGNATURE;
    NSString* SIGNATURE_MODE;
    NSString* RESPONSE_TYPE_PARAM;
    NSString* RESPONSE_TYPE_XML;
    NSString* RESPONSE_TYPE_JSON;
}

/*
 * Use this method to retrieve the URL of a file attached to a document stored in your account
 */
-(NSString*) getFullApiUrl:(NSString *) action parameters:(NSDictionary *) parameters files:(NSDictionary *) files;
-(id) initWithURL:(NSString*) baseUrl key:(NSString *) key authMode:(enum AuthMode) authMode;
-(id) initWithURL:(NSString*) baseUrl key:(NSString *) key user:(NSString*)user password:(NSString *)password authMode:(enum AuthMode) authMode;
-(id) initWithURL:(NSString*) baseUrl key:(NSString *) key secret:(NSString*)secret authMode:(enum AuthMode) authMode;
-(id) initWithURL:(NSString*) baseUrl key:(NSString *) key user:(NSString*)user secret:(NSString *)secret authMode:(enum AuthMode) authMode;


/*
 * Use this method when you need to call an Apstrata API. Preferred option when uploading a file.
 */
-(NSString*) callAPIMethod:(NSString*) methodName parameters:(NSDictionary *)params files:(NSDictionary *)files;

/* 
 * Use this method when you need to call an Apstrata API. The result is returned in the Json format
 */
-(NSString*) callAPIJson:(NSString*) methodName  params:(NSDictionary *)params files:(NSDictionary *)files;

/* 
 * Use this method when you need to call an Apstrata API. The result is returned in the XMLformat
 */
-(NSString*) callAPIXML:(NSString*) methodName  params:(NSDictionary *)params files:(NSDictionary *)files;

/*
 * Use this method to download a file that is attached to a document stored in your account.
 * 'path' is the local path where you would like to save the downloaded file.
 * If 'path' was null or an empty string, the method will only return the file content and will not store it locally
 */
-(NSData*) callAPIFile:(NSString *)methodName params:(NSDictionary *)params path:(NSString *)path;
@end 

/** Automatically generated file. DO NOT MODIFY */
package com.touchcloud.concert;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
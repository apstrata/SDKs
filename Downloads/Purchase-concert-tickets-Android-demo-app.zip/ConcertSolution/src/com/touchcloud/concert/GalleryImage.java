package com.touchcloud.concert;

import java.io.Serializable;

public class GalleryImage implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7356978582814548241L;
	private String key; //image key
	private String picture;
	private String title;
	private String pictureUrl;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPictureUrl() {
		return pictureUrl;
	}
	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}
}

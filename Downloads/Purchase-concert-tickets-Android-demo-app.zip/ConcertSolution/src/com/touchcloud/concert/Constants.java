package com.touchcloud.concert;

public class Constants {
	//identifies the application
	public static final String AUTH_KEY = "E99976F87D"; 
	//identifies the user; usually obtained after user login, but no login in this example 
	public static final String SECRET = "LCFA1A126891C995517B679D0A2ED276";
	public static final String BASE_URL = "https://sandbox.apstrata.com/apsdb/rest";
	
	public static final String REQ_BUY_TICKETS = "buytickets";
	public static final String REQ_UPLOAD_IMG = "uploadimages";
	public static final String REQUEST = "request";
}

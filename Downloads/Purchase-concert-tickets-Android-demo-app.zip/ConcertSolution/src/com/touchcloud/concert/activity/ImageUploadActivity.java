package com.touchcloud.concert.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.util.Log;

import com.apstrata.client.android.ApstrataClientAndroid;
import com.apstrata.client.android.ApstrataClientAndroid.AuthMode;
import com.touchcloud.concert.Constants;
import com.touchcloud.concert.R;
import com.touchcloud.concert.R.id;
import com.touchcloud.concert.R.layout;
import com.touchcloud.concert.R.string;

public class ImageUploadActivity extends Activity {
	protected final static String IMAGEURI = "imageuri";
	protected final static String CONCERT = "concert";
	
	private Uri imageURI;
	private ImageView image;
	private EditText titleET;
	private EditText descET;
	private EditText tagsET;
	private String concertKey;
	private Bitmap newImage;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_imageupload);
		
		setImageURI((Uri)getIntent().getParcelableExtra(IMAGEURI));
		image = (ImageView)findViewById(R.id.iv_selectedimage);
		newImage = decodeSampledBitmapFromResource(new File(imageURI.getPath()), 100, 100);
		image.setImageBitmap(newImage);
		
		setConcertKey(getIntent().getStringExtra(CONCERT));
	
		titleET = (EditText)findViewById(R.id.et_title);
		descET = (EditText)findViewById(R.id.et_description);
		tagsET = (EditText)findViewById(R.id.et_tags);
	}
	//taken from android developers
	//check http://developer.android.com/training/displaying-bitmaps/load-bitmap.html
	public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
    // Raw height and width of image
    final int height = options.outHeight;
    final int width = options.outWidth;
    int inSampleSize = 1;

    if (height > reqHeight || width > reqWidth) {

        // Calculate ratios of height and width to requested height and width
        final int heightRatio = Math.round((float) height / (float) reqHeight);
        final int widthRatio = Math.round((float) width / (float) reqWidth);

        // Choose the smallest ratio as inSampleSize value, this will guarantee
        // a final image with both dimensions larger than or equal to the
        // requested height and width.
        inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
    }

    return inSampleSize;
}
	//taken from android developers
	//check http://developer.android.com/training/displaying-bitmaps/load-bitmap.html
	public static Bitmap decodeSampledBitmapFromResource(File f,
	        int reqWidth, int reqHeight) {

	    // First decode with inJustDecodeBounds=true to check dimensions
	    final BitmapFactory.Options options = new BitmapFactory.Options();
	    options.inJustDecodeBounds = true;
	    BitmapFactory.decodeFile(f.getPath(), options);

	    // Calculate inSampleSize
	    options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

	    // Decode bitmap with inSampleSize set
	    options.inJustDecodeBounds = false;
	    return BitmapFactory.decodeFile(f.getPath(), options);
	}

	
	
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.button_save:
		{
			
			new AsyncTask<Void, Void, String>() {
	        	ProgressDialog progress = new ProgressDialog(ImageUploadActivity.this);
	    		protected void onPreExecute() {
	        		//called before starting the request
	        		//show a loader
	        		progress.setMessage(getString(R.string.loading));
	        		progress.setCancelable(false);
	        		progress.show();
	        	};
	        	protected String doInBackground(Void... params) {
	        		try {
	        			String ttl = titleET.getText().toString();
	        			String desc = descET.getText().toString();
	        			String tags = tagsET.getText().toString();
	        			
	        			File imageFile = new File(getPath(imageURI));
	        			newImage.compress(CompressFormat.JPEG, 100, new FileOutputStream(imageFile));
	        			
	        			//###################### EXERCISE 4 ####################################
	        			String response = uploadImageToConcert(getConcertKey(), ttl, desc, tags, imageFile);
	        			//###################### EXERCISE 4 ####################################
	        			
	        			if (response == null)
	        	    		return null;
	        	    	
	        			JSONObject json = new JSONObject(response);
	        			JSONObject jsonResponse = json.getJSONObject("response");
	        			JSONObject metadata = jsonResponse.getJSONObject("metadata");
	        			String status = metadata.getString("status");
	        			
	        			if (status.equals("success")) {
	        				return status;
	        			}
	        			else {
	        				return null;
	        			}
	        		} catch(Exception ex) {
	        			ex.printStackTrace();
	        			return null;
	        		}
	        	};
	        	protected void onPostExecute(String status) {
	        		//called when the request is done
	        		//check the result returned by doInBackground
	        		//hide the loader
	        		//update UI based on the result
	        		
	        		progress.dismiss();
	        		if(status == null) {
	        			//error
	        			new AlertDialog.Builder(ImageUploadActivity.this)
	        			.setTitle("Error")
	        			.setMessage("Could not upload image")
	        			.setPositiveButton("OK", new OnClickListener() {
	        			  
							public void onClick(DialogInterface dialog,
									int which) {
							}
	        			})
	        			.show();
	        		}
	        		else {
	        			new AlertDialog.Builder(ImageUploadActivity.this)
	        			.setTitle("Success")
	        			.setMessage("Image uploaded successfully")
	        			.setPositiveButton("OK", new OnClickListener() {
	        			 
							public void onClick(DialogInterface dialog,
									int which) {
						
							}
	        			})
	        			.show();
	        		}
	        	};
			}.execute();
		}
		}
	}
	
	private String getPath(Uri uri) {
		String projection[] = { MediaStore.Images.Media.DATA };
		Cursor cursor = ImageUploadActivity.this.getContentResolver().query(uri, projection, null, null, null);
		if (cursor != null) {
			//
			// HERE YOU WILL GET A NULLPOINTER IF CURSOR IS NULL
			// THIS CAN BE, IF YOU USED OI FILE MANAGER FOR PICKING THE MEDIA
			int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
			cursor.moveToFirst();
			return cursor.getString(column_index);
		}
		return uri.getPath();
	}
	
	public Uri getImageURI() {
		return imageURI;
	}
	public void setImageURI(Uri imageURI) {
		this.imageURI = imageURI;
	}

	public String getConcertKey() {
		return concertKey;
	}

	public void setConcertKey(String concertKey) {
		this.concertKey = concertKey;
	}
	
	
	
	
	
	//###################### EXERCISE 4 ####################################
	private String uploadImageToConcert (String concertKey, String title, String description,
			String tags, File imageFile) throws Exception {
		
		
		
		/**
		 * 1- initialize apstrata client
		 */
		ApstrataClientAndroid client = new ApstrataClientAndroid
				(Constants.BASE_URL, Constants.AUTH_KEY, Constants.SECRET, AuthMode.SIMPLE);
		
		/**
		 * 2- create list of parameters
		 * 
		 * example: key : value
		 * "apsdb.schema" : "concert_image"
		 * "concert", concertKey
		 * "title" : title
		 * "description" : description
		 * "tags" : tags
		 */
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		parameters.add(new BasicNameValuePair("apsdb.schema", "concert_image"));
		parameters.add(new BasicNameValuePair("concert", getConcertKey()));
		parameters.add(new BasicNameValuePair("title", title));
		parameters.add(new BasicNameValuePair("description", description));
		parameters.add(new BasicNameValuePair("tags", tags));
		
		/**
		 * 3- create files hashmap
		 * 
		 * i.e. "picture" : List<File> containing imageFile
		 */
	
		Map <String, List<File>> files = new HashMap <String, List<File>>();
		List<File> list = new ArrayList<File>();
		list.add(imageFile);
		files.put("picture", list);
		
		/**
		 * 4- call apstrata api: callAPIJson
		 * methodname is SaveDocument
		 */
		
		String response = client.callAPIJson("SaveDocument", parameters, files);
		
		return response;
	}
	
	
	
}
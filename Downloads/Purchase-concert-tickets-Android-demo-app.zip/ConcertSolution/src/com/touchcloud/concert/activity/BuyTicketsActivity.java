package com.touchcloud.concert.activity;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import com.apstrata.client.android.ApstrataClientAndroid;
import com.apstrata.client.android.ApstrataClientAndroid.AuthMode;
import com.touchcloud.concert.Concert;
import com.touchcloud.concert.Constants;
import com.touchcloud.concert.ImageDownloader;
import com.touchcloud.concert.R;
import com.touchcloud.concert.R.id;
import com.touchcloud.concert.R.layout;
import com.touchcloud.concert.R.string;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class BuyTicketsActivity extends Activity {
	protected static final String CONCERT = "concert";
	protected static final String IMAGE = "image";
	private Concert selectedConcert;
	
	private ImageView concertIV;
	private TextView captionTV;
	private EditText ticketCountET;
	private TextView totalCostTV;
	
	private int ticketCount;
	private ImageDownloader imdownloader = new ImageDownloader();
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_buytickets);
	    
	    setSelectedConcert((Concert) getIntent().getSerializableExtra(CONCERT));
	    
	    concertIV = (ImageView)findViewById(R.id.iv_concertimage);
		
	    imdownloader.downloadImageAsync(getIntent().getStringExtra(IMAGE), concertIV);
		
	    captionTV = (TextView)findViewById(R.id.tv_concertcaption);
	    ticketCountET = (EditText)findViewById(R.id.et_ticketcount);
	    totalCostTV = (TextView)findViewById(R.id.tv_totalcost);
	    
	    captionTV.setText(selectedConcert.getTitle());
	    
	    ticketCount = 0;
	    totalCostTV.setText("0.0");
	    
	    ticketCountET.setText(""+ticketCount);
	    
	    ticketCountET.addTextChangedListener(new TextWatcher(){
	        public void afterTextChanged(Editable s) {
	            if ((Integer.parseInt(ticketCountET.getText().toString())) < 0) {
	            	ticketCount = 0;
	            	ticketCountET.setText(""+ticketCount);
	            }
	            else if ((Integer.parseInt(ticketCountET.getText().toString())) > 99) {
	            	ticketCount = 99;
	            	ticketCountET.setText(""+ticketCount);
	            }
	            else {
	            	ticketCount = Integer.parseInt(ticketCountET.getText().toString());
	            }
	            
	    	    double totalCost = ticketCount * selectedConcert.getTicketPrice();
	    	    totalCostTV.setText(""+totalCost);
	        }
	        public void beforeTextChanged(CharSequence s, int start, int count, int after){}
	        public void onTextChanged(CharSequence s, int start, int before, int count){}
	    }); 
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.button_ticketsup:
		{
			if (ticketCount < 99) {
				ticketCount++;
				ticketCountET.setText(""+ticketCount);
			}
			break;
		}
		case R.id.button_ticketsdown:
		{
			if (ticketCount > 0) {
				ticketCount--;
				ticketCountET.setText(""+ticketCount);
			}
			break;
		}
		case R.id.button_buy:
			if (ticketCount > 0) {
				new AsyncTask<Void, Void, String>() {
		        	ProgressDialog progress = new ProgressDialog(BuyTicketsActivity.this);
		    		protected void onPreExecute() {
		        		//called before starting the request
		        		//show a loader
		        		progress.setMessage(getString(R.string.loading));
		        		progress.setCancelable(false);
		        		progress.show();
		        	};
		        	protected String doInBackground(Void... params) {
		        		try {
		        			TelephonyManager tMgr = (TelephonyManager)BuyTicketsActivity.this.getSystemService(Context.TELEPHONY_SERVICE);
		    				String msisdn = tMgr.getLine1Number();
		    				String name = "Test User";
		    				String unitPrice = "" + selectedConcert.getTicketPrice();
		    				String quantity = "" + ticketCount; 
		    				String concertTitle = selectedConcert.getTitle();
		    				
		    				String response = buyConcertTicket(msisdn, name, unitPrice, quantity, concertTitle);
		    				
		        			if (response == null)
		        	    		return null;
		        	    	
		        			JSONObject json = new JSONObject(response);
		        			JSONObject jsonResponse = json.getJSONObject("response");
		        			JSONObject result = jsonResponse.getJSONObject("result");
		        			String status = result.getString("status");
		        			
		        			if (status.equals("success")) {
		        				return status;
		        			}
		        			else {
		        				return null;
		        			}
		        		} catch(Exception ex) {
		        			ex.printStackTrace();
		        			return null;
		        		}
		        	};
		        	protected void onPostExecute(String status) {
		        		//called when the request is done
		        		//check the result returned by doInBackground
		        		//hide the loader
		        		//update UI based on the result
		        		
		        		progress.dismiss();
		        		if(status == null) {
		        			//error
		        			new AlertDialog.Builder(BuyTicketsActivity.this)
		        			.setTitle("Error")
		        			.setMessage("Could not buy ticket(s)")
		        			.setPositiveButton("OK", new OnClickListener() {
		        			 
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub
								}
		        			})
		        			.show();
		        			
		        		}
		        		else {
		        			new AlertDialog.Builder(BuyTicketsActivity.this)
		        			.setTitle("Success")
		        			.setMessage("Tickets bought successfully")
		        			.setPositiveButton("OK", new OnClickListener() {
		        			  
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub
								}
		        			})
		        			.show();
		        		}
		        	};
				}.execute();
			}
			break;
		}
	}
	
	//###################### EXERCISE 2 ####################################
	private String buyConcertTicket (String msisdn, String name, String unitPrice, String quantity, String concertTitle) throws Exception
	{
		/**
		 * 1- initialize apstrata client 
		 */
		ApstrataClientAndroid client = new ApstrataClientAndroid
		(Constants.BASE_URL, Constants.AUTH_KEY, Constants.SECRET, AuthMode.SIMPLE);
		
		/**
		 * 2- create list of parameters
		 * 
		 * keys : values
		 * "apsdb.scriptName" = "app.buyTickets"
		 * "name" : name
		 * "msisdn" : msisdn
		 * "unitPrice" : unitPrice
		 * "quantity" : quantity
		 * "concertTitle" : concertTitle
		 */
		
		
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		parameters.add(new BasicNameValuePair("apsdb.scriptName", "app.buyTickets"));
		parameters.add(new BasicNameValuePair("name", name));
		parameters.add(new BasicNameValuePair("msisdn", msisdn));
		parameters.add(new BasicNameValuePair("unitPrice", unitPrice));
		parameters.add(new BasicNameValuePair("quantity", quantity));
		parameters.add(new BasicNameValuePair("concertTitle", concertTitle));
		
		/**
		 * 3- call apstrata api callAPIJson
		 * methodname is RunScript
		 * 
		 */
		
		String response = client.callAPIJson("RunScript", parameters, null);
		
		return response;
	}
	
	public Concert getSelectedConcert() {
		return selectedConcert;
	}

	public void setSelectedConcert(Concert selectedConcert) {
		this.selectedConcert = selectedConcert;
	}
}
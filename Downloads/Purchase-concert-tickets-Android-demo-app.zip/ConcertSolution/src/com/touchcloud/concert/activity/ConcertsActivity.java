package com.touchcloud.concert.activity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.apstrata.client.android.ApstrataClientAndroid;
import com.apstrata.client.android.ApstrataClientAndroid.AuthMode;
import com.touchcloud.concert.Concert;
import com.touchcloud.concert.Constants;
import com.touchcloud.concert.ImageDownloader;
import com.touchcloud.concert.R;

public class ConcertsActivity extends Activity {
	private String requestType;
	private BaseAdapter mAdapter;
	private ApstrataClientAndroid client;
	private ImageDownloader imdownloader = new ImageDownloader();
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_concerts);

		Intent intent = getIntent();
		requestType = intent.getStringExtra(Constants.REQUEST);
		
		new AsyncTask<Void, Void, ArrayList<Concert>>() {
			ProgressDialog progress = new ProgressDialog(ConcertsActivity.this);
			protected void onPreExecute() {
				//called before starting the request
				//show a loader
				progress.setMessage(getString(R.string.loading));
				progress.setCancelable(false);
				progress.show();
			};
			protected ArrayList<Concert> doInBackground(Void... params) {
				try {
					String response = getConcerts();
					
					if (response == null)
						return null;

					JSONObject json = new JSONObject(response);
					JSONObject jsonResponse = json.getJSONObject("response");
					JSONObject metadata = jsonResponse.getJSONObject("metadata");
					String status = metadata.getString("status");

					if (status.equals("success")) {
						JSONObject result = jsonResponse.getJSONObject("result");
						JSONArray documents = result.getJSONArray("documents");
						ArrayList<Concert> concerts = new ArrayList<Concert>();
						for (int i=0; i<documents.length(); i++) {
							JSONObject doc = documents.getJSONObject(i);
							Concert concert = new Concert();
							concert.setKey(doc.getString("key"));
							concert.setTitle(doc.getString("title"));
							concert.setTicketPrice(doc.getDouble("ticketPriceLL"));
							concert.setPicture(doc.getString("picture"));
							
							List<NameValuePair> picParams = new ArrayList<NameValuePair>();
							picParams.add(new BasicNameValuePair("apsdb.fileName", concert.getPicture()));
							picParams.add(new BasicNameValuePair("apsdb.fieldName", "picture"));
							picParams.add(new BasicNameValuePair("apsdb.documentKey", concert.getKey()));

							String pictureURL = client.getFullUrl("GetFile", picParams);
							
							Log.v("cloud", "pictureURL:"+pictureURL);
							concert.setPictureUrl(pictureURL);

							concert.setDescription(doc.getString("description"));

							String dateString = doc.getString("date");  
							SimpleDateFormat  format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZZ");  
							Date date = format.parse(dateString);  
							concert.setDate(date);

							concert.setDocumentKey(doc.getString("apsdb.documentKey"));
							concerts.add(concert);
						}
						return concerts;
					}
					else {
						return null;
					}
				} catch(Exception ex) {
					ex.printStackTrace();
					return null;
				}
			};
			protected void onPostExecute(final ArrayList<Concert> concerts) {
				//called when the request is done
				//check the result returned by doInBackground
				//hide the loader
				//update UI based on the result

				progress.dismiss();
				if(concerts == null) {
					//error
					new AlertDialog.Builder(ConcertsActivity.this)
					.setTitle("Error")
					.setMessage("Could not load concerts")
					.setPositiveButton("OK", new OnClickListener() {
					
						public void onClick(DialogInterface dialog,
								int which) {
							// TODO Auto-generated method stub
						}
					})
					.show();
				}
				else {
					//update ui

					ListView listView = (ListView) findViewById(R.id.list_concerts);

					// Define a new Adapter
					// First parameter - Context
					// Second parameter - Layout for the row
					// Third parameter - ID of the TextView to which the data is written
					// Fourth - the Array of data

					mAdapter = new BaseAdapter() {
						@Override
						public int getViewTypeCount() {
							return 1;
						}
						
						
						public View getView(int position, View convertView, ViewGroup parent) {
							if(convertView == null) {
								convertView = LayoutInflater.from(ConcertsActivity.this).inflate(R.layout.list_concert, null);
							}
							
							TextView concertTitleTV = (TextView) convertView.findViewById(R.id.tv_concert);
							concertTitleTV.setText(getItem(position).getTitle());
							ImageView concertIV = (ImageView) convertView.findViewById(R.id.img_concert);
							String url = concerts.get(position).getPictureUrl();
							imdownloader.downloadImageAsync(url, concertIV, mAdapter);
							return convertView;
						}
						
					
						public long getItemId(int position) {
							// TODO Auto-generated method stub
							return 0;
						}
						
						
						public Concert getItem(int position) {
							return concerts.get(position);
						}
						
						
						public int getCount() {
							return concerts.size();
						}
					};
					// Assign adapter to ListView
					listView.setAdapter(mAdapter); 

					listView.setOnItemClickListener(new OnItemClickListener() {
					
						public void onItemClick(AdapterView<?> adapterView, View view,
								int index, long arg3) {
							
							if (requestType.equals(Constants.REQ_BUY_TICKETS)) {
								Intent intent = new Intent(ConcertsActivity.this, BuyTicketsActivity.class);
								intent.putExtra(BuyTicketsActivity.CONCERT, (Concert)mAdapter.getItem(index));
								intent.putExtra(BuyTicketsActivity.IMAGE, ((Concert)mAdapter.getItem(index)).getPictureUrl());
								startActivity(intent);
							}
							else {
								Intent intent = new Intent(ConcertsActivity.this, ConcertGalleryActivity.class);
								intent.putExtra(ConcertGalleryActivity.CONCERT, ((Concert)mAdapter.getItem(index)).getDocumentKey());
								startActivity(intent);
							}
						}
					});
				}
			};
		}.execute();
	}


	//###################### EXERCISE 1 ####################################
	private String getConcerts() throws Exception{
		/**
		 * 1- initialize apstrata client 
		 */
	
		client = new ApstrataClientAndroid
		(Constants.BASE_URL, Constants.AUTH_KEY, Constants.SECRET, AuthMode.SIMPLE);
		
		/**
		 * 2-create list of parameters
		 * 
		 * keys : values
		 * "apsdb.query" : "apsdb.schema = \"concert\""
		 * "apsdb.queryFields" : "title, ticketPriceLL, picture, description, date, apsdb.documentKey"
		 */
		
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		parameters.add(new BasicNameValuePair("apsdb.query", "apsdb.schema = \"concert\""));
		parameters.add(new BasicNameValuePair("apsdb.queryFields", "title, ticketPriceLL, picture, description, date, apsdb.documentKey" ));
		
		/**
		 * call apstrata api callAPIJson
		 * methodname is Query
		 */
		
		String response = client.callAPIJson("Query", parameters, null);
		Log.v("cloud", "json response: "+ response);
		return response;
	}

}
package com.touchcloud.concert.activity;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.apstrata.client.android.ApstrataClientAndroid;
import com.apstrata.client.android.ApstrataClientAndroid.AuthMode;
import com.touchcloud.concert.Constants;
import com.touchcloud.concert.GalleryImage;
import com.touchcloud.concert.ImageDownloader;
import com.touchcloud.concert.R;
import com.touchcloud.concert.R.id;
import com.touchcloud.concert.R.layout;
import com.touchcloud.concert.R.string;
import android.util.Log;

public class ConcertGalleryActivity extends Activity {
	protected static final String CONCERT = "concert";
	protected static final int GALLERY_REQUEST_CODE = 111;
	protected static final int CAMERA_REQUEST_CODE = 222;
	private String concertKey;
	private ArrayAdapter<GalleryImage> mAdapter;
	private ImageDownloader imdownloader = new ImageDownloader();
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_concertgallery);
		setConcertKey((String) getIntent().getSerializableExtra(CONCERT));

		new AsyncTask<Void, Void, ArrayList<GalleryImage>>() {
			ProgressDialog progress = new ProgressDialog(ConcertGalleryActivity.this);
			//private ApstrataClientAndroid client;
			protected void onPreExecute() {
				//called before starting the request
				//show a loader
				progress.setMessage(getString(R.string.loading));
				progress.setCancelable(false);
				progress.show();
			};
			protected ArrayList <GalleryImage> doInBackground(Void... params) {
				try {
					//send the request
					
					//###################### EXERCISE 3 ####################################
					String response  = getConcertGallery(concertKey);
					//###################### EXERCISE 3 ####################################
					
					
					if (response == null)
						return null;


					JSONObject json = new JSONObject(response);
					JSONObject jsonResponse = json.getJSONObject("response");
					JSONObject metadata = jsonResponse.getJSONObject("metadata");
					String status = metadata.getString("status");
					
					if (status.equals("success")) {
						JSONObject result = jsonResponse.getJSONObject("result");
						JSONArray documents = result.getJSONArray("documents");
						ArrayList<GalleryImage> images = new ArrayList<GalleryImage>();
						for (int i=0; i<documents.length(); i++) {
							JSONObject doc = documents.getJSONObject(i);
							GalleryImage image = new GalleryImage();
							image.setKey(doc.getString("key"));
							image.setPicture(doc.getString("picture"));
							
							List<NameValuePair> picParams = new ArrayList<NameValuePair>();
							picParams.add(new BasicNameValuePair("apsdb.fileName", image.getPicture()));
							picParams.add(new BasicNameValuePair("apsdb.fieldName", "picture"));
							picParams.add(new BasicNameValuePair("apsdb.documentKey", image.getKey()));
							ApstrataClientAndroid client = new ApstrataClientAndroid
									(Constants.BASE_URL, Constants.AUTH_KEY, Constants.SECRET, AuthMode.SIMPLE);
							String pictureURL = client.getFullUrl("GetFile", picParams);
							image.setPictureUrl(pictureURL);

							image.setTitle(doc.getString("title"));
							images.add(image);
						}
						return images;
					}
					else {
						return null;
					}
				} catch(Exception ex) {
					ex.printStackTrace();
					return null;
				}
			};
			protected void onPostExecute(final ArrayList<GalleryImage> images) {
				//called when the request is done
				//check the result returned by doInBackground
				//hide the loader
				//update UI based on the result
				progress.dismiss();
				if(images == null) {
					//error
        			new AlertDialog.Builder(ConcertGalleryActivity.this)
        			.setTitle("Error")
        			.setMessage("Could not load concerts")
        			.setPositiveButton("OK", new OnClickListener() {
        			
						public void onClick(DialogInterface dialog,
								int which) {
							// TODO Auto-generated method stub
						}
        			})
        			.show();
				}
				else {
					//update ui
					GridView gridView = (GridView) findViewById(R.id.grid_images);
					// Define a new Adapter
					// First parameter - Context
					// Second parameter - Layout for the row
					// Third parameter - ID of the TextView to which the data is written
					// Forth - the Array of data
	        			mAdapter = new ArrayAdapter<GalleryImage> 
	        			(ConcertGalleryActivity.this, R.layout.item_gallery, R.id.tv_concertgallery, images) {
	        				LayoutInflater inflator = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	        				@Override
	        				public View getView(int position, View convertView,
	        						ViewGroup parent) {
	        					if(convertView == null) {
	        						convertView = inflator.inflate(R.layout.item_gallery, null);
	        					}
	        					TextView convetTitleTV = (TextView) convertView.findViewById(R.id.tv_concertgallery);
	    						convetTitleTV.setText(getItem(position).getTitle());
	    						
	    						ImageView galleryIV = (ImageView) convertView.findViewById(R.id.img_concertgallery);
								String url = images.get(position).getPictureUrl();
								imdownloader.downloadImageAsync(url, galleryIV, mAdapter);
								
								return convertView;
	        				}
	        			};
	        			// Assign adapter to ListView
	        			gridView.setAdapter(mAdapter); 
				}
			};
		}.execute();
	}

	//this is a temp file to save any captured image
    File photo;
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.button_uploadimage:
		{
			CharSequence [] items = {"Capture", "Choose from library"};
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
		
			
			builder.setTitle("Upload Image")
			.setItems(items, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int item) {
                	if (item == 0) {
						try {
	                		Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	                		photo = File.createTempFile("image", "jpg");
	                	    Uri outputFileUri = Uri.fromFile(photo);
	                	    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
	                	    startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
						} catch (IOException e) {
							// an error has occurred
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                	}
                	else {
                		Intent intent = new Intent();
                	    intent.setType("image/*");
                	    intent.setAction(Intent.ACTION_GET_CONTENT);
                	    startActivityForResult(Intent.createChooser(intent, "Select Picture"), 
                	    		GALLERY_REQUEST_CODE);
                	}
                } 
            })
			.show();
			break;
		}
		}
    }
	
	protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) { 
		super.onActivityResult(requestCode, resultCode, imageReturnedIntent); 
		switch(requestCode) {
		case CAMERA_REQUEST_CODE:
		    if(resultCode == RESULT_OK){  
		        Intent intent = new Intent(this, ImageUploadActivity.class);
				intent.putExtra(ImageUploadActivity.IMAGEURI, Uri.fromFile(photo));
				intent.putExtra(ImageUploadActivity.CONCERT, getConcertKey());
				startActivity(intent);
		    }

		break; 
		case GALLERY_REQUEST_CODE:
		    if(resultCode == RESULT_OK){  
		        Uri selectedImage = imageReturnedIntent.getData();
		        Intent intent = new Intent(this, ImageUploadActivity.class);
				intent.putExtra(ImageUploadActivity.IMAGEURI, selectedImage);
				intent.putExtra(ImageUploadActivity.CONCERT, getConcertKey());
				startActivity(intent);
		    }
		break;
		}
	}
	
	
	//###################### EXERCISE 3 ####################################
	private String getConcertGallery(String concertKey) throws Exception{
		/**
		 * 1- initialize apstrata client 
		 */
		ApstrataClientAndroid client = new ApstrataClientAndroid
		(Constants.BASE_URL, Constants.AUTH_KEY, Constants.SECRET, AuthMode.SIMPLE);
		
		/**
		 * 2- create list of parameters
		 * 
		 * "apsdb.query" : "concert=\"" + concertKey + "\""
		 * "apsdb.queryFields" : "picture, title"
		 */
		
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		parameters.add(new BasicNameValuePair("apsdb.query", "concert=\"" + concertKey + "\""));
		parameters.add(new BasicNameValuePair("apsdb.queryFields", "picture, title" ));
		
		/**
		 * 3-call apstrata api callAPIJson
		 * methodname is Query
		 */
		
		String response = client.callAPIJson("Query", parameters, null);

		return response;
	}
	
	public String getConcertKey() {
		return concertKey;
	}

	public void setConcertKey(String concertKey) {
		this.concertKey = concertKey;
	}
}
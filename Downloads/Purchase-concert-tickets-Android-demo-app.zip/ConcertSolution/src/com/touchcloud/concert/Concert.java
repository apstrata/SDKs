package com.touchcloud.concert;

import java.io.Serializable;
import java.util.Date;

public class Concert implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8824085867396669588L;
	private String key; //concert key
	private String title; //concert title
	private double ticketPrice; //ticket price in LL
	private String description; //concert description
	private Date date; //concert date
	private String documentKey; //concert key
	private String picture; //concert image url
	private String pictureUrl;
		
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDocumentKey() {
		return documentKey;
	}
	public void setDocumentKey(String documentKey) {
		this.documentKey = documentKey;
	}
	public String getPictureUrl() {
		return pictureUrl;
	}
	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}
}

package com.touchcloud.concert;

public class ConcertImage {
	private String title; //image title
	private String description; //image description
	private String tags; //image tags
	private String concert; //concert key
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public String getConcert() {
		return concert;
	}
	public void setConcert(String concert) {
		this.concert = concert;
	}
}

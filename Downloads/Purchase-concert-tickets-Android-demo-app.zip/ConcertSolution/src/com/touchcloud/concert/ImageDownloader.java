package com.touchcloud.concert;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Hashtable;
import java.util.Vector;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.apstrata.client.android.ApstrataClientAndroid;


public class ImageDownloader {

	private  final int ImageCachelimit = 10;
	public  Vector<String> urls = new Vector<String>();
	public  Hashtable <String, ImageEntry> images = new Hashtable <String, ImageEntry> ();
	
	public synchronized void downloadImageAsync(final String url, ImageView target) {	
		downloadImageAsync(url, target, null);
	}

	public synchronized void downloadImageAsync(final String url, ImageView target, BaseAdapter mAdapter) {	
			ImageEntry	imageEntry = images.get(url);
			if(imageEntry == null){
				imageEntry = new ImageEntry();
				imageEntry.iv = target;
				images.put(url, imageEntry);
				urls.add(url);
				//Log.v("cloud", "image cache size: "+urls.size());
				if(urls.size() > ImageCachelimit){
					String turl = urls.remove(0);
					images.remove(turl);
				}
				new ImageDownloaderInternal(url, imageEntry, mAdapter).execute();
			}
			else if (imageEntry.status == ImageEntry.STATUS_DOWNLOADED && imageEntry.image != null) {
				target.setImageBitmap(imageEntry.image);
			}
			else {
				imageEntry.iv = target;
			}
		}

}


class ImageDownloaderInternal extends AsyncTask<Void, Void, ImageEntry> {
	ImageEntry mImageEntry;
	String mUrl;
	
	BaseAdapter mAdapter;
	//ImageView target;
	
	public ImageDownloaderInternal(String url, ImageEntry entry, BaseAdapter adapter) {
		////Log.v("cloud", "Created ImageDownloader(" + url.substring(0, 5) + ", " + entry.iv.toString() + ")");
		this.mUrl = url;
		this.mImageEntry = entry;
		this.mAdapter = adapter;
		//this.target = ptarget;
	}
	protected void onPreExecute() {
		//called before starting the request
	};
	
  
  static final int BUFF_SIZE = 1024;
  static final byte[] buffer = new byte[BUFF_SIZE];
  public static void copy(InputStream in, OutputStream out) throws IOException {
        try {
              while (true) {
                          synchronized (buffer) {
                          int amountRead = in.read(buffer);
                          if (amountRead == -1) {
                                break;
                          }
                          out.write(buffer, 0, amountRead);
                    }
              }
        }
        catch(Exception e){
              if (in != null) {
                    in.close();
              }
              if (out != null) {
                    out.close();
              }
        }
        finally { 
              if (in != null) {
                    in.close();
              }
             
        }
  } 



	protected ImageEntry doInBackground(Void... params) {
		try {
			InputStream imageStream = ApstrataClientAndroid.getStreamFromUrl(mUrl);
			//Drawable d = Drawable.createFromStream(imageStream, "src name");
			
//			final BufferedInputStream bis = new BufferedInputStream(imageStream);
            final ByteArrayOutputStream dataStream = new ByteArrayOutputStream();
//            BufferedOutputStream out = new BufferedOutputStream(dataStream);
            copy(imageStream, dataStream);
            //out.flush();
            final byte[] data = dataStream.toByteArray();
            Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length);
            imageStream.close(); 
            mImageEntry.image = bm;
			//mImageEntry.image  = BitmapFactory.decodeStream(imageStream);
			
//			Log.v("cloud", "Image size " +mImageEntry.image.getByteCount()/1024 + " K bytes");
			mImageEntry.status = ImageEntry.STATUS_DOWNLOADED;
			return mImageEntry;
			
		} catch (Exception e) {
			
			e.printStackTrace();
			mImageEntry.image = null;
			return mImageEntry;
		}catch (java.lang.OutOfMemoryError er){
			System.gc();
			mImageEntry.image = null;
			return mImageEntry;
		}
	};
	protected void onPostExecute(ImageEntry downloadedImage) {
		//called when the request is done
		//update UI based on the result
		if (downloadedImage.image == null) {
			//image download failed
//			mImageEntry.status = ImageEntry.STATUS_FAILED;
			mImageEntry.status = ImageEntry.STATUS_DOWNLOADED;
			downloadedImage.iv.setImageResource(R.drawable.ic_launcher);
			//downloadedImage.status = ImageEntry.STATUS_FAILED; 
		}
		else {
//			mImageEntry.status = ImageEntry.STATUS_DOWNLOADED;
			downloadedImage.status = ImageEntry.STATUS_DOWNLOADED;
			if(downloadedImage.iv!=null){
				//Log.v("cloud", "Image downloaded and target not null");
				downloadedImage.iv.setImageBitmap(downloadedImage.image);
				
			}
			if(mAdapter != null){
				//Log.v("cloud", "Image downloaded and adapter not null");
				mAdapter.notifyDataSetChanged();
			}
		
			
		}
	};

}

class ImageEntry {
	public static final int STATUS_DOWNLOADING = 0;
	public static final int STATUS_DOWNLOADED = 1;
	public static final int STATUS_FAILED = 2;
	public ImageView iv;
	public Bitmap image;
	public int status = STATUS_DOWNLOADING;
}

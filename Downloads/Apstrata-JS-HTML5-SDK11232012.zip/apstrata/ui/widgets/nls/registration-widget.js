define({ root:
//begin v1.x content
({
	ENTER_VALID_EMAIL: "Enter valid email address",
	EMAIL_ALREADY_REGISTERED: "Email already registered",
	LOGIN: "login?"
})
//end v1.x content
,
"fr": true,
"es": true,
"de": true,
"ar": true
});

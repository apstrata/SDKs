define({ root:
//begin v1.x content
({
	BAD_CREDENTIALS: "BAD CREDENTIALS"
})
//end v1.x content
,
"fr": true,
"es": true,
"de": true,
"ar": true
});

dojo.provide("apstrata.horizon.list.MultipleListContent")

dojo.require("apstrata.horizon.list.SimpleListContent")

dojo.declare("apstrata.horizon.list.MultipleListContent", [apstrata.horizon.list.SimpleListContent], {
	templatePath: dojo.moduleUrl("apstrata.horizon.list", "templates/MultipleListContent.html"),
	
})

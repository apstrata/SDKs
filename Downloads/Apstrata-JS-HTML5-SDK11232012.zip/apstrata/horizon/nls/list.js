define({ root:
//begin v1.x content
({
	CONFIRM_DELETE: "Are you sure you want to delete item: [${0}] ?",
	CONFIRM_EDIT: "Are you sure you want to change the label: [${0}] to [${1}] ?",
	TOOLTIP_DELETE_UNDELETE: "click to delete/undelete",
	TOOLTIP_DELETE: "click to delete",
	TOOLTIP_EDIT: "double-click to edit"
})
//end v1.x content
});

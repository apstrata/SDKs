/******************************************************************************* 
 *  Copyright 2009 apstrata
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://www.apache.org/licenses/LICENSE-2.0.html 
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 */


package apsdb.sample;

import java.io.File;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import apsdb.APSDBClientService;

public class GetFile {

	private static Logger	log	= Logger.getLogger(GetFile.class);

	public static void main(String[] args) {
		ResourceBundle configBundle = ResourceBundle.getBundle("apsdb/sample/credentials");
		String publicAccKey = configBundle.getString("PUBLIC_ACCESS_KEY");
		String privateAccKey = configBundle.getString("PRIVATE_ACCESS_KEY");

		APSDBClientService apClientService = new APSDBClientService(publicAccKey, privateAccKey, null);

		try {
			String storeName = "myStore";//TODO: replace by a valid store name
			String documentKey = "docKey";//TODO: replace by a valid document key
			/**
			 ************************************************ 
			 ************ GET FILE FROM DOCUMENT ************
			 ************************************************ 
			 */

			String fileAddress = apClientService.getFileURL(storeName, documentKey, "FieldFile", false);
			printMsg("Get file status: successful, File address: " + fileAddress);

			printMsg("Will download the file");
			String destinationPath = "c:/downloadedSunSet.jpg";
			File tmpFile = new File(destinationPath);
			tmpFile.delete();
			apClientService.getFile(storeName, documentKey, "FieldFile", destinationPath, true);
		} catch (Exception e) {
			log.error("", e);
		}

	}

	private static void printMsg(String msg) {
		System.out.println(msg);
	}
}

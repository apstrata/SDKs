/*******************************************************************************
 * Copyright 2009 apstrata Licensed under the Apache License, Version 2.0 (the "License");
 * 
 * You may not use this file except in compliance with the License. You may obtain a copy of the License at:
 * http://www.apache.org/licenses/LICENSE-2.0.html This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License. *****************************************************************************
 */

package apsdb.sample;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import apsdb.APSDBClientService;
import apsdb.request.SaveDocumentRequest;
import apsdb.response.SaveDocumentResponse;

public class SaveDocument {

	private static Logger	log	= Logger.getLogger(SaveDocument.class);

	public static void main(String[] args) {

		ResourceBundle configBundle = ResourceBundle.getBundle("apsdb/sample/credentials");
		String publicAccKey = configBundle.getString("PUBLIC_ACCESS_KEY");
		String privateAccKey = configBundle.getString("PRIVATE_ACCESS_KEY");

		APSDBClientService apClientService = new APSDBClientService(publicAccKey, privateAccKey, null);

		try {

			String storeName = "myStore";//TODO: replace by a valid store name

			/**
			 ********************************************** 
			 ************ SAVING A DOCUMENT ***************
			 ********************************************** 
			 */
			SaveDocumentRequest saveDocumentRequest = new SaveDocumentRequest(storeName, null);
			saveDocumentRequest.addField("FieldName_1", "FieldValue1");
			saveDocumentRequest.addField("FieldName_1", "FieldValue2");

			saveDocumentRequest.addField("FieldName_3", "FieldValue3");
			saveDocumentRequest.addFile("FieldFile", "C:/Sunset.jpg", false);

			SaveDocumentResponse saveDocumentResponse = apClientService.saveDocument(saveDocumentRequest);

			// making sure that operation went well
			printMsg("Save document status: " + saveDocumentResponse.getStatus());
			printMsg("Save document Message: " + saveDocumentResponse.getMessage());
			if(saveDocumentResponse.getStatus().equals("success"))
			{
				printMsg("Document Key: " + saveDocumentResponse.getDocumentKey());
			}

			/**
			 ********************************************** 
			 ************ UPDATING A DOCUMENT *************
			 ********************************************** 
			 */
			if(saveDocumentResponse.getStatus().equals("success"))
			{
				String documentKey = saveDocumentResponse.getDocumentKey();
				saveDocumentRequest = new SaveDocumentRequest(storeName, documentKey);
				// new field
				saveDocumentRequest.addField("FieldName_4", "FieldValue4");
				// adding another value for existing field
				saveDocumentRequest.addField("FieldName_5", "FieldValue_5");
	
				saveDocumentResponse = apClientService.saveDocument(saveDocumentRequest);
	
				// making sure that operation went well
				printMsg("Update document status: " + saveDocumentResponse.getStatus());
			}
		} catch (Exception e) {
			log.error("", e);
		}

	}

	private static void printMsg(String msg) {
		System.out.println(msg);
	}
}

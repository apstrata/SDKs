/******************************************************************************* 
 *  Copyright 2009 apstrata
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://www.apache.org/licenses/LICENSE-2.0.html 
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 */


package apsdb.sample;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import apsdb.APSDBClientService;
import apsdb.response.DeleteDocumentResponse;

public class DeleteDocument {

	private static Logger	log	= Logger.getLogger(DeleteDocument.class);

	public static void main(String[] args) {
		ResourceBundle configBundle = ResourceBundle.getBundle("apsdb/sample/credentials");
		String publicAccKey = configBundle.getString("PUBLIC_ACCESS_KEY");
		String privateAccKey = configBundle.getString("PRIVATE_ACCESS_KEY");
		APSDBClientService apClientService = new APSDBClientService(publicAccKey, privateAccKey, null);

		try {

			String storeName = "myStore";//TODO: replace by a valid store name
			String documentKey = "docKey";//TODO: replace by a valid document key
			/**
			 ********************************************** 
			 ************ DELETING A DOCUMENT *************
			 ********************************************** 
			 */
			DeleteDocumentResponse deleteDocumentResponse = apClientService.deleteDocument(storeName, documentKey);
			// making sure that operation went well
			printMsg("Delete document status: " + deleteDocumentResponse.getStatus());
			printMsg("Message: " + deleteDocumentResponse.getMessage());

		} catch (Exception e) {
			log.error("", e);
		}

	}

	private static void printMsg(String msg) {
		System.out.println(msg);
	}
}

/******************************************************************************* 
 *  Copyright 2009 apstrata
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://www.apache.org/licenses/LICENSE-2.0.html 
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 */

package apsdb.sample;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import apsdb.APSDBClientService;
import apsdb.response.CreateStoreResponse;

public class CreateStore {

	private static Logger	log	= Logger.getLogger(CreateStore.class);

	public static void main(String[] args) {

		ResourceBundle configBundle = ResourceBundle.getBundle("apsdb/sample/credentials");
		String publicAccKey = configBundle.getString("PUBLIC_ACCESS_KEY");
		String privateAccKey = configBundle.getString("PRIVATE_ACCESS_KEY");

		APSDBClientService apClientService = new APSDBClientService(publicAccKey, privateAccKey, null);

		try {
			/**
			 ********************************************** 
			 ************ CREATING A STORE ****************
			 ********************************************** 
			 */
			String storeName = "myStore";//TODO: replace by a valid store name
			CreateStoreResponse createStoreResponse = apClientService.createStore(storeName);

			// making sure that the operation was successful
			printMsg("Creating store status: " + createStoreResponse.getStatus());
			printMsg("Message: " + createStoreResponse.getMessage());

		} catch (Exception e) {
			log.error("", e);
		}

	}

	private static void printMsg(String msg) {
		System.out.println(msg);
	}
}

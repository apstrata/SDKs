/******************************************************************************* 
 *  Copyright 2009 apstrata
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://www.apache.org/licenses/LICENSE-2.0.html 
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 */


package apsdb.sample;

import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import apsdb.APSDBClientService;
import apsdb.common.Document;
import apsdb.common.DocumentField;
import apsdb.request.QueryRequest;
import apsdb.response.QueryResponse;

public class Query {

	private static Logger	log	= Logger.getLogger(Query.class);

	public static void main(String[] args) {

		ResourceBundle configBundle = ResourceBundle.getBundle("apsdb/sample/credentials");
		String publicAccKey = configBundle.getString("PUBLIC_ACCESS_KEY");
		String privateAccKey = configBundle.getString("PRIVATE_ACCESS_KEY");

		APSDBClientService apClientService = new APSDBClientService(publicAccKey, privateAccKey, null);

		try {
			String storeName = "myStore";//TODO: replace by a valid store name
			/**
			 ************************************************ 
			 **************** QUERY DOCUMENTS ***************
			 ************************************************ 
			 */

			QueryRequest queryRequest = new QueryRequest(storeName);
			queryRequest.addFieldToSelect("FieldName_1");
			queryRequest.addFieldToSelect("FieldName_5");

			queryRequest.setQuery("FieldName_1[string]=\"FieldValue2\"");
			QueryResponse quResponse = apClientService.query(queryRequest);
			printMsg("Query status: " + quResponse.getStatus());
			printMsg("Query Message: " + quResponse.getMessage());
			for (Document doc : quResponse.getDocuments()) {
				printMsg("Document Key: " + doc.getDocumentKey());
				List<DocumentField> fields = doc.getFields();
				for (DocumentField field : fields) {
					printMsg(" -- Field Name: " + field.getName() + " Field Value: " + field.getValues().get(0));
				}
			}

		} catch (Exception e) {
			log.error("", e);
		}

	}

	private static void printMsg(String msg) {
		System.out.println(msg);
	}
}

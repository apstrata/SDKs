/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.Menu")

dojo.require("dojo.store.Memory")
dojo.require("apstrata.horizon.Menu")

dojo.declare("apstrata.workbench.Menu", 
[apstrata.horizon.Menu], 
{
	items: [],
	
	
	constructor: function(args) {
		var self = this
		//
		// widget attributes
		//
		this.filterable = false;
		this.sortable = false;
		this.editable = false;
		
		dojo.mixin(this.items, [
				  			{	
								id:"overview", 
								label: "Overview", 
								iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/home.png",
								panelClass: "apstrata.workbench.Overview"
							},
							{
								id:"apiExplorer", 
								label: "API Explorer", 
								iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/right-left.png", 
								panelClass: "apstrata.workbench.apiExplorer.APIExplorerMenu"
							},
							{
								id:"manage", 
								label: "Manage Account", 
								iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/user-admin.png", 
								panelClass: "apstrata.workbench.manageAccount.ManageAccountMenu"
							}//,
//							{
//								id:"widgets", 
//								label: "Widgets", 
//								iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/picture.png", 
//								panelClass: "apstrata.horizon.blue.ApstrataMenu"
//							}
					]);
		

		this.store = new dojo.store.Memory({data: self.items});
	},
	
	startup: function() {
		
		//dojo.require("apstrata.horizon.blue.Home")
		//var a = this.openPanel(apstrata.horizon.blue.Home)
		//a.deferred.then(function() {
		//	console.debug(a.id +' done')
		//})
		
		this.inherited(arguments)
	},
	
	onClick: function(index, id, args) {
		if (id == 'logout') {
			this.getContainer().logout();;
		} else {
			this.inherited(arguments);
		}
	}
})



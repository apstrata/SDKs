/*******************************************************************************
 *  Copyright 2009-2011 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.ApplicationDetails");

dojo.require("apstrata.sdk.ObjectStore");
dojo.require("apstrata.sdk.Client");
dojo.require("dojox.grid.EnhancedGrid");
dojo.require("dojox.form.FileInput");
dojo.require("dijit.form.Form");

dojo.require("apstrata.horizon.PanelAlert");

dojo.require("apstrata.workbench.manageAccount.ChannelDetails");

dojo.declare("apstrata.workbench.manageAccount.ApplicationDetails", 
[apstrata.horizon.Panel], 
{

	widgetsInTemplate: true,
	templatePath: dojo.moduleUrl("apstrata.workbench.manageAccount", "templates/ApplicationDetails.html"),
	
	constructor: function(attrs) {
		this.attrs = {};
		if (attrs){
			this.attrs = attrs;
			this.application = attrs.application;
			this.backup = dojo.clone(this.application);
			this.docStore = attrs.docStore;		
		}
				
		if (!this.docStore) {
			this.docStore = 'DefaultStore';
		}
		
		this._buildStore();
	},	
	
	postCreate: function() {		
		var form = new dijit.form.Form();
		this.dvForm.set("encType", "multipart/form-data");
		if (this.attrs.isNewApplication){
			this._editApplication();			
		}else {
			this.applicationID.set("value", this.attrs.application.applicationID);
			this.password.set("value", this.attrs.application.password);
			this.certificate.innerHTML = "<a id='certificateLink' href='" + this._getCertificate() + "' target='_blank'>Certificate</a>";
		};
		
		this._createGrid();
		
		dojo.connect(this.editApplicationButton, "onClick", dojo.hitch(this, "_editApplication"));
		dojo.connect(this.addChannelButton, "onClick", dojo.hitch(this, "_addChannel"));
		dojo.connect(this.removeChannelButton, "onClick", dojo.hitch(this, "_removeChannel"));
		dojo.connect(this.cancelChangesButton, "onClick", dojo.hitch(this, "_cancelChanges"));
		dojo.connect(this.saveChangesButton, "onClick", dojo.hitch(this, "_saveChanges"));	
		this.inherited(arguments);
	},
	
	startup: function() {
		this.inherited(arguments);
	},
	
	onClick: function(event) {
		this._onGridRowSelected(event);
	},
	
	/*
	 * This method is called by the child panel (containing the details of the selected channel)
	 * when its content is updated ('save' is clicked and changes have been sent to the server) 
	 */
	refreshContent: function() {
		
		this.grid.store.close();		
		this._buildStore();
		this.grid.setStore(new apstrata.sdk.ObjectStoreAdaptor({objectStore: this.store}));		
	},
	
	_buildStore: function() {
				
		var applicationID =  this.attrs.isNewApplication ? "" : this.attrs.application.applicationID;
		var docStore = this.attrs.docStore ? this.attrs.docStore : "DefaultStore";
		this.store = new apstrata.sdk.ObjectStore(
				{
					store : this.docStore,
					connection : this.container.connection,
					queryFields : "key, platform, lifetime, applicationID, deviceTokens",
					queryExpression : "applicationID = \"" + applicationID + "\" and platform is not null"
				});
		
	},

	/*
	 * Open a new panel containing the selected channel instance (from the selected row).
	 * Switch the visibility of the remove channel ("-") button to visible in order to 
	 * enable the user to remove the selected channel
	 */
	_onGridRowSelected: function(event) {
		var self = this;
		
		dojo.style(this.removeChannelButton.domNode, "display", "inline");	
		dojo.style(this.cancelChangesButton.domNode, "display", "inline");
		this.candidateRow = event.rowIndex;

		var channel = self.grid.getItem(event.rowIndex);		
		if (channel){
			if (channel.deviceTokens){
				channel.deviceTokensAsObjects = [];
					if (dojo.isArray(channel.deviceTokens)){
						dojo.forEach(channel.deviceTokens, function(token, index){
							channel.deviceTokensAsObjects[index] = {'token' : token, 'index' :index};
						});
				}else {
					channel.deviceTokensAsObjects[0] = { 'token' : channel.deviceTokens, 'index' : 0};
				}
			}
			
			self.attrs = dojo.mixin(self.attrs, {isNewChannel : false});
			self.openPanel(apstrata.workbench.manageAccount.ChannelDetails,{channel : channel, attrs : self.attrs, docStore : self.attrs.docStore});
		}
	},
	
	/*
	 * Create the grid that will contain the list of the channels of the current application
	 */
	_createGrid: function() {
		var self = this;
		self.grid = new dojox.grid.EnhancedGrid( 
				{					
					structure : [
					             {'name': 'Channel Id', 'field': 'key', 'width': 'auto'},                             
	                             {'name': 'Platform', 'field': 'platform'},
	                             {'name': 'Life time', 'field': 'lifetime'},	
	                             {'name': 'Device Tokens', 'field': 'deviceTokens', 'hidden': true}                                                                                    
			                 ],
			        clientSort: true,			       
			        style: 'height:100%'
				});
		
		dojo.connect(self.grid, "onRowClick", dojo.hitch(self, "_onGridRowSelected"));
				
		self.grid.setStore(new apstrata.sdk.ObjectStoreAdaptor({objectStore: self.store}));
		self.grid.startup();
		dojo.place(self.grid.domNode, self.gridDiv)
	},
	
	/*
	 * Open a new panel for entering channel information. The opened panel
	 * will contain an empty channel instance with a default life-time of '5'
	 * an applicationID equal to the current application's id.
	 * You can only add a channel if the application already existed or if 
	 * it was saved.
	 */
	_addChannel: function() {
		var self = this;
		var isValid = this.dvForm.validate();
		if (this.attrs.isNewApplication){
			this._alert("You first need to save your changes");
		}
		
		if (isValid) {		
			var self = this;
			var channel = {
				channelId : '',
				platform : '',
				lietie : 5,
				applicationID : this.applicationID.get("value"),
				deviceTokens : [],
				deviceTokensAsObjects : [{}]
			};
			self.attrs = dojo.mixin(self.attrs, {isNewChannel : true});
			self.openPanel(apstrata.workbench.manageAccount.ChannelDetails,{channel : channel, attrs : self.attrs});
		}
	},
	
	/*
	 * Remove the selected row from the grid and store, then close the corresponding child panel.
	 * The user will get a dialog box and changes will be effective as soon as the user clicks on "OK"
	 */
	_removeChannel: function(event) {
		var self = this;
				
		// The function that actually takes care of removing the channel. It is passed as 
		// a callback to the confirmation panel
		var removeChannelImpl = function() {
		
			if (self.candidateRow >= 0){
				
				var channel = self.grid.getItem(self.candidateRow);
				if (channel){
					
					self._callApi("RemoveChannel", {"channelId":channel.key}).then(
						
						function(response) {
							
							self.grid.store.deleteItem(channel);
							self.closePanel();
							self.candidateRow = -1;							
							dojo.style(self.saveChangesButton.domNode, "display", "inline");
							dojo.style(self.removeChannelButton.domNode, "display", "none");
							dojo.style(self.cancelChangesButton.domNode, "display", "inline");
						},
						
						function(response) {
							
							if (typeof(response) == "string") {
								self._alert(response);
							}else {
								var error = response.metadata.errorDetail ? response.metadata.errorDetail : response.metadata.errorCode
								self._alert(error);
							}
						}
					);							
					
				}
			}		
		}
		
		this._confirm("Are you sure you want to remove this channel?", removeChannelImpl, {});	
	},
	
	/*
	 * Switch the panel to edit mode
	 */
	_editApplication: function() {
		if (this.attrs.isNewApplication){
			this.applicationID.set("readOnly", false);
		}
		
		this.password.set("readOnly", false);
		dojo.style(this.certificateFile.domNode, "display", "block");
		dojo.style(this.saveChangesButton.domNode, "display", "inline");
		dojo.style(this.addChannelButton.domNode, "display", "inline");
		dojo.style(this.cancelChangesButton.domNode, "display", "inline");
		dojo.style(this.editApplicationButton.domNode, "display", "none");
		dojo.style(this.editApplicationButton.domNode, "display", "none");		
	},
	
	/*
	 * Undo the changes that were done by the user (of course if he did not click on "save" before).
	 * Reset the visibility of the buttons to its initial value.
	 * Reset the file upload widget  
	 * Reset the store
	 * Close the child panel if it was opened
	 */
	_cancelChanges: function() {	
		var self = this;
		
		if (this.attrs.isNewApplication){
			this.close();
		}else {
		
			this.applicationID.set("readOnly", true);		
			this.password.set("readOnly", true);
			this.password.set("value", this.backup.password)
			dojo.style(this.certificateFile.domNode, "display", "none");
			dojo.style(this.cancelChangesButton.domNode, "display", "none");
			dojo.style(this.addChannelButton.domNode, "display", "none");
			dojo.style(this.removeChannelButton.domNode, "display", "none");
			dojo.style(this.editApplicationButton.domNode, "display", "inline");
			
			// Remove any newly attached certificate
			this.certificateFile.reset();
			
			// restore initial device channel values and update the grid by resetting the store
			var storeReloaded = this.grid.store.fetch();	
			this.store = storeReloaded.store.objectStore;
			this.grid.setStore(new apstrata.sdk.ObjectStoreAdaptor({objectStore: self.store}));			
			
			// Close child panel if any
			this.closePanel();
		}
	},
	
	/*
	 * Persist the changes that were made by the user by calling the UpdateCertificate or AddCertificate APIs
	 * and reloading the store of the parent panel
	 */
	_saveChanges: function() {
		var isValid = this.dvForm.validate();
		if (isValid) {	
			
			var self = this;			
			var scriptParams = {};
			scriptParams["applicationID"] = this.applicationID.get("value");
			scriptParams["password"] = this.password.get("value");
			scriptParams["apsdb.store"] = this.attrs.docStore ? this.attrs.docStore : "DefaultStore";
			
			var action = this.attrs.isNewApplication ? "AddCertificate" : "UpdateCertificate";			
			var client = new apstrata.sdk.Client(this.container.connection);			
			client.call(action, scriptParams, self.dvForm.domNode, {method:"post"}).then(
					function(response){
						if (response.metadata.status == "error"){
							if (response.metadata.errorDetail instanceof Object){
								self._alert("Script error");
							}else {
								self._alert(response.metadata.errorDetail);
							}
						}else {
							self._parent.refreshContent();							
							
							if (self.attrs.isNewApplication) {
								self.attrs.isNewApplication = false;
							}
							
							// Layout the updated grid by sorting twice (TODO: need a better alternative)
							self.grid.sort();
							self.grid.sort();
						}
					},
					function(response){
						if (typeof(response) == "string") {
							self._alert(response);
						}else {
							var error = response.metadata.errorDetail ? response.metadata.errorDetail : response.metadata.errorCode
							self._alert(error);
						}
					}
			);			
		}		
	},	
	
	/*
	 * A utility function that factors out the logic to create and call the Apstrata client
	 */
	_callApi: function(action, scriptParams) {
		
		var client = new apstrata.sdk.Client(this.container.connection);			
		return client.call(action, scriptParams, this.dvForm.domNode, {method:"post"});
	},
	
	/*
	 * Builds and returns the URL to download the certificate file that is related
	 * to the application. 
	 */
	_getCertificate: function(event) {	
		
		var docStore = this.attrs.docStore ? this.attrs.docStore : "DefaultStore";
		var params = {
			"apsdb.documentKey" : this.applicationID.get("value"),
			"apsdb.fileName" : "certificate",
			"apsdb.fieldName" : "apsdb_attachments",
			"apsdb.store" : docStore
		};
		
		var connection = this.container.connection;
		var url = connection.sign("GetFile", dojo.objectToQuery(params)).url;
		return url;
	},
	
	/*
	 * Displays an alert message
	 */
	_alert: function(message) {
		var self = this;
		new apstrata.horizon.PanelAlert({
					panel: self, 
					width: 320,
					height: 140,
					iconClass: "errorIcon",
					message: message,
					actions: ['OK'],
					actionHandler: function(action) {
						self.closePanel();
					}
				}
			);		
	},
	
	/*
	 * Displays a confirmation pop-pup.
	 * @param message: the message to display
	 * @param callback: the function to call when "ok" is clicked
	 * @param callbackParams: the parameters to send to the callback function
	 */
	_confirm: function(message, callback, callbackParams) {
		var self = this;
		new apstrata.horizon.PanelAlert({
					panel: self, 
					width: 320,
					height: 140,
					iconClass: "editIcon",
					message: message,
					actions: ['OK', 'Cancel'],
					actionHandler: function(action) {
						
						if (action == "Cancel") {
							self.closePanel();
						}
						
						if (action == "OK") {
							callback(callbackParams);
							self.closePanel();
						}
					}
				}
			);		
	}
	
})
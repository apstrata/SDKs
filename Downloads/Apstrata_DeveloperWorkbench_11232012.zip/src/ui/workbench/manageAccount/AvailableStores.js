dojo.provide("apstrata.workbench.manageAccount.AvailableStores");

dojo.require("apstrata.horizon.NewList");
dojo.require("apstrata.sdk.AdminStore");
dojo.require("apstrata.workbench.manageAccount.PushNotifications");

dojo.declare("apstrata.workbench.manageAccount.AvailableStores", 
[apstrata.horizon.NewList], 
{
	//
	// widget attributes
	//
	filterable: true,
	sortable: true,
	editable: false,
	
	labelAttribute: "name",
	idAttribute: "name",
	
	constructor: function(attrs) {
		var self = this
	
		this.store = new apstrata.sdk.AdminStore({
			connection: this.container.connection
		});
		
		this.store.setType('stores');
	},

	postCreate: function() {
		this.inherited(arguments);		
	},
	
	startup: function() {
		dojo.style(this.domNode, "width", "190px");		
		this.inherited(arguments);
	},
	
	onClick: function(id, selectedIds) {
		this.openPanel(apstrata.workbench.manageAccount.PushNotifications, {store: id});
	},

	getId: function(item) {return item.name},
	getLabel: function(item) {return item.name},
	
})
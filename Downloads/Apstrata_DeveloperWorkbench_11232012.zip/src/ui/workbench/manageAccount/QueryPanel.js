/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.QueryPanel");

dojo.require("apstrata.workbench.manageAccount.AdminForm");
dojo.require("apstrata.workbench.manageAccount.QueryResultsPanel");

dojo.declare("apstrata.workbench.manageAccount.QueryPanel",
		[apstrata.workbench.manageAccount.AdminForm], 
{	
	constructor: function(args) {
		var self = this;
	
		this.store.setType("documents");
	
		self.options = dojo.mixin(self.options, args);
	
		self.options = dojo.mixin(self.options, {
			definitionPath: dojo.moduleUrl("apstrata.workbench.manageAccount", "formDefinitions/Query.json"),
			actions: ['Query'],
			title: "Query",
			label: "Query",
	
			Query: function(values, formGenerator){
				values["apsdb.store"] = self.options.storeName;
				values["apsdb.resultsPerPage"] = 20;
				values["apsdb.pageNumber"] = 1;
				self.openPanel(apstrata.workbench.manageAccount.QueryResultsPanel, {"adminStore": self.store, "queryParams": values});
			}
		});
	}
	
});


dojo.provide("apstrata.workbench.manageAccount.SchemaEditorPanel")

dojo.require("dojox.dtl._Templated")

dojo.require("apstrata.workbench.manageAccount.CodeEditorPanel")


/**
 * Provides a code viewer panel to show sample code of an Apstrata call
 * 
 * @param {Object} attrs
 */
dojo.declare("apstrata.workbench.manageAccount.SchemaEditorPanel", 
[apstrata.workbench.manageAccount.CodeEditorPanel], 
{
	
	constructor: function(options) {
		var self = this
		this.syntax = "xml"
		this.options = options
		if (this.options.target) {
			this._id = this.options.target
		}
		if (this.options.update) {
			this._update = this.options.update
		}
		this.store.setType("schemas")
	},

	setCode: function(code) {
		this._id = code.id
		this.txtEditor.set("value", code.schema)
		this.fldName.set("value", code.id)
		
		if (code.id == "apsdb_user" && !this.defaultUDSchemaBtn) {
			this.defaultUDSchemaBtn = new dijit.form.Button({"label": "Default UD Schema"});
			dojo.place(this.defaultUDSchemaBtn.domNode, this.dvActionBar, "first");
			dojo.connect(this.defaultUDSchemaBtn, "onClick", this, "_defaultUDSchema");
		}
	},
	
	saveCode: function() {
		var self = this
		
		var nameChange = false
		if (this._id) {
			nameChange = (this._id != self.fldName.get("value"))
		} 
		
		var theSchemaName = ""
		var theSchemaNewName = ""
		
		if (nameChange) {
			theSchemaName = this._id
			theSchemaNewName = 	self.fldName.get("value")
		} else {
			theSchemaName = self.fldName.get("value")
		}
		
		var attr = {
			"apsdb.schemaName": theSchemaName,
			"apsdb.schema": editAreaLoader.getValue(self.txtEditor.id)
		}

		if (theSchemaNewName) attr["apsdb.newSchemaName"] = theSchemaNewName
		if (this._update) attr["apsdb.update"] = true
		
		self.showAsBusy(true, "saving...")		
		dojo.when(
			self.store.put(attr),
			function(success) {
				self.showAsBusy(false)
				
				//this is required so that the updated schema definition gets set in the editor upon resizing of the panel
				self._code = {
					id: self.fldName.get("value"),
					schema: editAreaLoader.getValue(self.txtEditor.id)
				}
				
				self._id = self.fldName.get("value")
				if (!self._update || nameChange) {
					self.getParent().reload()
				}
				if (self._update) {
					self.getParent().highlight(self._id)
				}
				self._update = true 
			},
			function(responseMetadata) {
				self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
				self.showAsBusy(false)		
				
			}
		)
	},
	
	_defaultUDSchema: function() {
		var self = this;
		
		var defaultUDSchema = '<!-- \r\n'
							+ 'This is the default user schema. Feel free to modify it to your liking.\r\n'
							+ 'This schema follows all rules and restrictions as all other schemas, as do the documents (users) created out of it.\r\n'
							+ 'However, it imposes the following restrictions of its own:\r\n'
							+ '1. The six default fields (groups, name, login, password, locale and isSuspended) are required.\r\n'
							+ '2. This schema cannot be deleted.\r\n'
							+ '\r\n'
							+ 'Additionally, since this schema is used for user management, the following ACLs are set by default upon creation of each new user document:\r\n'
							+ '- document.readACL = login, creator\r\n'
							+ '- document.writeACL = login, creator\r\n'
							+ '- deleteACL = nobody\r\n'
							+ '- required.readACL = nobody\r\n'
							+ '- required.writeACL = nobody\r\n'
							+ '- requiredVisibles.readACL = login, creator\r\n'
							+ '- requiredVisibles.writeACL = nobody\r\n'
							+ '- requiredEditables.readACL = login, creator\r\n'
							+ '- requiredEditables.writeACL = login, creator\r\n'
							+ '\r\n'
							+ 'You can specify your own ACLs upon user creation by passing them as parameters to the SaveUser API as described in the documentation.\r\n'
							+ '-->\r\n'
							+ '<schema>\r\n'
 							+ '  <aclGroups>\r\n'
 							+ '    <aclGroup name=\"required\">\r\n'
 							+ '      <read>nobody</read>\r\n'
 							+ '      <write>nobody</write>\r\n'
 							+ '      <fields>\r\n'
 							+ '        <field>isSuspended</field>\r\n'
 							+ '      </fields>\r\n'
 							+ '    </aclGroup>\r\n'
 							+ '    <aclGroup name=\"requiredVisibles\">\r\n'
 							+ '      <read>creator</read>\r\n'
 							+ '      <write>nobody</write>\r\n'
 							+ '      <fields>\r\n'
 							+ '        <field>login</field>\r\n'
 							+ '        <field>groups</field>\r\n'
 							+ '      </fields>\r\n'
 							+ '    </aclGroup>\r\n'
 							+ '    <aclGroup name=\"requiredEditables\">\r\n'
 							+ '      <read>creator</read>\r\n'
 							+ '      <write>creator</write>\r\n'
 							+ '      <fields>\r\n'
 							+ '        <field>name</field>\r\n'
 							+ '        <field>password</field>\r\n'
 							+ '        <field>locale</field>\r\n'
 							+ '      </fields>\r\n'
 							+ '    </aclGroup>\r\n'
 							+ '    <defaultAcl>\r\n'
 							+ '      <read>creator</read>\r\n'
 							+ '      <write>creator</write>\r\n'
 							+ '    </defaultAcl>\r\n'
 							+ '    <schemaAcl>\r\n'
 							+ '      <read>creator</read>\r\n'
 							+ '      <write>creator</write>\r\n'
 							+ '      <delete>nobody</delete>\r\n'
 							+ '    </schemaAcl>\r\n'
 							+ '  </aclGroups>\r\n'
 							+ '  <fields>\r\n'
 							+ '    <field name=\"login\" type=\"string\" />\r\n'
 							+ '    <field name=\"name\" type=\"string\"/>\r\n'
 							+ '    <field name=\"groups\" type=\"string\" />\r\n'
 							+ '    <field name=\"password\" type=\"string\" />\r\n'
 							+ '    <field name=\"locale\" type=\"string\" />\r\n'
 							+ '    <field name=\"isSuspended\" type=\"string\" />\r\n'
 							+ '  </fields>\r\n'
 							+ '</schema>';
							
		editAreaLoader.setValue(self.txtEditor.id, defaultUDSchema);
	}
})

dojo.provide("apstrata.workbench.manageAccount.ScriptsMenu")

dojo.require("dojo.store.Memory")
dojo.require("apstrata.horizon.Menu")

dojo.declare("apstrata.workbench.manageAccount.ScriptsMenu", 
[apstrata.horizon.Menu], 
{
	items: [
				{	
					id:"myScripts", 
					label: "My Scripts", 
					panelClass: "apstrata.workbench.manageAccount.ScriptsList"
				}/*,
				{	
					id:"scriptsGallery", 
					label: "Scripts Gallery", 
					panelClass: "apstrata.horizon.blue.Home"
				},
				{	
					id:"logs", 
					label: "Logs", 
					panelClass: "apstrata.horizon.blue.Home"
				},*/
	],

	constructor: function(args) {
		var self = this
		//
		// widget attributes
		//
		this.filterable = false
		this.sortable = false
		this.editable = false

		this.store = new dojo.store.Memory({data: self.items})
	},
	
	postCreate: function() {
		dojo.addClass(this.domNode, "scriptsMenu")
		this.inherited(arguments)
	}
})
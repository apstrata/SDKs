dojo.provide("apstrata.workbench.manageAccount.CodeEditorPanel")

dojo.require("dojox.dtl._Templated")

dojo.require("dijit.form.Form")
dojo.require("dijit.form.ValidationTextBox")
dojo.require("dijit.form.SimpleTextarea")

/**
 * Provides a code viewer panel to show sample code of an Apstrata call
 * 
 * @param {Object} attrs
 */
dojo.declare("apstrata.workbench.manageAccount.CodeEditorPanel", 
[apstrata.horizon.Panel], 
{
	syntax: "js",
	maximizable: true,
	widgetsInTemplate: true,
	templatePath: dojo.moduleUrl("apstrata.workbench.manageAccount", "templates/EditorPanel.html"),

	constructor: function(options) {
		var self = this
		dojo.mixin(this, options)
		this.store = new apstrata.sdk.AdminStore({
			connection: self.container.connection
		})
	},

	/**
	 * Provides rendering of code viewer
	 * @function
	 */
	postCreate: function(){
		var self = this
		
		dojo.addClass(this.domNode, "EditorPanel")
		
		if (this._code) {
			this._setupEditor()
			this.setCode(this._code)
		}

		this.inherited(arguments)		
	},
	
	resize: function() {
		var h = dojo.contentBox(this.domNode).h
		var hh = dojo.contentBox(this.dvHeader).h
		var fh = dojo.contentBox(this.dvFooter).h
		
		dojo.style(this.dvContent, {
			height: h-hh-fh + "px"
		})
		
		//resize the editor
		if (this.txtEditorFrameID) {
			var c = dojo.contentBox(this.domNode)	
			dojo.style(dojo.byId(this.txtEditorFrameID), {height: (c.h-85)+"px", width: (c.w-4)+"px"})
		}

		this.inherited(arguments)
	},
	
	_setupEditor: function() {
		var self = this
		
		parent.EditAreaLoaded= function() {
			var c = dojo.contentBox(self.domNode)		
			console.debug("frame_"+self.txtEditor.id)
			self.txtEditorFrameID = "frame_"+self.txtEditor.id
			dojo.style(dojo.byId("frame_"+self.txtEditor.id), {height: (c.h-85)+"px", width: (c.w-4)+"px"})
			self.showAsBusy(false)
		}

		editAreaLoader.init({
			id: self.txtEditor.id
			,start_highlight: true	// if start with highlight
			,allow_resize: "no"
			,allow_toggle: false
			//,word_wrap: true    //word_wrap is causing ghosting effect in chrome; it can still be enabled manually after editor is loaded 
			,language: "en"
			,syntax: self.syntax
			,font_size: "9"
			,toolbar: "reset_highlight, |, undo, redo, |, search, |, go_to_line, |, word_wrap, select_font,|, change_smooth_selection, highlight, |, help"
			,EA_load_callback: "EditAreaLoaded"
		})

		dojo.style(self.dvContent, {display: "block"})
	},

	onAnimationEnd: function() {
		var self = this
		
		if (this.target) {
			this.showAsBusy(true, "loading...")
	
			dojo.when(
				self.store.get(self.target),
				function(code) {
					self._code = code
					self.setCode(code)
					self._setupEditor()
					
				},
				function(responseMetadata) {
					self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)	
					self.showAsBusy(false)
				}
			)
		} else {
			this.showAsBusy(true)
			self.setCode({id:"", schema:""})
			self._setupEditor()
		}
		
		this.resize()
		this.inherited(arguments)
	},
	
	_save: function() {
		this.saveCode()
	},
	
	_run: function() {
		
	}
	
})
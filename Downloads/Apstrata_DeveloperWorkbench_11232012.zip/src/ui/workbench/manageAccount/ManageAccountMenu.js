dojo.provide("apstrata.workbench.manageAccount.ManageAccountMenu")

dojo.require("dojo.store.Memory")
dojo.require("apstrata.horizon.Menu")

dojo.require("apstrata.workbench.manageAccount.ConfigurationForm")

dojo.declare("apstrata.workbench.manageAccount.ManageAccountMenu", 
[apstrata.horizon.Menu], 
{
	items: null,

	constructor: function(args) {
		var self = this
		//
		// widget attributes
		//
		
		
		this.items= [
		 			{
						id:"stores", 
						label: "Stores", 
						iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/datebase.png", 
						panelClass: "apstrata.workbench.manageAccount.StoresList"
					},
					{
						id:"schemas", 
						label: "Schemas", 
						iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/schema.png", 
						panelClass: "apstrata.workbench.manageAccount.SchemasList"
					},
					{
						id:"scripts", 
						label: "Scripts",
						iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/draft.png", 
						panelClass: "apstrata.workbench.manageAccount.ScriptsMenu"
					},
					{
						id:"notifications", 
						label: "Push notifications", 
						iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/configuration.png", 
						panelClass: "apstrata.workbench.manageAccount.AvailableStores" 
					},
					{
						id:"groups", 
						label: "Groups", 
						iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/users.png", 
						panelClass: "apstrata.workbench.manageAccount.GroupsList"
					},
					{
						id:"users", 
						label: "Users", 
						iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/user-man.png", 
						panelClass: "apstrata.workbench.manageAccount.UsersList"
					},
					{
						id:"savedQueries", 
						label: "Saved Queries", 
						iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/datebase.png", 
						panelClass: "apstrata.workbench.manageAccount.SavedQueriesList"
					},
					{
						id:"configuration", 
						label: "Configuration", 
						iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/configuration.png", 
						panelClass: "apstrata.workbench.manageAccount.ConfigurationForm" 
					}
			];
		this.filterable = false
		this.sortable = false
		this.editable = false

		this.store = new dojo.store.Memory({data: self.items})
	},
	
	postCreate: function() {
		dojo.addClass(this.domNode, "manageAccountMenu")
		
		this.inherited(arguments)
	}
})


<?php 

$server = "http://localhost"; 
$root = "/~rabih/ApstrataDeveloperWorkbench/src/ui/workbench/manageAccount/dav.php";

error_log("============================");
error_log("method:");
error_log($_SERVER['REQUEST_METHOD']);

error_log("headers:");
foreach (getallheaders() as $name => $value) {
    error_log("$name: $value");
}

error_log("request params:");
foreach ($_GET as $key=>$value) {
	error_log("$key = " . urldecode($value));
}

error_log("body:");
$body = @file_get_contents('php://input');

error_log($body);


error_log("\n\n\n\n");
?>
<?xml version="1.0" encoding="utf-8"?>
<d:multistatus>
	<d:response>
		<d:href>/~rabih/ApstrataDeveloperWorkbench/src/ui/workbench/manageAccount/dav.php/</d:href>
		<d:propstat>
			<d:prop>
				<d:getlastmodified xmlns:b="urn:uuid:c2f41010-65b3-11d1-a29f-00aa00c14882/" b:dt="dateTime.rfc1123">Fri, 13 Apr 2012 09:49:41 GMT</d:getlastmodified>
				<d:resourcetype><d:collection/></d:resourcetype>
			</d:prop>
			<d:status>HTTP/1.1 200 OK</d:status>
		</d:propstat>
	</d:response>
	<d:response>
		<d:href>/~rabih/ApstrataDeveloperWorkbench/src/ui/workbench/manageAccount/dav.php/public/</d:href><d:propstat><d:prop><d:getlastmodified xmlns:b="urn:uuid:c2f41010-65b3-11d1-a29f-00aa00c14882/" b:dt="dateTime.rfc1123">Fri, 13 Apr 2012 07:05:01 GMT</d:getlastmodified><d:resourcetype><d:collection/></d:resourcetype><d:quota-used-bytes>94695575552</d:quota-used-bytes><d:quota-available-bytes>127377440768</d:quota-available-bytes></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat>
	</d:response>
</d:multistatus>

/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.ScriptsList")

dojo.require("apstrata.workbench.manageAccount.AdminList")
dojo.require("apstrata.workbench.manageAccount.ScriptEditorPanel")


dojo.require("apstrata.sdk.AdminStore")
 
dojo.declare("apstrata.workbench.manageAccount.ScriptsList",
[apstrata.workbench.manageAccount.AdminList], 
{	
	//
	// widget attributes
	//
	filterable: true,
	sortable: true,
	editable: true,

	newObjectPanel: null,
	
	// index of the essential item properties
	idProperty: 'name',
	labelProperty: 'name',
	
	// params sent to documentation widget to display contextual information
	docTopic: "",
	docId: "",

	constructor: function() {
		var self = this

		this.store.setType("scripts") 
	},
	
	onClick: function(id, args) {
		var self = this	

		self.openPanel(apstrata.workbench.manageAccount.ScriptEditorPanel, {target: id, update: true})
	},

	onNew: function() {
		var self = this

		self.openPanel(apstrata.workbench.manageAccount.ScriptEditorPanel)
	},

	changeItemLabel: function(id, label) {
		var self = this

		var attr = {
			"apsdb.scriptName": id,
			"apsdb.update": true,
			"apsdb.newScriptName": label
		}

		self.showAsBusy(true, "changing label...")
		dojo.when(
			self.store.put(attr),
			function(){
				self.showAsBusy(false)
				// on success we can show the modified label
				self._listContent.changeItemLabel(id, label)
				self._tglEdit.set("checked", false) 
				self.reload()
			}, function(responseMetadata) {
				// on failure revert the old value
				self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
				self.showAsBusy(false)
				self._listContent.revertItemEdit()
			}
		)
	}
})


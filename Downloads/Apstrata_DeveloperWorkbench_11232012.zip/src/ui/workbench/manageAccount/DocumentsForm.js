/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.DocumentsForm")

dojo.require("apstrata.workbench.manageAccount.AdminForm")
dojo.require("dojox.form.FileInput")
 
dojo.declare("apstrata.workbench.manageAccount.DocumentsForm",
[apstrata.workbench.manageAccount.AdminForm], 
{	
	fileFields: null,
	dvAddFileButton: null,
	
	constructor: function(args) {
		var self = this
		
		if (args.fileFields) {
			this.fileFields = args.fileFields;
		} else {
			this.fileFields = {};			
		}
		
		this.store.setType("documents");
		
		self.options = dojo.mixin(self.options, args)
		
		self.options = dojo.mixin(self.options, {
			definitionPath: dojo.moduleUrl("apstrata.workbench.manageAccount", "formDefinitions/SaveDocument.json"),
			actions: ['save'],
			cssClass: "UserEditor",
			
			save: function(values, formGenerator){
				var originalValues = dojo.clone(values);
				
				values["apsdb.store"] = self.options.storeName;
				
				var fieldsNames = values.fieldName;
				var fieldsTypes = values.fieldType;
				var fieldsValues = values.fieldValue;
				
				var ftsFields = ""; 
				
				if (fieldsNames) {
					if (dojo.isArray(fieldsNames)) {
						for (var i = 0; i < fieldsNames.length; i++) {
							values[fieldsNames[i]] = [];
						}
						
						for (var j = 0; j < fieldsNames.length; j++) {
							values[fieldsNames[j]].push(fieldsValues[j])
							values[fieldsNames[j] + ".apsdb.fieldType"] = fieldsTypes[j]
							if (ftsFields != "") {
								var tmpStr = ftsFields + ",";
								if (tmpStr.indexOf(fieldsNames[j] + ",") == -1) {
									ftsFields = ftsFields + "," + fieldsNames[j]
								}
							} else {
								ftsFields = fieldsNames[j]
							}
						}
					} else {
						values[fieldsNames] = fieldsValues
						values[fieldsNames + ".apsdb.fieldType"] = fieldsTypes
						ftsFields = fieldsNames;
					}
					
					if (!values["apsdb.schema"]) {
						values["apsdb.ftsFields"] = ftsFields;
					}
					
					delete values.fieldName;
					delete values.fieldType;
					delete values.fieldValue;
				}				
				
				if ((self.options.update) && (values["apsdb.versioning"] == "false")) {
					values['apsdb.update'] = true
					if (values["apsdb.latestVersion"] == "0.0") {
						new apstrata.horizon.PanelAlert({
							panel: self,
							width: 320,
							height: 140,
							message: "Updates are only allowed on the latest version of a document.",
							iconClass: "errorIcon",
							actions: ['Ok'],
							actionHandler: function(action) {
								if (action=='Ok') {
								} 
							}
						})	
						return					  
					} 
				} 
				
				delete values["apsdb.latestVersion"]
				delete values["apsdb.versionNumber"]
				
				if (!values["apsdb.documentKey"]) {
					delete values["apsdb.documentKey"]
				}
				
				//remove the uploadFile field from the values. Dojo by default names the file field as uploadFile
				delete values["uploadFile"];
				
				delete values["apsdb_attachments"];
				
				//remove file fields from values because they will be sent as part of the form
				//at the same time, set the file field names in the multivalueappend list so that files can be uodated properly
				for (var fileFieldName in self.fileFields) {
					delete values[fileFieldName];
					if (self.options.update) {
						if (!values["apsdb.multivalueAppend"]) {
							values["apsdb.multivalueAppend"] = fileFieldName;
						} else {
							values["apsdb.multivalueAppend"] = values["apsdb.multivalueAppend"] + "," + fileFieldName;
						}
					}
				}
								
				// Clean up the form
				// In the case we need to be able to upload files, we need to pass a form to the client, 
				// not the 'values' object. Therefore, we need to perform the same clean up as before, but
				// on the form this time. In addition, we will send the fieldName/fieldValue/fieldType
				// as parameters of the request so we retrieve them in an object (newFieldsParams)
				// We do not however take into account fields of type file, since they already are sent
				// with the form
				
				if (!values["apsdb.documentKey"]) {					
					var documentKeyWidget = self._form.getField("apsdb.documentKey");
					if (documentKeyWidget) {
						//dojo.destroy(documentKeyWidget.domNode);
						dojo.destroy(dojo.byId(documentKeyWidget.get("id")));
					}
				}		
				
				var schemaWidget = self._form.getField("apsdb.schema");
				var versioningWidget = self._form.getField("apsdb.versioning");
				var runAsWidget = self._form.getField("apsdb.runAs");
				var latestVersionWidget = self._form.getField("apsdb.latestVersion");
				var versionNumberWidget = self._form.getField("apsdb.versionNumber");
				var fieldNameWidget = self._form.getField("fieldName");
				var fieldTypeWidget = self._form.getField("fieldType");
				var fieldValueWidget = self._form.getField("fieldValue");
				
				if (schemaWidget) {
					dojo.destroy(schemaWidget.domNode);
				}

				if (versioningWidget) {
					dojo.destroy(versioningWidget.domNode);
				}
					
				if (runAsWidget) {
					dojo.destroy(runAsWidget.domNode);
				}					
				
				if (latestVersionWidget) { 
					dojo.destroy(latestVersionWidget.domNode);
				}					
				
				if (versionNumberWidget) {
					dojo.destroy(versionNumberWidget.domNode);
				}

				if (fieldNameWidget) {
					if (fieldNameWidget.length) {
						dojo.forEach(fieldNameWidget, function(current, index) {
							dojo.destroy(current.domNode);
						})
					}else {
						dojo.destroy(fieldNameWidget.domNode);
					}
				}
					
				if (fieldTypeWidget) {
					if (fieldTypeWidget.length) {
						dojo.forEach(fieldTypeWidget, function(current, index) {
							dojo.destroy(current.domNode);
						})
					}else {
						dojo.destroy(fieldTypeWidget.domNode);
					}
				}
					
				if (fieldValueWidget) {
					if (fieldValueWidget.length) {
						dojo.forEach(fieldValueWidget, function(current, index) {
							dojo.destroy(current.domNode);
						})
					}else {
						dojo.destroy(fieldValueWidget.domNode);
					}
				}				
								
				// end Clean up the form
								
				self.showAsBusy(true, "saving document...");
				//self.store.put(values).then( <-- this was removed as we need to pass the form in order to upload files
				self.store.put(self._form.frmMain, values).then(
					function(response) {
						self.showAsBusy(false)
						self.reloadData(response.result.document.key + "|" + Math.floor(response.result.document.versionNumber));
						//refresh the query results grid
						if (self.getParent().refresh) 
							self.getParent().refresh()
						
					},
					function(responseMetadata) {
						self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
						self.showAsBusy(false)
						self.reloadData("", originalValues);
					}
				)
			}
		})
		
	},
	
	prepareFormData: function() {	
		var self = this;
		
		var deferred = new dojo.Deferred();
		if (self.options && self.options.dockey && self.options.update) {
			self.showAsBusy(true, "loading document...");	
	  		this.store.get(self.options.dockey, {store: self.options.storeName}).then(
	  			function(doc) {
		  			self.showAsBusy(false);
		  			
		  			this.fileFields = {};
		  			
		  			var fieldName = [];
		  			var fieldType = [];
		  			var fieldValue = [];
		  			
		  			var values = {}
		  			
		  			for (var field in doc) {
		  				if (field != "_type" && field != "key" && field != "versionNumber") {
			  				if (field.indexOf("apsdb.") == 0 ) {
			  					values[field] = doc[field]
			  				} else {
			  					if (dojo.isArray(doc[field])) {
			  						for (var i = 0; i < doc[field].length; i++) {
			  							if (doc["_type"][field] != "file") {
				  							fieldName.push(field)
						  					fieldValue.push(doc[field][i])
						  					fieldType.push(doc["_type"][field])
			  							} else {
			  								if (self.fileFields[field]) {
												self.fileFields[field].push(doc[field][i]);
											} else {
												self.fileFields[field] = [];
												self.fileFields[field].push(doc[field][i]);
											}
			  							}			  							
			  						}
			  					} else {
			  						if (doc["_type"][field] != "file") {
					  					fieldName.push(field)
					  					fieldValue.push(doc[field])
					  					fieldType.push(doc["_type"][field])
			  						} else {
		  								if (self.fileFields[field]) {
											self.fileFields[field].push(doc[field]);
										} else {
											self.fileFields[field] = [];
											self.fileFields[field].push(doc[field]);
										}
			  						}
			  					}
			  				}
		  				}
		  			}
		  			
		  			values["fieldName"] = fieldName;
		  			values["fieldType"] = fieldType;
		  			values["fieldValue"] = fieldValue;
		  			
		  			if (self.options.runAs) {
		  				values["apsdb.runAs"] = self.options.runAs
		  			}
		  			
		  			deferred.resolve(values);
				}, 
				function(responseMetadata) {
					self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
					self.showAsBusy(false);	
					deferred.reject(responseMetadata);
				}
			)
		} else {
			if (self.options && self.options.values) {
				deferred.resolve(self.options.values);
			} else {
				deferred.resolve({});
			}
		}
		
		return deferred;
	},
	
	reloadData: function(dockey, values) {
		//we had to reload the data by reopening the form in order for the MultipleFile attachment widget to work
		//we faced issues with the widget when just setting the values of a certain document in the form generator 
		var self = this;
		
		if (dockey) {
			var params = {
				title: "Edit Document",
				label: "Edit Document",
				update: true,
				dockey: dockey,
			};
			
			if (self.options && self.options.storeName) {
				params.storeName = self.options.storeName;
			};
			
			if (self.options && self.options.runAs) {
				params.runAs = self.options.runAs;
			};
			
			self.getParent().openPanel(apstrata.workbench.manageAccount.DocumentsForm, params);
		} else {
			if (!values) {
				values = {};
			}
			
			var params = {
				title: "New Document",
				label: "New Document",
				values: values,
				fileFields: self.fileFields
			};
			
			if (self.options && self.options.storeName) {
				params.storeName = self.options.storeName;
			};
			
			if (self.options && self.options.runAs) {
				params.runAs = self.options.runAs;
			};
			
			self.getParent().openPanel(apstrata.workbench.manageAccount.DocumentsForm, params);	
							
		} 
	},


	addFileFieldHandler: function(event) {
		this.addFileField("apsdb_attachments", "", false);	
	},
	
	
	addFileField: function(name, value, disableFieldName) {
		
		dojo.place("<br>", this.dvAddFileButton, "before");	
		
		var dockey = this._form.value["apsdb.documentKey"];
		
		var fileWidget = new apstrata.ui.forms.FileField({
			connection: this.container.connection,
			store: this.options.storeName,
			dockey: dockey,
			name: name,
			displayImage: false,
			showFieldName: true,
			value: value,		
			style: "border-style:dashed; border-width:1px; border-color:grey; padding:10px;",
			showRemoveFieldBtn: true
		});		
		
		fileWidget._displayAttachedFile();
		
		if (disableFieldName) {
			dojo.attr(fileWidget.filefieldName, "readonly", "readonly");
		}
		
		dojo.place(fileWidget.domNode, this.dvAddFileButton, "before");
	},
	
	
	_getReady: function() {
		
		this._form._setFormFileEncType();
		
		//Add label for attachments section
		var dv = dojo.create("div", {innerHTML:"<br><div style='font-weight:bold;'>Attached Files:</div>"});
		dv = dojo.place(dv, this._form.dvActions, "first");
		
		//Add button for adding attachments
		var addFileBtn = new dijit.form.Button({"label": "+"});
		this.dvAddFileButton = dojo.place(addFileBtn.domNode, dv, "last");
		dojo.connect(addFileBtn, "onClick", this, "addFileFieldHandler");
		
		var dockey = this._form.value["apsdb.documentKey"];
		if (!dockey) {
			return;
		}
		
		for (var fileFieldName in this.fileFields) {
			for (var k = 0; k < this.fileFields[fileFieldName].length; k++) {
				this.addFileField(fileFieldName, this.fileFields[fileFieldName][k], true);
			}
			
		}		
	}
	
})


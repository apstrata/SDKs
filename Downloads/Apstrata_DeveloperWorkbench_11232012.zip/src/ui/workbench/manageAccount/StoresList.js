/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.StoresList")

dojo.require("apstrata.workbench.manageAccount.AdminList")
 
dojo.require("apstrata.sdk.AdminStore")
dojo.require("apstrata.workbench.manageAccount.StoreOperationsList")
dojo.require("apstrata.workbench.manageAccount.StoresForm") 
 
 
dojo.declare("apstrata.workbench.manageAccount.StoresList",
[apstrata.workbench.manageAccount.AdminList], 
{	
	//
	// widget attributes
	//
	filterable: true,
	sortable: true,
	editable: true,

	newObjectPanel: null,
	
	// params sent to documentation widget to display contextual information
	docTopic: "",
	docId: "",
	
	isItemDeleteable: function(item) {
		return true
	},

	isItemEditable: function(item) {
		return false
	},
	
	constructor: function() {
		var self = this
		this.store.setType('stores')
	},

	onClick: function(id) {
		var self = this	

		self.openPanel(apstrata.workbench.manageAccount.StoreOperationsList, {target: id})
	},
	
	onNew: function() {
		var self = this

		self.openPanel(apstrata.workbench.manageAccount.StoresForm)
	},
	
	onDeleteItem: function(id, item) {
		var self = this
		new apstrata.horizon.PanelAlert({
			panel: self,
			width: 320,
			height: 150,
			title: "Delete store [" + id + "]?",
			iconClass: "deleteIcon",
			message: "This operation is not reversible.",
			actions: [ 'Confirm', 'Cancel' ],
			actionHandler: function(action) {
				if (action == 'Confirm') {
					self.showAsBusy(true, "deleting item...")
					
					dojo.when(
						self.deleteItem(id),
						function() {
							self.showAsBusy(false)
						},
						function() {
							self.showAsBusy(false)
						}
					)
				}
			}
		})
	}	
})


/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.ConfigurationForm")

dojo.require("apstrata.workbench.manageAccount.AdminForm")
 
dojo.declare("apstrata.workbench.manageAccount.ConfigurationForm",
[apstrata.workbench.manageAccount.AdminForm], 
{	
	constructor: function(args) {
		var self = this
		
		
		this.store.setType("configuration")
		
		self.options = dojo.mixin(self.options, args)
		
		self.options = dojo.mixin(self.options, {
			definitionPath: dojo.moduleUrl("apstrata.workbench.manageAccount", "formDefinitions/Configuration.json"),
			actions: ['save'],
			title: "Edit configuration",
			label: "Edit configuration",
			
			save: function(values, formGenerator){
				self.showAsBusy(true, "saving configuration")
				self.store.put(values).then(
					function(result) {
						self.showAsBusy(false)
					},
					function(responseMetadata) {
						self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
						self.showAsBusy(false)
					}
				)
			}
		})
		
	},
	
	prepareFormData: function() {
		var self = this

		var deferred = new dojo.Deferred();
		
		self.showAsBusy(true, "retrieving configuration")
		dojo.when(
			this.store.query(null, null),
			function(response) {
				self.showAsBusy(false)
				delete response["stores"];
				
				var prefixedResult = {} 
				for (var key in response) {
					prefixedResult["apsdb." + key] = response[key];
				}
				
				deferred.resolve(prefixedResult);
			}, 
			function(responseMetadata) {
				self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
				self.showAsBusy(false)	
				deferred.reject(responseMetadata);
			}
		)
		
		return deferred;
	}
})

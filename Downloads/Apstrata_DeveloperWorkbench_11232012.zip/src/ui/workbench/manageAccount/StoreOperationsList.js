dojo.provide("apstrata.workbench.manageAccount.StoreOperationsList")

dojo.require("apstrata.horizon.Menu")

dojo.declare("apstrata.workbench.manageAccount.StoreOperationsList", 
[apstrata.horizon.Menu], 
{
	items: null,

	constructor: function(attrs) {
		var self = this
		//
		// widget attributes
		//
		this.items = [
		      		{	
		    			id:"query", 
		    			label: "Query", 
		    			iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/search.png",
		    			panelClass: "apstrata.workbench.manageAccount.QueryPanel"
		    		},
		    		{	
		    			id:"editStore", 
		    			label: "Edit Store", 
		    			iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/schema.png",
		    			panelClass: "apstrata.workbench.manageAccount.StoresEditForm",
		    		},
		    		{	
		    			id:"saveDocument", 
		    			label: "Save Document", 
		    			iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/schema.png",
		    			panelClass: "apstrata.workbench.manageAccount.DocumentsForm",
		    			attrs: {
		    				title: "New Document",
		    				label: "New DOcument",
		    			}	
		    		}
		    	];
		this.filterable = false
		this.sortable = false
		this.editable = false
		
		this.target = attrs.target
		
		for(var i = 0 ; i < self.items.length; i++) {
			self.items[i].attrs = {
				storeName: self.target
			}
		}

		this.store = new dojo.store.Memory({data: self.items})
	},
	
	postCreate: function() {
		dojo.style(this.domNode, "width", "180px")
		this.inherited(arguments)
	}	
})

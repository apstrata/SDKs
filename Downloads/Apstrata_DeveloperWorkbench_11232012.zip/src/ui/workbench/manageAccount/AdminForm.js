dojo.provide("apstrata.workbench.manageAccount.AdminForm")

dojo.require("apstrata.ui.forms.FormGenerator")
dojo.require("apstrata.sdk.AdminStore")
dojo.require("apstrata.horizon.PanelAlert")

/**
 * 
 * @param {Object} attrs
 */
dojo.declare("apstrata.workbench.manageAccount.AdminForm", 
[apstrata.horizon.Panel], 
{
	constructor: function(options) {
		var self = this

		this.store = new apstrata.sdk.AdminStore({
			connection: self.container.connection
		})
		
		this.options = options		
	},

	postCreate: function(){
		var self = this

		dojo.addClass(this.domNode, "AdminForm")
		dojo.addClass(this.domNode, this.options.cssClass)
	
		this._xhrLoad = dojo.xhrGet({
			url: this.options.definitionPath.uri,
			handleAs: "text",
			timeout: 5000
		})		
		
		this._xhrLoad.then(function(definition) {
			var definition = dojo.fromJson(definition)
			definition.actions = self.options.actions;
			self.prepareFormData().then(
				function(values) {			
					self._form = new apstrata.ui.forms.FormGenerator(
						dojo.mixin(self.options, 
							{
								definition: definition, 
								displayGroups: self.options.displayGroup, 
								label: self.options.label,
								value: values
							})
					)
					dojo.place(self._form.domNode, self.dvContent)
					
					self._form.ready(dojo.hitch(self, self._getReady));
				}
			);
		})
		
		this.inherited(arguments);
	},
	
	_getReady: function() {
		
	},
	
	reload: function() {
		
		var self = this;
		self.prepareFormData().then(
			function(values) {
				
				if (self.options.dockey && self.options.update) {
					self._form.set('value', values);
				}else if (self.options.runAs) {
					self._form.set('value', {"apsdb.runAs": self.options.runAs});
				}
			}
		)
	},
	
	prepareFormData: function() {
		var deferred = new dojo.Deferred();
		deferred.resolve({});
		return deferred;
	}
})
/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.SchemasList")

dojo.require("apstrata.workbench.manageAccount.AdminList")
dojo.require("apstrata.workbench.manageAccount.SchemaEditorPanel")

dojo.require("apstrata.sdk.AdminStore")
 
dojo.declare("apstrata.workbench.manageAccount.SchemasList",
[apstrata.workbench.manageAccount.AdminList], 
{	
	//
	// widget attributes
	//
	filterable: true,
	sortable: true,
	editable: true,

	newObjectPanel: null,
	
	idProperty: 'name',
	labelProperty: 'name',
	
	constructor: function() {
		var self = this

		this.store.setType("schemas")
	},
	
	onClick: function(id, args) {
		var self = this	

		self.openPanel(apstrata.workbench.manageAccount.SchemaEditorPanel, {target: id, update: true})
	},

	onNew: function() {
		var self = this

		self.openPanel(apstrata.workbench.manageAccount.SchemaEditorPanel)
	},
	
	changeItemLabel: function(id, label) {
		var self = this

		var attr = {
			"apsdb.schemaName": id,
			"apsdb.update": true,
			"apsdb.newSchemaName": label
		}

		self.showAsBusy(true, "changing label...")
		dojo.when(
			self.store.put(attr),
			function(){
				self.showAsBusy(false)
				// on success we can show the modified label
				self._listContent.changeItemLabel(id, label)
				self._tglEdit.set("checked", false) 
				self.reload()
			}, function(responseMetadata) {
				// on failure revert the old value
				self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
				self.showAsBusy(false)
				self._listContent.revertItemEdit()
			}
		)
	}, 
	
	onDeleteItem: function(id) {
		var self = this;
		
		if (id == "apsdb_user") {
			new apstrata.horizon.PanelAlert({
				panel: self,
				width: 320,
				height: 150,
				message: "You are not allowed to delete the [apsdb_user] schema",
				iconClass: "deleteIcon",
				actions: [
					'Ok'
				],
				actionHandler: function(action) {
					if (action == 'Ok') {
						self.resetItem(id)
					} 
				}
			})
		} else {
			this.inherited(arguments)
		}
		
	}
	
})


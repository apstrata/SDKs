/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.UsersForm")

dojo.require("apstrata.workbench.manageAccount.AdminForm")
 
dojo.declare("apstrata.workbench.manageAccount.UsersForm",
[apstrata.workbench.manageAccount.AdminForm], 
{	
	fileFields: null,
	dvAddFileButton: null,
	
	constructor: function(args) {
		var self = this
		
		if (args.fileFields) {
			this.fileFields = args.fileFields;
		} else {
			this.fileFields = {};			
		}
		
		this.store.setType("users")
		
		self.options = dojo.mixin(self.options, args)
		
		self.options = dojo.mixin(self.options, {
			definitionPath: dojo.moduleUrl("apstrata.workbench.manageAccount", "formDefinitions/SaveUser.json"),
			actions: ['save'],
			cssClass: "UserEditor",
			
			save: function(values, formGenerator){
				var originalValues = dojo.clone(values);
				
				var form = {}
				
				if (values.attributeName) {
					if (dojo.isArray(values.attributeName)) {
						dojo.forEach(values.attributeName, function(attributeName, index) {
							if (!form[attributeName]) form[attributeName]=[]
							form[attributeName].push(values.attributeValue[index])
							form[attributeName+".apsdb.fieldType"] = values.attributeType[index]
						})
					} else {
						form[values.attributeName] = values.attributeValue
						form[values.attributeName+".apsdb.fieldType"] = values.attributeType
					}
				}
				
				delete values.attributeName
				delete values.attributeType
				delete values.attributeValue

				for (k in values) {
					if (dojo.isArray(values[k]) && values[k].length==1) {
						form[k] = values[k][0]
					}
				}

				dojo.mixin(values, form)
				
				if (values.password.trim() != "") {
					if (values.password.trim() == values.confirmPassword.trim()) {
						delete values.confirmPassword
					} else {
						self.displayError('', 'Passwords do not match')
						return
					}
				} else {
					delete values.password	
					delete values.confirmPassword
				}
				
				if (self.options.update) {
					values['apsdb.update'] = true
				}
				
				//remove the uploadFile field from the values. Dojo by default names the file field as uploadFile
				delete values["uploadFile"];
				
				delete values["apsdb_attachments"];
				
				//remove file fields from values because they will be sent as part of the form
				//at the same time, set the file field names in the multivalueappend list so that files can be uodated properly
				for (var fileFieldName in self.fileFields) {
					delete values[fileFieldName];
					if (self.options.update) {
						if (!values["apsdb.multivalueAppend"]) {
							values["apsdb.multivalueAppend"] = fileFieldName;
						} else {
							values["apsdb.multivalueAppend"] = values["apsdb.multivalueAppend"] + "," + fileFieldName;
						}
					}
				}
								
				// Clean up the form
				// In the case we need to be able to upload files, we need to pass a form to the client, 
				// not the 'values' object. Therefore, we need to perform the same clean up as before, but
				// on the form this time. In addition, we will send the attributeName/attributeValue/attributeType
				// as parameters of the request so we retrieve them in an object (newFieldsParams)
				// We do not however take into account fields of type file, since they already are sent
				// with the form
				
				var nameWidget = self._form.getField("name");
				var passwordWidget = self._form.getField("password");
				var confirmPasswordWidget = self._form.getField("confirmPassword");
				var emailWidget = self._form.getField("email");
				var isSuspended = self._form.getField("isSuspended");
				var groupsWidget = self._form.getField("groups");
				var attributeNameWidget = self._form.getField("attributeName");
				var attributeTypeWidget = self._form.getField("attributeType");
				var attributeValueWidget = self._form.getField("attributeValue");

				if (nameWidget) {
					dojo.destroy(nameWidget.domNode);
				}
				
				if (passwordWidget) {
					dojo.destroy(passwordWidget.domNode);
				}
				
				if (confirmPasswordWidget) {
					dojo.destroy(confirmPasswordWidget.domNode);
				}
				
				if (emailWidget) {
					dojo.destroy(emailWidget.domNode);
				}
				
				if (isSuspended) {
					dojo.destroy(isSuspended.domNode);
				}
				
				if (groupsWidget) {
					if (groupsWidget.length) {
						dojo.forEach(groupsWidget, function(current, index) {
							dojo.destroy(current.domNode);
						})
					}else {
						dojo.destroy(groupsWidget.domNode);
					}
				}
				
				
				if (attributeNameWidget) {
					if (attributeNameWidget.length) {
						dojo.forEach(attributeNameWidget, function(current, index) {
							dojo.destroy(current.domNode);
						})
					}else {
						dojo.destroy(attributeNameWidget.domNode);
					}
				}
					
				if (attributeTypeWidget) {
					if (attributeTypeWidget.length) {
						dojo.forEach(attributeTypeWidget, function(current, index) {
							dojo.destroy(current.domNode);
						})
					}else {
						dojo.destroy(attributeTypeWidget.domNode);
					}
				}
					
				if (attributeValueWidget) {
					if (attributeValueWidget.length) {
						dojo.forEach(attributeValueWidget, function(current, index) {
							dojo.destroy(current.domNode);
						})
					}else {
						dojo.destroy(attributeValueWidget.domNode);
					}
				}

				// end Clean up the form
				
				
				self.showAsBusy(true, "saving user info...");
				//self.store.put(values).then( <-- this was removed as we need to pass the form in order to upload files
				self.store.put(self._form.frmMain, values).then(
					function(response) {
						self.showAsBusy(false)
						if (!(self.options.update)) {
							//self.options.parentList.closePanel()
							self.options.parentList.reload()
						}
						self.reloadData(values.login);
						
					},
					function(responseMetadata) {
						self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail);
						self.showAsBusy(false);
						self.reloadData(values.login, originalValues);
					}
				)
			}
		})
		
	},
	
	prepareFormData: function() {	
		var self = this;
		
		var deferred = new dojo.Deferred();
		
		if (self.options && self.options.login && self.options.update) {
			self.showAsBusy(true, "loading user info...");	
	  		this.store.get(self.options.login, {"apsdb.includeFieldType": "true"}).then(function(obj) {
	  			self.showAsBusy(false);
				var values = {attributeName:[], attributeType:[], attributeValue: []}
	
				for (var k in obj.user) {
					if (k != "_type") {
						if ((k != "name") && (k != "email") && (k != "login") && (k != "groups") && (k != "isSuspended")) {
							if (dojo.isArray(obj.user[k])) {
		  						for (var i = 0; i < obj.user[k].length; i++) {
		  							if (obj.user._type[k] != "file") {
										values.attributeName.push(k)
										values.attributeValue.push(obj.user[k][i])
										values.attributeType.push(obj.user._type[k])
		  							} else {
		  								if (self.fileFields[k]) {
											self.fileFields[k].push(obj.user[k][i]);
										} else {
											self.fileFields[k] = [];
											self.fileFields[k].push(obj.user[k][i]);
										}
		  							}
		  						}
							} else {
								if (obj.user._type[k] != "file") {
									values.attributeName.push(k)
									values.attributeValue.push(obj.user[k])
									values.attributeType.push(obj.user._type[k])
								} else {
									if (self.fileFields[k]) {
										self.fileFields[k].push(obj.user[k]);
									} else {
										self.fileFields[k] = [];
										self.fileFields[k].push(obj.user[k]);
									}
								}								
							}
						} else {
							values[k] = obj.user[k]
						}
					}
				}	
				
				deferred.resolve(values);
				
			}, function(responseMetadata) {
				self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail);
				self.showAsBusy(false);
				dojo.reject(responseMetadata);	
			})
		} else {
			if (self.options && self.options.values) {
				deferred.resolve(self.options.values);
			} else {
				deferred.resolve({});
			}
		}
		
		return deferred;
	},
	
	reloadData: function(login, values) {
		//we had to reload the data by reopening the form in order for the MultipleFile attachment widget to work
		//we faced issues with the widget when just setting the values of a certain document in the form generator 
		var self = this;
		
		if (login) {
			var params = {
				title: "Edit User",
				displayGroup: "editUser",
				label: "Edit User: " + login,
				update: true
			};
			
			if (values) {
				params.values = values;
			} else {
				params.login = login;
			}
			
			self.options.parentList.openPanel(apstrata.workbench.manageAccount.UsersForm, params);
		} else {
			if (!values) {
				values = {};
			}
			
			var params = {
				title: "New User",
				displayGroup: "newUser",
				label: "New User",
				values: values,
				fileFields: self.fileFields
			};
			
			self.options.parentList.openPanel(apstrata.workbench.manageAccount.UsersForm, params);
							
		} 
	},


	addFileFieldHandler: function(event) {
		this.addFileField("apsdb_attachments", "", false);	
	},
	
	
	addFileField: function(name, value, disableFieldName) {
		
		dojo.place("<br>", this.dvAddFileButton, "before");	
		
		var login = this._form.value["login"];
		
		var fileWidget = new apstrata.ui.forms.FileField({
			connection: this.container.connection,
			dockey: login,
			name: name,
			displayImage: false,
			showFieldName: true,
			value: value,		
			style: "border-style:dashed; border-width:1px; border-color:grey; padding:10px;",
			showRemoveFieldBtn: true
		});		
		
		fileWidget._displayAttachedFile(true);
		
		if (disableFieldName) {
			dojo.attr(fileWidget.filefieldName, "readonly", "readonly");
		}
		
		dojo.place(fileWidget.domNode, this.dvAddFileButton, "before");
	},
	
	
	_getReady: function() {
		
		this._form._setFormFileEncType();
		
		//Add label for attachments section
		var dv = dojo.create("div", {innerHTML:"<br><div style='font-weight:bold;'>Attached Files:</div>"});
		dv = dojo.place(dv, this._form.dvActions, "first");
		
		//Add button for adding attachments
		var addFileBtn = new dijit.form.Button({"label": "+"});
		this.dvAddFileButton = dojo.place(addFileBtn.domNode, dv, "last");
		dojo.connect(addFileBtn, "onClick", this, "addFileFieldHandler");
		
		var login = this._form.value["login"];
		if (!login) {
			return;
		}
		
		for (var fileFieldName in this.fileFields) {
			for (var k = 0; k < this.fileFields[fileFieldName].length; k++) {
				this.addFileField(fileFieldName, this.fileFields[fileFieldName][k], true);
			}
			
		}		
	}
		
})


/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.UsersList")

dojo.require("apstrata.workbench.manageAccount.AdminList")

dojo.require("apstrata.sdk.AdminStore")

dojo.require("apstrata.workbench.manageAccount.AdminForm")
dojo.require("apstrata.workbench.manageAccount.UsersForm")
 
dojo.declare("apstrata.workbench.manageAccount.UsersList",
[apstrata.workbench.manageAccount.AdminList], 
{	
	//
	// widget attributes
	//
	filterable: true,
	sortable: true,
	editable: true,

	newObjectPanel: null,
	
	// index of the essential item properties
	idAttribute: 'login',
	labelAttribute: 'login',
	
	// params sent to documentation widget to display contextual information
	docTopic: "",
	docId: "",

	constructor: function() {
		var self = this

		this.store.setType("users")
	},
	
	isItemDeleteable: function(item) {
		return true
	},

	isItemEditable: function(item) {
		return false
	},

	getId: function(item) {return item.login[0]},
	getLabel: function(item) {return item.login[0]},
		
	onNew: function() {
		var self = this	

		self.openPanel(apstrata.workbench.manageAccount.UsersForm, {
			title: "New User",
			displayGroup: "newUser",
			label: "New User"
		})
	},

	onClick: function(id, args) {
		var self = this	
		
		self.openPanel(apstrata.workbench.manageAccount.UsersForm, {
				title: "Edit user",
				displayGroup: "editUser",
				label: "Edit User: "+id,
				update: true,
				login: id
		})	
	}
	
})



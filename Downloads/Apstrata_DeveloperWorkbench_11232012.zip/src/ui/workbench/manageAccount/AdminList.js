/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.AdminList")

dojo.require("apstrata.horizon.NewList")
dojo.require("apstrata.sdk.AdminStore")
 
dojo.declare("apstrata.workbench.manageAccount.AdminList",
[apstrata.horizon.NewList], 
{	
	
	//
	// widget attributes
	//
	filterable: true,
	sortable: true,
	editable: true,
	
	// params sent to documentation widget to display contextual information
	docTopic: "",
	docId: "",
	
	labelAttribute: "name",
	idAttribute: "name",
	
	constructor: function(attrs) {
		var self = this
		
		this.store = new apstrata.sdk.AdminStore({
			connection: self.container.connection
		})
	},

	postCreate: function() {
		var self = this

		dojo.addClass(this.domNode, "AdminList")

		dojo.publish("/apstrata/documentation/topic", [])

		this.inherited(arguments)
	},

	getId: function(item) {return item.name},
	getLabel: function(item) {return item.name},
		
	
	onChangeLabel: function(id, oldLabel, newLabel) {
		var self = this
		new apstrata.horizon.PanelAlert({
			panel: self,
			width: 320,
			height: 140,
			message: "Are you sure you want to change: " + '[' + oldLabel + "] to [" + newLabel + "] ?",
			iconClass: "editIcon",
			actions: ['Yes', 'No'],
			actionHandler: function(action) {
				if (action=='Yes') {
					self.changeItemLabel(id, newLabel)
					self.setEditMode(false)
				} else {
					self.revertItemEdit()
				}
			}
		})
	},

	onDeleteItem: function(id, item) {
		var self = this
		new apstrata.horizon.PanelAlert({
			panel: self,
			width: 320,
			height: 150,
			title: "Delete [" + id + "]?",
			iconClass: "deleteIcon",
			message: "This operation is not reversible.",
			actions: [ 'Confirm', 'Cancel' ],
			actionHandler: function(action) {
				if (action == 'Confirm') {
					self.showAsBusy(true, "deleting item...")
					
					dojo.when(
						self.deleteItem(id),
						function() {
							self.showAsBusy(false)
						},
						function() {
							self.showAsBusy(false)
						}
					)
				}
			}
		})
	}	
})


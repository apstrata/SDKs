/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.StoresEditForm")

dojo.require("apstrata.workbench.manageAccount.AdminForm")
 
dojo.declare("apstrata.workbench.manageAccount.StoresEditForm",
[apstrata.workbench.manageAccount.AdminForm], 
{	
	constructor: function(args) {
		var self = this
		
		this.storeName = args.storeName;
		
		this.store.setType("storesConfig")
		
		self.options = dojo.mixin(self.options, args)
		
		self.options = dojo.mixin(self.options, {
			definitionPath: dojo.moduleUrl("apstrata.workbench.manageAccount", "formDefinitions/StoresConfig.json"),
			actions: ['save'],
			title: "Edit store configuration",
			label: "Edit store configuration",
			
			save: function(values, formGenerator){
				self.showAsBusy(true, "saving store configuration")
		
				values.store = self.storeName
				 
				self.store.put(values).then(
					function(result) {
						self.showAsBusy(false)
					},
					function(responseMetadata) {
						self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
						self.showAsBusy(false)
					}
				)
			}
		})
		
	},
	
	prepareFormData: function() {
		var self = this

		var deferred = new dojo.Deferred();
		
		self.showAsBusy(true, "retrieving store configuration")
		dojo.when(
			this.store.get(self.storeName),
			function(response) {
				self.showAsBusy(false);
				deferred.resolve(response.storeConfig);
			},
			function(responseMetadata) {
				self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail);
				self.showAsBusy(false);	
				deferred.reject(responseMetadata);
			}
		)
		
		return deferred;
	}
})

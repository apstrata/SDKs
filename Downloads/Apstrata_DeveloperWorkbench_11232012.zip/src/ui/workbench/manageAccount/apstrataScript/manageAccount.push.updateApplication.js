<script>
<scriptACL>  
	<execute>authenticated-users</execute>
	<read>nobody</read>
	<write>nobody</write>
</scriptACL>
<code><![CDATA[
	
	/*
	 * This script updates the certificate (application document). If a series of channels
	 * to remove was sent along the request, they are removed before updating the certificate
	 * document. The removals and update are executed withing transactional boundaries
	 */
	
	// This function removes a single channel document
	function removeChannel(channelDocKey) {
		
		var deleteParams = {
				"apsdb.store" : store,
				"apsdb.documentKey" : channelDocKey
			};
				
		var deleteChannelResponse = apsdb.callApi("DeleteDocument", deleteParams, null);
				
		//debug zone
		apsdb.log.debug("Removing channel " + channelDocKey);
		apsdb.log.debug("Delete channel response",  deleteChannelResponse);
		// end of debug zone
							
		if (deleteChannelResponse.metadata.status == "failure"){
			var errorDetails = deleteChannelResponse.metadata.errorDetail;
			var errorCode = deleteChannelResponse.metadata.errorCode;
			var error = errorDetails ? errorDetails : errorCode;
			throw { error : error};
		}
	}
	
	function isArray(obj){
		return (Object.prototype.toString.call(obj) === '[object Array]' );
	}
	
	// main logic
	if (request["logLevel"]) {
		apsdb.log.setLogLevel(request["logLevel"]); 
	}
		
	var response = {};
	var transaction = null;
	try{			
		// Retrieve the parameters to be used in UpdateCertificate
		var store = request.parameters["store"];
		if (!store) {
			store = "DefaultStore";
		}
		
		var updateCertParams = {};
		updateCertParams ["apsdb.store"] = store;
		updateCertParams ["applicationID"] = request.parameters["applicationID"];
		updateCertParams ["password"] = request.parameters["password"];
		
		// Retrieve the list of channels ids to remove
		var channelsToRemove = request.parameters["channelsToRemove"];
						
		// Retrieve the certificate file
		var attachedCertificate = {};	
		if (request.files && request.files.apsdb_attachments){			
			attachedCertificate["apsdb_attachments"] = request.files.apsdb_attachments;
		}
		
		// Begin a transaction to remove all channels then update the certificate document (application)
		transaction = apsdb.beginTransaction();
		
		// first step, remove the channels if any
		if (channelsToRemove){
			if (isArray(channelsToRemove)){
				apsdb.log.debug("channels array : ", channelsToRemove);
				for (var index=0; index < channelsToRemove.length; index++){
					removeChannel(channelsToRemove[index]);	
				}
			}else {
				removeChannel(channelsToRemove);
			}
		}
		
		// second step, update the certificate document (application)
		if (attachedCertificate){
			response = apsdb.callApi("UpdateCertificate", updateCertParams , attachedCertificate);
		}else {
			response = apsdb.callApi("UpdateCertificate", updateCertParams);	
		}
		
		if (response.metadata.status == "failure") {
			var errorDetails = response.metadata.errorDetail;
			var errorCode = response.metadata.errorCode;
			var error = errorDetails ? errorDetails : errorCode;
			throw { error : error};	
		}
		
		transaction.commit();
			
	}catch (e){
		if (transaction) {
			transaction.rollback();
		}
		response = {status : "failure", errorDetail : e};
	}finally {
		return response ;
	}
	
]]></code>
</script>
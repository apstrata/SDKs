dojo.provide("apstrata.workbench.manageAccount.QueryResultsPanel");

dojo.require("apstrata.sdk.ObjectStore");

dojo.require("apstrata.horizon.Grid");
dojo.require("dojox.grid.EnhancedGrid");
dojo.require("dojox.grid.enhanced.plugins.Pagination");
dojo.require("apstrata.horizon.PanelAlert");

dojo.require("apstrata.workbench.manageAccount.DocumentsForm");

dojo.declare("apstrata.workbench.manageAccount.QueryResultsPanel", 
[apstrata.horizon.Grid], 
{
	idProperty: 'key',
	labelProperty: 'title',
	
	maximizable: true,

	constructor: function(attrs) {
		var self = this;
		
		dojo.mixin(this, attrs);
		
		this.editable= true;
		this.gridClass = dojox.grid.EnhancedGrid;
	},
	
	postCreate: function() {
		var self = this;
		
		dojo.style(this.domNode, "width", "600px");
		this.inherited(arguments);
	},
	
	startup: function() {
		var self = this;
		var args = arguments;
		
		self.queryParams["apsdb.pageNumber"] = 1;
		self.prepareStructure().then(
			function() {
				var storeParams = {
					connection: self.container.connection,
					store: self.queryParams["apsdb.store"],
					resultsPerPage: self.queryParams["apsdb.resultsPerPage"],
					queryExpression: self.queryParams["apsdb.query"],
					queryFields: self.queryParams["apsdb.queryFields"],
					runAs: self.queryParams["apsdb.runAs"],
					// used to indicate the sort type to be applied to a column
					fieldTypes: self.fieldsTypeObject
				};
				
				var searchExpression = self.queryParams["apsdb.ftsQuery"]; 
				if (searchExpression) {
					storeParams.ftsQuery = searchExpression;
				}
				
				self.gridParams = {
					rowsPerPage: self.queryParams["apsdb.resultsPerPage"],
					
					store:  new apstrata.sdk.ObjectStoreAdaptor({objectStore: new apstrata.sdk.ObjectStore(storeParams)}),
					
					structure: [
						// view 1
						{ cells: [ new dojox.grid.cells.RowIndex({width: "30px"}) ], noscroll: true},
						self.fieldsStructure
					],
					
					
					plugins: {
						pagination: {
							pageSizes: ["10", "25", "50", "100"],	// Array, custom the items per page button
							itemTitle: "docs", 	// String, custom the item' title of description
							description: "100px",	// boolean, custom whether or not the description will be displayed
							sizeSwitch: "100px",	// boolean, custom whether or not the page size switch will be displayed
							pageStepper: "100px",	// boolean, custom whether or not the page step will be displayed
							gotoButton: true,	// boolean, custom whether or not the goto page button will be displayed
							maxPageStep: 7,		// Integer, custom how many page step will be displayed
							position: "bottom"	// String, custom the position of the pagination bar
													// there're three options: top, bottom, both
							// ,descTemplate: "${1} ${0}" // A template of the current position description.
						}
					},
					
					
					rowSelector: "15px"
				};
				
				self.inherited(args);
				
				if (searchExpression) {
					self._filter.frmSearch.set("value", {"search": searchExpression});
				}
				
				self.paginationPlugin = self._grid.plugin("pagination"); 
				self.paginationPlugin.originalGotoPage = self.paginationPlugin.gotoPage
				self.paginationPlugin.originalChangePageSize = self.paginationPlugin.changePageSize
			
				//override the gotoPage function of the pagination plugin
				self.paginationPlugin.gotoPage = function(pageIndex) {
					self.queryParams["apsdb.pageNumber"] = pageIndex;
					self.prepareStructure().then(
						function() {
							self._grid.store.objectStore.fieldTypes = self.fieldsTypeObject;
			
							var structure = [
									// view 1
									{ cells: [ new dojox.grid.cells.RowIndex({width: "30px"}) ], noscroll: true},
									self.fieldsStructure
								];
								
							self.paginationPlugin.originalGotoPage(pageIndex);
							self._grid.setStructure(structure);		
						}, 
						function(responseMetadata) {
							self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail);
						}
					);
				}
				
				//override the changePageSize function of the pagination plugin	
				self.paginationPlugin.changePageSize = function(pageSize) {
						self.queryParams["apsdb.resultsPerPage"] = pageSize;	
						self.queryParams["apsdb.pageNumber"] = 1;	
						self._grid.store.objectStore.resultsPerPage = pageSize;
						self.prepareStructure().then(
							function() {
								self._grid.store.objectStore.fieldTypes = self.fieldsTypeObject;
				
								var structure = [
										// view 1
										{ cells: [ new dojox.grid.cells.RowIndex({width: "30px"}) ], noscroll: true},
										self.fieldsStructure
									];
									
								self.paginationPlugin.originalChangePageSize(pageSize);
								self._grid.setStructure(structure);		
							}, 
							function(responseMetadata) {
								self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail);
							}
						);
				};	
			},
			function(responseMetadata) {
				self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail);
			}
		);		
	},
	
	prepareStructure: function() {
		var self = this;
		
		var def = new dojo.Deferred();
		
		self.showAsBusy(true, "preparing structure...")
		self.adminStore.query(self.queryParams).then(
			function(documents) {
				self.showAsBusy(false)
				self.fieldsTypeObject = {};
				self.fieldsStructure = [];
				self.fieldsTypes = [];
				
				for(var i = 0 ; i < documents.length; i++) {
					for(var fieldName in documents[i])
					{
						if(documents[i]['_type'][fieldName] && !self.fieldsTypeObject[fieldName]) {
							self.fieldsTypeObject[fieldName] = documents[i]['_type'][fieldName];
							self.fieldsTypes.push(documents[i]['_type'][fieldName]);
							self.fieldsStructure.push({ "field": fieldName, "editable": "false", "width": "auto" });
						}
					}
					
					if (documents[i]["_derivedFields"]) {
						for(var derivedFieldName in documents[i]["_derivedFields"]) {
							if (!self.fieldsTypeObject[derivedFieldName]) {
								self.fieldsTypeObject[derivedFieldName] = "derived";
								self.fieldsTypes.push("numeric");
								self.fieldsStructure.push({ "field": derivedFieldName, "editable": "false", "width": "auto" });
							}							
						}
						
					}
				}
				
				if (self.fieldsStructure.length == 0) {
					if (self.queryParams["apsdb.queryFields"] == "*") {
						self.fieldsStructure.push({ "field": "apsdb.documentKey", "editable": "false", "width": "auto" });
					} else {
						// In case the query fields to return include derived fields (which are formulas with commas),
						// then return only apsdb.documentKey and do not split on commas in order not to make the grid columns messy
						if (self.queryParams["apsdb.queryFields"].indexOf("(") >= 0) {
							self.fieldsStructure.push({ "field": "apsdb.documentKey", "editable": "false", "width": "auto" });
						} else {
							var fields = self.queryParams["apsdb.queryFields"].split(",");
							for (var i = 0; i < fields.length; i++) {
								self.fieldsStructure.push({ "field": fields[i], "editable": "false", "width": "auto" });
							}
						}
					}
				}
				
				def.resolve(documents);

			},
			function(responseMetadata) {
				self.showAsBusy(false)
				def.reject(responseMetadata)
			}
		)
		
		return def;			
	},
	
	filter: function(attr) {
		var self = this;
		
		var search = attr.search.trim();
		self._grid.store.objectStore.ftsQuery = search; 
		self.queryParams["apsdb.ftsQuery"] = search;
		self.queryParams["apsdb.pageNumber"] = 1;
		self.prepareStructure().then(
			function() {
				self._grid.store.objectStore.fieldTypes = self.fieldsTypeObject;
		
				var structure = [
						// view 1
						{ cells: [ new dojox.grid.cells.RowIndex({width: "30px"}) ], noscroll: true},
						self.fieldsStructure
					];
					
				self._grid.setStructure(structure);					
			},
			function(responseMetadata) {
				self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail);
			}
		);		
	},
	
	newItem: function() {
		var self = this;
		self.openPanel(apstrata.workbench.manageAccount.DocumentsForm, {
			title: "New Document",
			label: "New Document",
			storeName: self.queryParams["apsdb.store"],
			runAs: self.queryParams["apsdb.runAs"]
		})					
	},
	
	
	editItem: function(key, versionNumber) {
		var self = this;
		self.openPanel(apstrata.workbench.manageAccount.DocumentsForm, {
				title: "Edit Document",
				label: "Edit Document",
				update: true,
				dockey: key + (versionNumber ? "|" + versionNumber : ""),
				storeName: self.queryParams["apsdb.store"],
				runAs: self.queryParams["apsdb.runAs"]
			})	
			
	},
	
	
	editItems: function() {
		var self = this;
		var selection = self._grid.selection.getSelected();
		if (selection && selection.length > 0) {
			self.editItem(selection[0].key, Math.floor(selection[0].versionNumber));
		}
	},
	
	
	deleteItems: function() {
		var self = this;
		var args = arguments;
		
		
		self.inherited(args).then(
			function() {
				self.prepareStructure().then(
					function() {
						self._grid.store.objectStore.fieldTypes = self.fieldsTypeObject;
				
						var structure = [
								// view 1
								{ cells: [ new dojox.grid.cells.RowIndex({width: "30px"}) ], noscroll: true},
								self.fieldsStructure
							];
							
						self._grid.setStructure(structure);							
					},
					function(responseMetadata) {
						self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail);
					}
				);		
			},
			function(response) {
				if (response.metadata) {
					self.displayError(response.metadata.errorCode, response.metadata.errorDetail);
				} else if (response.errorCode) {
					self.displayError(response.errorCode, response.errorDetail);					
				}
			}
		);
	}, 
	
	refresh: function() {
		var self = this;
		self._grid.setStructure(self._grid.structure);	
	}
					
});



/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.manageAccount.GroupsForm")

dojo.require("apstrata.workbench.manageAccount.AdminForm")
 
dojo.declare("apstrata.workbench.manageAccount.GroupsForm",
[apstrata.workbench.manageAccount.AdminForm], 
{	
	constructor: function(args) {
		var self = this
		
		
		this.store.setType("groups")
		
		self.options = dojo.mixin(self.options, args)
		
		self.options = dojo.mixin(self.options, {
			definitionPath: dojo.moduleUrl("apstrata.workbench.manageAccount", "formDefinitions/SaveGroup.json"),
			actions: ['save'],
			title: "Create new group",
			label: "New Group",
			
			save: function(values, formGenerator){
				formGenerator.showAsBusy(true)
				self.store.put(values).then(
					function() {
						self.options.parentList.reload()
						self.options.parentList.closePanel()
						formGenerator.showAsBusy(false)
					},
					function(responseMetadata) {
						self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
						formGenerator.showAsBusy(false)	
					}
				)
			}
		})
		
	}
})


dojo.provide("apstrata.workbench.manageAccount.ScriptEditorPanel")

dojo.require("apstrata.workbench.manageAccount.CodeEditorPanel")
dojo.require("apstrata.workbench.manageAccount.ScriptRunnerPanel")

/**
 * Provides a code viewer panel to show sample code of an Apstrata call
 * 
 * @param {Object} attrs
 */
dojo.declare("apstrata.workbench.manageAccount.ScriptEditorPanel", 
[apstrata.workbench.manageAccount.CodeEditorPanel], 
{
	_runButton: "",
	
	constructor: function(options) {
		var self = this
		this.options = options
		if (this.options.target) {
			this._id = this.options.target
		}
		
		if (this.options.update) {
			this._update = this.options.update
		}
		 
		this.store.setType("scripts")
	},
	
	postCreate: function() {
		var self = this
		
		var dvButton = new dijit.form.Button({
			label: "Run",
			onClick: function() {
				self.openPanel(apstrata.workbench.manageAccount.ScriptRunnerPanel, {action : "RunScript", target:self.fldName.get("value"), update: self._update});				
			}
		})
		
		if (!self._update)
			dvButton.setDisabled(true);

		self._runNodeId = dojo.place(dvButton.domNode, this.dvActionBar)
		self._runButton = dvButton
		this.inherited(arguments)
	},
	
	setCode: function(code) {
		this._id = code.id
		this.txtEditor.set("value", code.script)
		this.fldName.set("value", code.id)
	},
	
	saveCode: function() {
		var self = this
		
		var nameChange = false
		if (this._id) {
			nameChange = (this._id != self.fldName.get("value"))
		} 
		
		var theScriptName = ""
		var theScriptNewName = ""
		
		if (nameChange) {
			theScriptName = this._id
			theScriptNewName = 	self.fldName.get("value")
		} else {
			theScriptName = self.fldName.get("value")
		}
		
		var attr = {
			"apsdb.scriptName": theScriptName, 
			"apsdb.script": editAreaLoader.getValue(self.txtEditor.id)
		}

		if (theScriptNewName) attr["apsdb.newScriptName"] = theScriptNewName
		if (this._update) attr["apsdb.update"] = true
		
		self.showAsBusy(true, "saving...")		
		dojo.when(
			self.store.put(attr),
			function(success) {
				self.showAsBusy(false)
				
				//this is required so that the updated script definition gets set in the editor upon resizing of the panel
				self._code = {
					id: self.fldName.get("value"),
					script: editAreaLoader.getValue(self.txtEditor.id)
				}
				
				self._id = self.fldName.get("value")		
				if (!self._update || nameChange) {
					self.getParent().reload()								
				}
				
				if (self._update) {
					self.getParent().highlight(self._id)
				}
				
				self._update = true
				self._runButton.setDisabled(false);
			},
			function(responseMetadata) {
				self.displayError(responseMetadata.errorCode, responseMetadata.errorDetail)
				self.showAsBusy(false)

			}
		)
	}
})
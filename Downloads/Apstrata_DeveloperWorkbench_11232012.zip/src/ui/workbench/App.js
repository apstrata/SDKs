/*******************************************************************************
 *  Copyright 2009 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.App")

dojo.require("apstrata.horizon.Container")
dojo.require("apstrata.workbench.Menu")

dojo.require("apstrata.sdk.Client")
//dojo.require("apstrata.Client")

//dojo.require("apstrata.horizon.Preferences")

dojo.declare("apstrata.workbench.App", 
[apstrata.horizon.Container], 
{
	applicationId: "apstrataWorkbench",
	connection: {},
	
	constructor: function(attrs) {
		dojo.mixin(this, attrs)

		this.connection = new apstrata.sdk.Connection()
		this.client = new apstrata.sdk.Client(this.connection)
	},
	
	onCredentials: function(credentials) {		
		var serviceURL = apstrata.apConfig["apstrata.sdk"].Connection.serviceURL;
		var timeout = apstrata.apConfig["apstrata.sdk"].Connection.timeout;
		this.connection = new apstrata.sdk.Connection({credentials: credentials, serviceURL: serviceURL, timeout: timeout, loginType: apstrata.sdk.Connection.prototype._LOGIN_TYPE_MASTER});		
		
		var item = {
			id:"logout", 
			label: "Logout", 
			iconSrc: apstrata.baseUrl+"/../horizon/resources/images/pencil-icons/logout.png"
		};
		
		try {
			this.main.addItem(item);
		} catch (e) {
			//catch the exception that results from adding the logout item when it already exists and do nothing about it
		}	
	},
	
	overridePreferences: function (urlParams) {
	
		if (urlParams && urlParams["key"]) {
			
			dojo.require("apstrata.sdk.Client");		
			var newCredentials = {
				key : urlParams["key"],			
			};
			
			apstrata.apConfig["apstrata.sdk"].Connection.credentials = newCredentials;
			this.loginWidget.form.set("value", apstrata.registry.get("apstrata.sdk", "Connection").credentials)		
		}	
		
		if (urlParams && urlParams["serviceUrl"]) {
			apstrata.apConfig["apstrata.sdk"].Connection.serviceURL = decodeURIComponent(urlParams["serviceUrl"]);
		}
	},
	
	startup: function() {
		var urlParams = dojo.queryToObject(location.search.substr(1));
		this.overridePreferences(urlParams);
				
		this.addMainPanel(apstrata.workbench.Menu)
		this.inherited(arguments)
	},
	
	logout: function() {
		try {
			this.main.deleteItem('logout');
		} catch (e) {
			//catch the exception that results from deleting the logout item when it does not exist and do nothing about it
		}
		
		apstrata.apConfig["apstrata.ui"]["widgets.Login"].autoLogin = false;
		loginWidget = new apstrata.ui.widgets.LoginWidget({type: "master"});
		this.loginWidget = loginWidget;
		this.startup();
		this.layout();
	}
})






dojo.provide("apstrata.workbench.apiExplorer.APIExplorerMenu")

dojo.require('apstrata.workbench.apiExplorer.APIExplorerPanel')
dojo.require('apstrata.workbench.apiExplorer.DocViewerPanel')

dojo.declare("apstrata.workbench.apiExplorer.APIExplorerMenu", 
[apstrata.horizon.List], 
{
	constructor: function(args) {
		var self = this
		//
		// widget attributes
		//
		this.filterable = true
		this.sortable = false
		this.editable = false

		var actions = [ 
			{ action: "AddCertificate", iconClass: "pushnotification" },
			{ action: "CreateChannel", iconClass: "pushnotification" },
			{ action: "CreateStore", iconClass: "persistence" }, 
			{ action: "DeleteDocument", iconClass: "persistence" }, 
			{ action: "DeleteGroup", iconClass: "identity" }, 
			{ action: "DeleteSavedQuery", iconClass: "persistence" }, 
			{ action: "DeleteSchema", iconClass: "persistence" }, 
			{ action: "DeleteScript", iconClass: "orchestration" }, 
			{ action: "DeleteStore", iconClass: "persistence" }, 
			{ action: "DeleteToken", iconClass: "identity" }, 
			{ action: "DeleteUser", iconClass: "identity" },
			{ action: "GetChannel", iconClass: "pushnotification" }, 
			{ action: "GetFile", iconClass: "persistence" }, 
			{ action: "GetInvalidTokens", iconClass: "pushnotification" },
			{ action: "GetSavedQuery", iconClass: "persistence" }, 
			{ action: "GetSchema", iconClass: "persistence" }, 
			{ action: "GetScript", iconClass: "orchestration" }, 
			{ action: "GetScriptLogs", iconClass: "orchestration" },
			{ action: "GetUser", iconClass: "identity" }, 
			{ action: "ListConfiguration", iconClass: "configuration" }, 
			{ action: "ListGroups", iconClass: "identity" }, 
			{ action: "ListSavedQueries", iconClass: "persistence" }, 
			{ action: "ListSchemas", iconClass: "persistence" }, 
			{ action: "ListScripts", iconClass: "orchestration" }, 
			{ action: "ListStores", iconClass: "persistence" }, 
			{ action: "ListUsers", iconClass: "identity" }, 
			{ action: "PushNotification", iconClass: "pushnotification" },
			{ action: "Query", iconClass: "persistence" }, 
			{ action: "RemoveCertificate", iconClass: "pushnotification" },
			{ action: "RemoveChannel", iconClass: "pushnotification" },
			{ action: "RunScript", iconClass: "orchestration" }, 
			{ action: "SaveConfiguration", iconClass: "configuration" }, 
			{ action: "SaveDocument", iconClass: "persistence" }, 
			{ action: "SaveGroup", iconClass: "identity" }, 
			{ action: "SaveQuery", iconClass: "persistence" }, 
			{ action: "SaveSchema", iconClass: "persistence" }, 
			{ action: "SaveScript", iconClass: "orchestration" }, 
			{ action: "SaveUser", iconClass: "identity" }, 
			{ action: "SendEmail", iconClass: "messaging" }, 
			{ action: "SubscribeTokens", iconClass: "pushnotification" },
			{ action: "TagTokensAsInvalid", iconClass: "pushnotification" },
			{ action: "Transaction", iconClass: "persistence" }, 
			{ action: "UnsubscribeTokens", iconClass: "pushnotification" },
			{ action: "UpdateCertificate", iconClass: "pushnotification" },
			{ action: "UpdateChannel", iconClass: "pushnotification" },
			{ action: "VerifyCredentials", iconClass: "identity" } 
		]
		
		var items = []
		for (var i=0; i<actions.length; i++) {
			var item = {
				id: actions[i].action, 
				label: actions[i].action, 
				iconClass: actions[i].iconClass 
			}
			
			items.push(item)
		}

		this.store = new dojo.store.Memory({data: items})
	},
	
	postCreate: function() {
		dojo.addClass(this.domNode, "apiMenu")
		this.inherited(arguments)
	},

	onClick: function(index, id, args) {
		var self = this	

		if (args && !args.menuItemId) args.menuItemId = id;
		if (this.store) dojo.when(
			this.store.get(id),
			function(item) {
				self.openPanel(apstrata.workbench.apiExplorer.APIExplorerPanel, {id: id})
			}			
		)
	}
})


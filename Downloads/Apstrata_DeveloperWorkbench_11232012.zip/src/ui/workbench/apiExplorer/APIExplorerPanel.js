/*******************************************************************************
 *  Copyright 2009-2011 Apstrata
 *  
 *  This file is part of Apstrata Database Javascript Client.
 *  
 *  Apstrata Database Javascript Client is free software: you can redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *  
 *  Apstrata Database Javascript Client is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Apstrata Database Javascript Client.  If not, see <http://www.gnu.org/licenses/>.
 * *****************************************************************************
 */
dojo.provide("apstrata.workbench.apiExplorer.APIExplorerPanel")

dojo.require("apstrata.horizon.Panel")
dojo.require("apstrata.workbench.apiExplorer.FormGenerator")

dojo.declare("apstrata.workbench.apiExplorer.APIExplorerPanel", 
[apstrata.horizon.Panel], 
{
	maximizePanel: false,
//	contentTemplateString: "<div><div dojoAttachPoint='dvTopButtons'></div><div dojoAttachPoint='dvForm'></div><div dojoAttachPoint='dvLowerButtons'></div></div>",
	constructor: function(attrs) {
		this.action = attrs.id
	},
	
	_loadDefinition: function() {
		var self = this

		 // The parameters to pass to xhrGet, the url, how to handle it, and the callbacks.
		  var xhrArgs = {
            url: "workbench/apiExplorer/dictionnary/"+self.action+".json",
		    handleAs: "json",
            timeout: 5000
		  }
		
		  // Call the asynchronous xhrGet
		  return dojo.xhrGet(xhrArgs);
	},

	postCreate: function() {
		var self = this

		dojo.addClass(this.domNode, "APICall")
		
		this.dvForm = dojo.create("div", {}, this.dvContent)
		this.dvTopButtons = dojo.create("div", {}, this.dvContent)
		this.dvLowerButtons = dojo.create("div", {}, this.dvContent)
		
		dojo.when(
			this._loadDefinition(),
			function(def){
				self.formGenerator = new apstrata.workbench.apiExplorer.FormGenerator({formDef: def, action: self.action, parent: self})
				dojo.place(self.formGenerator.domNode, self.dvForm)
				self._addLowerButtons()			
			},
			function(a) {
			}
		)
		self._addTopButtons()
		
		this.inherited(arguments)
	},
	
	_addTopButtons: function() {
		var self = this
		this._submit = new dijit.form.Button({
			label: "View Documentation",
			onClick: function() {
				self.openPanel(apstrata.workbench.apiExplorer.DocViewerPanel, {
					action: self.action
				})
			}
		})
		dojo.place(this._submit.domNode, this.dvTopButtons)
	},
	
	_addLowerButtons: function() {
		var self = this

		this._submit = new dijit.form.Button({
			label: "View JavaScript Code",
			onClick: function() {
				self.openPanel(apstrata.workbench.apiExplorer.CodeViewerPanel, {
					credentials: self.getContainer().connection.credentials,
					serviceURL: self.getContainer().connection.serviceURL,
					timeout: self.getContainer().connection.timeout,
					loginType: apstrata.sdk.Connection.prototype._LOGIN_TYPE_MASTER,
					callAttrs: {
						action: self.action,
						request: self.formGenerator.get("value"),
						codeTemplatePath: dojo.moduleUrl("apstrata.workbench.apiExplorer","codeTemplates/javascript.txt")
					}
				})
			}
		})
		dojo.place(this._submit.domNode, this.dvLowerButtons)

		this._submit = new dijit.form.Button({
			label: "View Android Code",
			onClick: function() {
				self.openPanel(apstrata.workbench.apiExplorer.CodeViewerPanel, {
					credentials: self.getContainer().connection.credentials,
					serviceURL: self.getContainer().connection.serviceURL,
					timeout: self.getContainer().connection.timeout,
					loginType: apstrata.sdk.Connection.prototype._LOGIN_TYPE_MASTER,
					callAttrs: {
						action: self.action,
						request: self.formGenerator.get("value"),
						codeTemplatePath: dojo.moduleUrl("apstrata.workbench.apiExplorer","codeTemplates/android.txt")
					}
				})
			}
		})
		dojo.place(this._submit.domNode, this.dvLowerButtons)

		this._submit = new dijit.form.Button({
			label: "Run",
			onClick: function() {
				self.openPanel(apstrata.workbench.apiExplorer.CodeRunnerPanel, {
					credentials: self.getContainer().connection.credentials,
					serviceURL: self.getContainer().connection.serviceURL,
					timeout: self.getContainer().connection.timeout,
					callAttrs: {
						action: self.action,
						request: self.formGenerator.get("value")
					}
				})
			}
		})
		dojo.place(this._submit.domNode, this.dvLowerButtons)
	},

	startup: function() {
		this.resize()
		this.inherited(arguments)
	}
})









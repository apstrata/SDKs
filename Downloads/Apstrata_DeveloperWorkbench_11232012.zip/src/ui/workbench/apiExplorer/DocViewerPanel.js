dojo.provide("apstrata.workbench.apiExplorer.DocViewerPanel")

dojo.require("dojox.dtl._Templated")

/**
 * Provides a code viewer panel to show sample code of an Apstrata call
 * 
 * @param {Object} attrs
 */
dojo.declare("apstrata.workbench.apiExplorer.DocViewerPanel", 
[apstrata.horizon.Panel], 
{
	contentTemplateString: "<div><div class='name'>{{ action }}</div><div dojoAttachPoint='dvWikiContent'></div></div>",
	
	constructor: function(attrs) {
		console.dir(attrs)
		dojo.mixin(this, attrs)
		//attrs.parent = this
	},
	
	postCreate: function() {
		var self = this
		dojo.addClass(this.domNode, "DocViewerPanel")
		// The parameters to pass to xhrGet, the url, how to handle it, and the callbacks. 591 31 30
		var xhrArgs = {
			url: "workbench/apiExplorer/wikiProxy.php?api="+self.action,
			handleAs: "text",
			timeout: 5000
		}
		this._xhrLoad = dojo.xhrGet(xhrArgs)
		this.inherited(arguments)
	},
	
	onAnimationEnd: function() {
		var self = this
		
		this.showAsBusy(true)
		
		dojo.when (
			this._xhrLoad,
			function(text) {
				self.dvWikiContent.innerHTML = text
				self.showAsBusy(false)
			},
			function() {
				self.showAsBusy(false)
			}
		)
		
		this._xhrLoad.then(function(text) {
			self.dvWikiContent.innerHTML = text
			self.showAsBusy(false)
		})
		
	}
})
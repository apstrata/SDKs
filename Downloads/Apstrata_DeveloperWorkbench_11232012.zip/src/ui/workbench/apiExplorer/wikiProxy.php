<?php 

include ('../../lib/simplehtmldom/simple_html_dom.php');

$url = "http://wiki.apstrata.com/display/doc/" . $_GET['api'];
$html = file_get_html ($url);

$content = $html->find('.wiki-content'); 

$expandControl = $content[0]->find('.expand-control');
$expandControl[0]->innertext = '';

$codeBlocks = $content[0]->find('.code');
foreach ($codeBlocks as $block) {
	$scripts = $block->find('script');
	foreach ($scripts as $script) {
		$script->tag = 'div';
		$script->innertext = str_replace('<![CDATA[', '', $script->innertext);
		$script->innertext = str_replace(']]>', '', $script->innertext);
		
		//For the post parameters section, split each parameter and its value on a separate line
		if (!(strpos($script->innertext, '=') === FALSE ) && (strpos($script->innertext, '?') === FALSE) && (strpos($script->innertext, 'response') === FALSE)) {  
			$elements = explode('=', $script->innertext);
			$text = '';
			for ( $counter = 0; $counter < count($elements); $counter += 1) {
				//echo $elements[$counter] . '<br/>';
				if ($counter == 0) {
					$text = $text . $elements[$counter] . ' = ';
				} else {
					$temp = explode(' ', trim($elements[$counter]));
					$text = $text . $temp[0] . '<br/>';
					if (count($temp) > 1) {
						$text = $text . $temp[1] . ' = ';
					}
				}
			}
			
			$script->innertext = $text;
		}
	}
	$block->class = null;
	$block->style = 'display:block';	
}


//Rewrite links in documentation
$anchors = $content[0]->find('a');
foreach ($anchors as $link) {
	$link->target = '_new';
	if ((strpos($link->href, 'http://') === FALSE ) && (strpos($link->href, 'https://') === FALSE)) {  
		$link->href = 'http://wiki.apstrata.com' . $link->href;
	}
}

echo $content[0];
 
?>

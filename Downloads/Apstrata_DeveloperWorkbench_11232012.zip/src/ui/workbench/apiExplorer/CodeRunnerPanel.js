dojo.provide("apstrata.workbench.apiExplorer.CodeRunnerPanel")

dojo.require("dojox.dtl._Templated")
dojo.require("apstrata.horizon.Panel")

dojo.require("dojox.highlight");
dojo.require("dojox.highlight.languages.pygments._www");


/**
 * 
 * @param {Object} attrs
 */
dojo.declare("apstrata.workbench.apiExplorer.CodeRunnerPanel", 
[apstrata.horizon.Panel], 
{
	widgetsInTemplate: true,
	templatePath: dojo.moduleUrl("apstrata.workbench.apiExplorer", "templates/CodeRunnerPanel.html"),
	urlGlued: false,
	contentGlued: false,

	constructor: function(attrs) {
		console.dir(attrs)
		dojo.mixin(this, attrs)
		this.contentClipboard = new ZeroClipboard.Client()
		this.urlClipboard = new ZeroClipboard.Client()
		dojo.connect(this, "closePanel", this, function() {
			this.contentClipboard.destroy();
			this.urlClipboard.destroy();
		})
	},
	
	postCreate: function(){
		var self = this
		
		dojo.addClass(this.domNode, "CodeRunnerPanel")

		//clone the credentials so that we do not change those of the container or parent
		var theCredentials = dojo.clone(self.credentials);
		var loginType = apstrata.sdk.Connection.prototype._LOGIN_TYPE_MASTER; 

		//verifying credentials for a particular user
		if (self.callAttrs.action == 'VerifyCredentials') {
			var username = self.callAttrs.request['apsws.user']
			var password = self.callAttrs.request.password
			delete self.callAttrs.request['apsws.user']
			delete self.callAttrs.request.password  
			if (username || password) {
				//if one of username or password is provided, we still want to verify credentials as a user.
				//for the client to sign the request as a user, both should be provided
				if (!username) username = 'xxxxx';
				if (!password) password = 'xxxxx';
				
				theCredentials.user = username;
				theCredentials.password = password;			
				loginType = apstrata.sdk.Connection.prototype._LOGIN_TYPE_USER; 
			}
		} 
		
		var connection = new apstrata.sdk.Connection({credentials: theCredentials, serviceURL: self.serviceURL, timeout: self.timeout, loginType: loginType});
		var client = new apstrata.sdk.Client(connection);
		
		self.callAttrs.useHttpMethod = "GET";
		
		//for API calls that require files to be uploaded, make sure to make them as POST and to specify the form node
		if (self.callAttrs.action == 'AddCertificate' || self.callAttrs.action == 'UpdateCertificate' || self.callAttrs.action == 'SaveDocument' || self.callAttrs.action == 'RunScript' || self.callAttrs.action == 'SendEmail' || self.callAttrs.action == 'SaveScript' || self.callAttrs.action == 'SaveSchema' || self.callAttrs.action == 'SaveQuery' || self.callAttrs.action == 'SaveUser') {
			self.callAttrs.useHttpMethod = "POST";
			self.callAttrs.formNode = self.getParent().formGenerator._form.domNode;
		}
		
		if (self.callAttrs.action == 'GetFile') {
			var url = connection.sign(self.callAttrs.action, dojo.objectToQuery(self.callAttrs.request)).url;
			self.dvCall.innerHTML = '<a href="' + url + '" target="_blank">' + url + '</a>';
			this.urlClipboard.setText(url);
			self.dvResult.innerHTML = 'Please click on the above URL to get the file.'
			dojo.attr(self.btnCopyResponse, 'style', 'display:none');
		} else {
			var handle = dojo.subscribe("/apstrata/client", function(message) {
				if (message.type == 'request') {
					self.dvCall.innerHTML = message.url
					self.urlClipboard.setText(message.url);
										
					if (self.callAttrs.useHttpMethod == "POST") {
						var params = dojo.clone(self.callAttrs.request)
						delete params["apsws.redirectHref"]
						delete params["apsws.callback"]
						if (Object.keys(params).length != 0) {
							params = dojo.trim(dojo.toJson(params, true));
							self.dvCallParams.innerHTML = dojox.highlight.processString(params).result; 
							dojo.style(self.dvCallParamsContainer, 'display', 'block');
						}
					} else {
						dojo.style(self.dvCallParamsContainer, 'display', 'none');
					}
				}
			});
			
			var options = {method: self.callAttrs.useHttpMethod, timeout: self.timeout};
			
			var callResult = client.call(
				self.callAttrs.action, 
				self.callAttrs.request, 
				self.callAttrs.formNode, 
				options).then(
					function(response) {
						console.debug(response);
						dojo.unsubscribe(handle);
						dojo.addClass(self.dvResult, "success");
						dojo.addClass(self.dvResultContainer, "success");
						var rawResponse = dojo.trim(dojo.toJson(response, true));
						self.dvResult.innerHTML = dojox.highlight.processString(rawResponse).result; 
						self.contentClipboard.setText(rawResponse);
					},
					function(response) {
						console.debug(response);
						dojo.unsubscribe(handle);
						dojo.addClass(self.dvResult, "failure");
						dojo.addClass(self.dvResultContainer, "failure");
						var rawResponse = dojo.trim(dojo.toJson(response, true));
						self.dvResult.innerHTML = dojox.highlight.processString(rawResponse).result; 
						self.contentClipboard.setText(rawResponse);
					}					
				)
		}
		
		this.inherited(arguments)		
	},
	
	resize: function() {
		if (this.contentGlued == false)
			this.contentClipboard.glue(this.btnCopyResponse.domNode, this.dvContent);
		
		if (this.urlGlued == false){
			this.urlClipboard.glue(this.btnCopyUrl.domNode, this.dvContent);
			
		}
	},
})


dojo.provide("apstrata.workbench.apiExplorer.CodeViewerPanel")

dojo.require("dojox.dtl._Templated")
dojo.require("dojox.highlight");
dojo.require("dojox.highlight.languages.pygments._www");
dojo.require("dojox.highlight.languages.java");

/**
 * Provides a code viewer panel to show sample code of an Apstrata call
 * 
 * @param {Object} attrs
 */
dojo.declare("apstrata.workbench.apiExplorer.CodeViewerPanel", 
[apstrata.horizon.Panel], 
{
	constructor: function(attrs) {
		attrs.parent = this
		this.viewer = new apstrata.workbench.apiExplorer.CodeViewerWidget(attrs)
	},
	
	onAnimationEnd: function() {
		this.resize()
	},

	resize: function() {
		var c = dojo.contentBox(this.domNode)
		dojo.style(this.viewer.domNode, {height: (c.h-15)+"px"})
		this.viewer.resize()
	},

	/**
	 * Provides rendering of code viewer
	 * @function
	 */
	postCreate: function(){
		dojo.addClass(this.domNode, "CodeViewerPanel")
		dojo.place(this.viewer.domNode, this.dvContent)

		this.inherited(arguments)		
	}
})

dojo.provide("apstrata.workbench.apiExplorer.CodeViewerWidget")

dojo.require("apstrata.workbench.apiExplorer.CodeRunnerPanel")

dojo.declare("apstrata.workbench.apiExplorer.CodeViewerWidget", 
[dijit._Widget, dojox.dtl._Templated],
{
	widgetsInTemplate: true,
	templatePath: dojo.moduleUrl("apstrata.workbench.apiExplorer", "templates/CodeViewerWidget.html"),
	glued : false,
	
	constructor: function(attrs) {
		dojo.mixin(this, attrs)
		this.action = attrs.callAttrs.action			
	},
	
	postCreate: function() {
		var self = this	

		// The parameters to pass to xhrGet, the url, how to handle it, and the callbacks. 591 31 30
		var xhrArgs = {
			url: self.callAttrs.codeTemplatePath.uri, //"workbench/codeTemplates/javaScript.txt",
			handleAs: "text",
			timeout: 5000
		}
		
		dojo.when(
			dojo.xhrGet(xhrArgs),
			function(js) {				
				
				var tokens = {
					key: self.credentials.key,
					secret: self.credentials.secret,
					loginType: self.loginType,
					attr: dojo.toJson(self.callAttrs, true)
				}
				
				if (self.callAttrs.codeTemplatePath.path.indexOf("android") >= 0) {
					js = self._parseAndroidRequest(tokens, js);	
				}else {
					for (t in tokens) {
						var s = js.split("$"+t)
						if (s.length>1) {
							js = s[0] + tokens[t] + s[1]
						}
					}
				}
				
				delete self.callAttrs.codeTemplatePath;				
				self.dvCode.innerHTML = dojox.highlight.processString(js).result
				zeroClipboard.setText(js)
			},
			function () {
				
			}
		)
		this.inherited(arguments)		
		
	},	
	
	run: function() {
		var self = this
		
		this.parent.openPanel(apstrata.workbench.apiExplorer.CodeRunnerPanel, {
			credentials: self.credentials,
			callAttrs: self.callAttrs
		})
	},	
	
	resize: function() {
		var h, c, f
		
		h = dojo.marginBox(this.dvHeader).h
		c = dojo.contentBox(this.domNode).h
		f = dojo.marginBox(this.dvFooter).h
		
		dojo.style(this.dvCodeWindow, {height: (c-h-f) + "px"})
		dojo.style(this.dvCodeWindow, {visibility: "visible"})
		if (this.glued == false) {
			zeroClipboard.glue(this.btnCopy.domNode, this.dvFooter);			
			this.glued = true;
		}
	},
	
	_parseAndroidRequest: function(tokens, script) {
		
		var self = this;
		var api = "";		
		for (t in tokens) {
			var s = script.split("$"+t);
			if (s.length>1) {
				if (t != "attr") {
					script = s[0] + "\"" + tokens[t] + "\"" + s[1];
				}else {
					var str = "\n";
					var keyValuePairs = tokens[t].split(",");
					for (var i = 0; i < keyValuePairs.length; i++) {
						var keyValue = keyValuePairs[i].split(":");
						var name = keyValue[0].replace("{", "").replace("}", "").trim();											
						if(name.indexOf("codeTemplate") >= 0)
							break;
							 
						var value = keyValue[1].replace("{", "").replace("}", "").trim();
						if (name.indexOf("request") >= 0) {
							name = value;
							value = keyValue[2];
						}
						
						if (name.indexOf("action") > 0) {
							api = value;
						}else {
							str = str + "parameters.add(new BasicNameValuePair(" + name + "," + value + "));" + "\n";
							script = s[0] + str + s[1];		
						}				
					}									
				}				
			}
		}
		
		script = script.replace("$api", api);
		script = script.replace("$url", "\"" + this.container.connection.serviceURL + "\"");
		return script;
	}
})
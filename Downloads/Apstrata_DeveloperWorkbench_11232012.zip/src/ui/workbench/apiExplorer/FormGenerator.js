dojo.provide("apstrata.workbench.apiExplorer.FormGenerator")

dojo.require("dojox.dtl._Templated")
dojo.require("dijit.form.Form");
dojo.require("dijit.form.Button");
dojo.require("dijit.form.ValidationTextBox");
dojo.require("dojox.form.Uploader");
dojo.require("dojox.form.FileInput");
dojo.require("dojox.form.uploader.FileList");

dojo.require("apstrata.workbench.apiExplorer.CodeViewerPanel");
dojo.require("apstrata.workbench.apiExplorer.DocViewerPanel");


dojo.declare("apstrata.workbench.apiExplorer.FormGenerator", 
[dijit._Widget, dojox.dtl._Templated], 
{
	templatePath: dojo.moduleUrl("apstrata.workbench.apiExplorer", "templates/FormGenerator.html"),
		
	constructor: function(attrs) {
		dojo.mixin(this, attrs)
		this._attachments = 0	
		this._attachedFilesNames = [];
	},

	postCreate: function() {
		var self = this
		this._form = new dijit.form.Form()
		this._form.set("encType", "multipart/form-data")
		dojo.place(this._form.domNode, this.dvForm)

		if (this.formDef.order) {
			for (var i=0; i<this.formDef.order.length; i++) {
				this.addField(this.formDef.order[i], this.formDef.form[this.formDef.order[i]])
			}
		} else {
			for (fieldName in (this.formDef.form)) {
				this.addField(fieldName, this.formDef.form[fieldName])
			}
		}
		
		this.inherited(arguments)
	},
	
	mvf: [],
	
	addField: function(name, definition) {		
		var dvField = dojo.create("div")
		dojo.addClass(dvField, "field")
		dojo.place(dvField, this._form.domNode)
		
			var label = dojo.create("div", {innerHTML: name})
				dojo.addClass(label, "attributeLabel")
				dojo.place(label, dvField)
			
				if (name.substring(0,1) == "*" && definition.type != "file") {
					var field = new apstrata.workbench.apiExplorer.MutliValueField({name: name, definition: definition})
					this.mvf.push(field)
				} else if (definition.type == "editor") {
					var field = new dijit.form.SimpleTextarea()
					dojo.addClass(field, "attributeValue")
					field.set("name", name.replace(".", "!", "g"))
					
					dojo.style(this.parent.domNode, "width", "540px");
					var c = dojo.contentBox(this.parent.domNode)
					dojo.style(field.domNode, {height: (c.h-475)+"px", width: (c.w-50)+"px"})
					
					
				}else if (definition.type == "file") {
					self = this;
					
					var attachMany = name.substring(0,1) == "*" ? true : false;
					
					// We need to wait for the panel animation to end before we place the upload elements 
					dojo.connect(self.parent, "onAnimationEnd", function(){
						self._addAttachmentNodes(self, dvField, attachMany, name);								
					});		
					
					var att = true;
					
				} else {
					var attr = {}
					if (definition.type == "password") {
						attr.type = "password"
					}
					var field = new dijit.form.ValidationTextBox(attr)
					dojo.addClass(field, "attributeValue")
					field.set("name", name.replace(".", "!", "g"))					
				}
				if (!att)
					dojo.place(field.domNode, dvField)
	},
	
	/*
	 * Add FileInput field and corresponding logic to the form
	 * in order to provide the ability to upload a file
	 * @param self: the formGenerator instance
	 * @param dvField: the node to which the fields will be linked
	 * @param attachMany: if true, will allow to upload multiple files and to enter a specific name for each file
	 * @param name: the name used in the dictionary to define the file upload field. 
	 * If name is defined and attachMany is false, it is used as the name of the file (not shown).
	 */
	_addAttachmentNodes: function(self, dvField, attachMany, name) {
				
		// Create a FileInput instance that will handle the upload of a file
		var newAttachment = new dojox.form.FileInput();		
		dojo.connect(newAttachment.fileInput, "onchange", function() {			
				newAttachment.inputNode.value = newAttachment.fileInput.value;
				newAttachment.cancelNode.style.visibility = 'visible';			
		});
		
		if (attachMany){
			
			// Create an input field for the name of the file field. 
			var newFileName = new dijit.form.ValidationTextBox( {
				inputFileField: newAttachment,
				onChange: function() {					
						this.inputFileField.fileInput.name = this.value;					
				}			
			});				
			
			newFileName.inputFileField.fileInput.name = "apsdb_attachments";
			newFileName.set("value", "apsdb_attachments");
			
			dojo.addClass(newFileName, "attributeValue");
			dojo.place(newFileName.domNode, dvField);
		}else {
			newAttachment.fileInput.name = name ? name : "apsdb_attachments";
		}
		
		self._attachments++;		
				
		dojo.place(newAttachment.domNode, dvField)
		
		if (attachMany) {
			// Create a '+' button to allow adding more FileInput instances and file names
			var addAttachmentButton = new dijit.form.Button({
	            label: "+",
	            style: "float:left;width:40px",
	            onClick: function(){
	                self._addAttachmentNodes(self, dvField, true);
	            }
	        });		
			
			dojo.place(addAttachmentButton.domNode, dvField);		
			
			var addAttachmentButtonPos = dojo.position(addAttachmentButton.domNode, true);
							
			// Create a '-' button to allow removing FileInput instances and file names
			var removeAttachmentButton = new dijit.form.Button({
	            label: "-",
	            style: "float:left;width:40px",
	            onClick: function(){
					if (self._attachments > 1) { 
		                var nodesToRemove = this.get("nodesToRemove");
		                dojo.forEach(nodesToRemove, function(node) {
		                	dojo.destroy(node);	                	
		                });
		                self._attachments--;
					}
	            }
	        });		
			
			dojo.place(removeAttachmentButton.domNode, dvField);		
			
			// Create a dummy div node with a style that will stop the floating positioning of the '+' and '-' buttons
			var divNode = dojo.create("div");
			dojo.style(divNode, "clear", "both");
			dojo.place(divNode, dvField);
			
			// when a user clicks on the '-' button, we need to remove all the nodes that were added 
			// i.e. the InputField, the '+' and '-' buttons and the dummy div
			var nodesToRemove = [newAttachment.domNode, addAttachmentButton.domNode, removeAttachmentButton.domNode, divNode, newFileName.domNode]
			removeAttachmentButton.set("nodesToRemove", nodesToRemove);
		}	
		
		self.parent.resize();
		
	},
		
	get: function() {
		var v = this._form.get("value")

		var value = {}
		
		for (key in v) {
			// remove undefined or empty values
			if (v[key] && (key != '*' && (key != 'uploadFile'))) {
				if (v[key]!="") {
					/*
					 * For some reason, replace as written below only replaces the first occurence on chrome
					 */
					//var k = key.replace("!", ".", "g")
					var k = key.split('!').join('.')
					value[k] = v[key]	
				}
			}
		}
		
		return value
	}
})

dojo.declare("apstrata.workbench.apiExplorer.MutliValueField", 
[dijit._Widget, dijit._Templated], 
{
	widgetsInTemplate: true,
	templatePath:  dojo.moduleUrl("apstrata.workbench.apiExplorer", "templates/MultiValueField.html"),
	
	rows: [],
	
	constructor: function(attrs) {
		
		if (attrs.name.substring(0,2) == "*.") 
			this._name = attrs.name.split("*.")[1];
		else if (attrs.name.substring(0,1) == "*") 
			this._name = ""
			
			
		// Replacing "." with "!" because dijit.form.Form.get("value") expands field names such as "object.attribute" into object = {attribute: [value]}	
		this._name = this._name.replace(".", "!", "g")

		this.definition = attrs.definition
	},
	
	postCreate: function(attrs) {
		//this.createRow(false)
		
		this.inherited(arguments)
	},

	createRow: function(animation) {
		var self = this
		var mvf = new apstrata.workbench.apiExplorer.MutliValueFieldRow({name: self._name, animation: animation})
		if (self.definition.fixedKeyValue) {
			mvf.fldName.set("value", self.definition.fixedKeyValue);
			mvf.fldName.disabled = true;
		}
		this.rows.push(mvf)
		dojo.place(mvf.domNode, this.dvRows, "last")
	},
	
	_add: function() {
		this.createRow(true)
	}
})


dojo.declare("apstrata.workbench.apiExplorer.MutliValueFieldRow", 
[dijit._Widget, dijit._Templated], 
{
	widgetsInTemplate: true,
	templatePath:  dojo.moduleUrl("apstrata.workbench.apiExplorer", "templates/MultiValueFieldRow.html"),
	
	constructor: function(attrs) {
		dojo.mixin(this, attrs)
	},
	
	postCreate: function(attrs) {
		if (this.animation) {
			console.debug('no animation')
			dojo.style(this.domNode, "opacity", "0")
			dojo.animateProperty({
				node: this.domNode, 
				duration: 500,
				properties: {
					opacity: 1			
				}
			}).play()
		}
		this.inherited(arguments)
	},
	
	_remove: function() {
		var self = this
		dojo.animateProperty({
			node: this.domNode, 
			duration: 500,
			properties: {
				opacity: 0
			},
			onEnd: function() {
				self.destroyRecursive()
			}
		}).play()
	},
	
	_change: function() {
		var s = this.fldName.get("value")
		s = s.split('.').join('!')
		
		var suffix = ""
		if (this.name != "") suffix = "!"+this.name
		this.fldValue.set("name", s + suffix)
	}
})



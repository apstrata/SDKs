//
//  BuyTicketParser.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/2/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "BuyTicketParser.h"

@interface BuyTicketParser()

@property(nonatomic, strong) NSString *fname;

@end

@implementation BuyTicketParser

@synthesize fname;
@synthesize requestId=_requestId;
@synthesize status=_status;

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    if ([elementName isEqualToString:@"requestId"]){
        _requestId=@"";
        fname=@"requestId";
    }
    if ([elementName isEqualToString:@"status"]){
        _status=@"";
        fname=@"status";
    }
}

-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    NSLog(@"Found Characters: %@",string);
    if ([self.fname isEqualToString:@"requestId"]){
        _requestId=[_requestId stringByAppendingString:string];
    }
    if ([self.fname isEqualToString:@"status"]){
        _status=[_status stringByAppendingString:string];
    }
}

-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    fname=@" ";
}

-(id)initWithData:(NSData *)data{
    self=[super initWithData:data];
    if (self){
        self.delegate=self;
        _requestId=nil;
        _status=nil;
        [self parse];
    }
    return self;
}
@end

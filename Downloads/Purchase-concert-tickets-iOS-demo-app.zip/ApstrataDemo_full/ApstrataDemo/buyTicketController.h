//
//  buyTicketController.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 10/29/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ConcertViewController.h"

@interface buyTicketController : ConcertViewController<UITextFieldDelegate>

@property (retain, nonatomic) IBOutlet UILabel *concertTitle;
@property (retain, nonatomic) IBOutlet UIImageView *image;
@property (retain, nonatomic) IBOutlet UITextField *ticketsToBuy;


- (IBAction)buyTickets:(id)sender;

@end

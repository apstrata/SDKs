//
//  ConcertPickerController.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/2/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "ConcertPickerController.h"
#import "ApstrataFacade.h"
#import "ConcertViewController.h"

@interface ConcertPickerController ()
@property(nonatomic, strong) NSArray *_concerts;
@end

@implementation ConcertPickerController
@synthesize _concerts;
@synthesize concerts;
- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    ApstrataFacade *facade=[[ApstrataFacade alloc] init];
    self._concerts=[facade concerts];


    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self._concerts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"concert";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    UILabel *label=(UILabel *)[cell viewWithTag:1];
    Concert *c=[_concerts objectAtIndex:indexPath.row];
    label.text=c.title;
    UIImageView *v=(UIImageView *) [cell viewWithTag:2];
    v.image=c.picture;
    return cell;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    ConcertViewController *des=(ConcertViewController *) segue.destinationViewController;
    UITableViewCell *cell=(UITableViewCell *) sender;
    NSIndexPath *p=[self.concerts indexPathForCell:cell];
    Concert *c=[self._concerts objectAtIndex:p.row];
    des.concert=c;
}

- (void)dealloc {
    [_concerts release];
    [super dealloc];
}
@end

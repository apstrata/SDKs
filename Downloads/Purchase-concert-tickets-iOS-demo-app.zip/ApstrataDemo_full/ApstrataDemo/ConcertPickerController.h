//
//  ConcertPickerController.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/2/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConcertPickerController : UITableViewController
@property (retain, nonatomic) IBOutlet UITableView *concerts;

@end

//
//  buyTicketController.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 10/29/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "buyTicketController.h"
#import "ApstrataFacade.h"
#import "AuthorizeTweetController.h"

@interface buyTicketController ()
@end

@implementation buyTicketController

@synthesize concertTitle;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.concertTitle.text=self.concert.title;
    self.image.image=self.concert.picture;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [self.concertTitle release];
    [_ticketsToBuy release];
    [_image release];
    [super dealloc];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return FALSE;
}
- (IBAction)buyTickets:(id)sender {
    ApstrataFacade *facade=[[ApstrataFacade alloc] init];
    NSString *requestId=[facade buyTicket:[self.ticketsToBuy.text intValue] forConcert:self.concert];
    if (requestId!=nil){
        NSUserDefaults* defaults=[NSUserDefaults standardUserDefaults];
        BOOL activated=[defaults boolForKey:@"activated"];
        if (!activated){
            AuthorizeTweetController *c=[self.storyboard instantiateViewControllerWithIdentifier:@"authorizeTweet"];
            [self presentViewController:c animated:TRUE completion:nil];
            [c setURL:[facade authorizationURL]];
            [defaults setBool:YES forKey:@"activated"];
            [defaults synchronize];
        }
        else
            [facade Tweet:@"Yupiii"];
    }
    else{
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Error"
                                                      message:@"!Error"
                                                     delegate:nil
                                            cancelButtonTitle:@"Close"
                                            otherButtonTitles:nil];
        [alert show];
    }

}

@end

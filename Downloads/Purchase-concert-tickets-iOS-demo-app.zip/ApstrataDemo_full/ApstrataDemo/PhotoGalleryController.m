//
//  PhotoGalleryController.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/24/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "PhotoGalleryController.h"
#import "PickImage.h"
#import "ApstrataFacade.h"

@interface PhotoGalleryController ()
@property(nonatomic, strong) NSArray *photos;
@end

@implementation PhotoGalleryController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

-(void)setConcert:(Concert *)concert{
    [super setConcert:concert];
    ApstrataFacade *facade=[[ApstrataFacade alloc] init];
    self.photos=[facade photoGalery:concert];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    PickImage *des=(PickImage *) segue.destinationViewController;
    des.concert=self.concert;

}

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.photos.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"picture"];
    if (cell==0){
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"picture"];
    }
    cell.imageView.image=[self.photos objectAtIndex:indexPath.row];
    return cell;
}

@end

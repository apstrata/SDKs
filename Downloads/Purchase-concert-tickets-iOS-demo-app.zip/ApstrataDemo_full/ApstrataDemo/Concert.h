//
//  Concert.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 10/25/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Concert : NSObject
@property(nonatomic,strong) NSString *key;
@property(nonatomic,strong) NSString *title;
@property float price;
@property(nonatomic,strong) UIImage *picture;
@property(nonatomic,strong) NSString *description;
@property(nonatomic,strong) NSDate *date;
@end

//
//  PhotoGalleryController.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/24/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "ConcertViewController.h"

@interface PhotoGalleryController : ConcertViewController<UITableViewDataSource>

@end

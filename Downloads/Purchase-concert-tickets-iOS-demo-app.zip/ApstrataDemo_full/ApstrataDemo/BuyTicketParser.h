//
//  BuyTicketParser.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/2/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BuyTicketParser : NSXMLParser<NSXMLParserDelegate>
@property(nonatomic, strong,readonly) NSString *requestId;
@property(nonatomic, strong,readonly) NSString *status;

-(id)initWithData:(NSData *)data;
@end

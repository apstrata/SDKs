//
//  ConcertListViewController.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 10/25/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "ConcertListViewController.h"
#include "Concert.h"
#import "ApstrataFacade.h"
#import "buyTicketController.h"

@interface ConcertListViewController ()
@property(nonatomic, strong) NSArray *_concerts;
@end

@implementation ConcertListViewController
@synthesize _concerts;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    ApstrataFacade *facade=[[ApstrataFacade alloc] init];
    self._concerts=[facade concerts];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _concerts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"concertCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    UILabel *label=(UILabel *)[cell viewWithTag:1];
    // Configure the cell...
    Concert *c=[_concerts objectAtIndex:indexPath.row];
    label.text=c.title;
    label=(UILabel*)[cell viewWithTag:2];
    label.text=c.description;
    label=(UILabel*)[cell viewWithTag:3];
    label.text=[NSString stringWithFormat:@"%.0f LBP",c.price];
    NSDateFormatter *df=[[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd"];
    label=(UILabel *)[cell viewWithTag:4];
    label.text=[df stringFromDate:c.date];
    NSLog(@"Date=%@    %@",c.date,label.text);
    UIImageView *v=(UIImageView *)[cell viewWithTag:5];
    v.image=c.picture;
    return cell;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"buyTicket"]){
        buyTicketController *des=(buyTicketController *)segue.destinationViewController;
        UITableView *tv=(UITableView *) self.view;
        UITableViewCell *cell=(UITableViewCell*) sender;
        des.concert=[_concerts objectAtIndex:[tv indexPathForCell:cell].row];
    }
}



@end

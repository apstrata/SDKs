//
//  ConcertListViewController.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 10/25/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConcertListViewController : UITableViewController

@end

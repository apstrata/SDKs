//
//  ApstrataFacade.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 10/25/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "apstrata.h"
#import "Concert.h"

@interface ApstrataFacade : NSObject

@property(nonatomic,strong) ApstrataiPhoneClient *client;

-(id)init;
-(NSArray *)concerts;
-(NSString *) buyTicket:(int)n forConcert:(Concert *)c;
-(bool) uploadImage:(UIImage *)image  called:(NSString*)name forConcert:(Concert *)c;
-(NSArray *)photoGalery:(Concert *) c;
-(NSString*) authorizationURL;
-(bool) Tweet:(NSString *)s;
@end

//
//  ApstrataConcertListParser.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/1/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "apstrata.h"

@interface ApstrataConcertListParser : NSXMLParser<NSXMLParserDelegate>

-(id)initWithData:(NSData *)data fromClient:(ApstrataiPhoneClient *)client;
-(NSArray*) getConcerts;
@end

//
//  Concert.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 10/25/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "Concert.h"

@implementation Concert

@synthesize key;
@synthesize title;
@synthesize price;
@synthesize picture;
@synthesize description;
@synthesize date;

@end

//
//  PhotoGalleryParser.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/24/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PhotoGalleryParser : NSXMLParser<NSXMLParserDelegate>

-(NSArray *) pictures;
-(NSArray *)documentKey;
@end

//
//  AuthorizeTweetController.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 1/9/13.
//  Copyright (c) 2013 Dani Mezher. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AuthorizeTweetController : UIViewController
@property (retain, nonatomic) IBOutlet UIWebView *webView;
- (IBAction)close:(id)sender;
-(void) setURL:(NSString *)url;
@end

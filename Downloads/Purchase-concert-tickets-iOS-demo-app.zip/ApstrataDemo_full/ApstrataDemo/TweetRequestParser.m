//
//  TweetRequestParser.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 1/6/13.
//  Copyright (c) 2013 Dani Mezher. All rights reserved.
//

#import "TweetRequestParser.h"

@interface TweetRequestParser()
@property(nonatomic,strong) NSString* key;
@property(nonatomic,strong) NSString* secret;
@property(nonatomic,strong) NSString* authorizationUrl;
@property(nonatomic,strong) NSMutableString *result;
@end

@implementation TweetRequestParser

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    if ([elementName isEqualToString:@"result"])
        self.result=[[NSMutableString alloc] init];
}

-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    if (self.result!=nil)
        [self.result appendString:string];
}

-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    if (self.result!=nil){
        NSError *error;
        NSLog(@"Data=%@",self.result);
        NSMutableDictionary *obj=(NSMutableDictionary *)[NSJSONSerialization
                                                         JSONObjectWithData:[self.result dataUsingEncoding:NSUTF8StringEncoding]
                                        options:NSJSONReadingMutableContainers
                                          error:&error];
        obj=[obj objectForKey:@"authorizationAndSecret"];
        self.secret=[obj objectForKey:@"requestSecret"];
        self.key=[obj objectForKey:@"requestToken"];
        self.authorizationUrl=[obj objectForKey:@"authorizationUrl"];
        self.result=nil;
    }
}

-(id)initWithData:(NSData *)data{
    self=[super initWithData:data];
    if (self){
        self.delegate=self;
        self.secret=nil;
        self.key=nil;
        self.result=nil;
        [self parse];
    }
    return self;
}

-(NSString*) getToken{
    return self.key;
}
-(NSString*) getSecret{
    return self.secret;
}
-(NSString*) getAuthorizationUrl{
    return self.authorizationUrl;
}
@end

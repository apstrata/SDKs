//
//  ConcertViewController.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/24/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "ConcertViewController.h"

@interface ConcertViewController ()

@end

@implementation ConcertViewController

@synthesize concert=_concert;

-(id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void) setConcert:(Concert *)concert{
    _concert=concert;
    self.navigationItem.title=[concert title];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                           style:UIBarButtonItemStyleDone
                                                                          target:self
                                                                          action:@selector(dismiss)];
}

-(void)dismiss{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

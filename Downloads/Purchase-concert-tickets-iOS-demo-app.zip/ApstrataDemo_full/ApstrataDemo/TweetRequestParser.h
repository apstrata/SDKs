//
//  TweetRequestParser.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 1/6/13.
//  Copyright (c) 2013 Dani Mezher. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TweetRequestParser : NSXMLParser<NSXMLParserDelegate>
-(NSString*) getToken;
-(NSString*) getSecret;
-(NSString*) getAuthorizationUrl;
@end

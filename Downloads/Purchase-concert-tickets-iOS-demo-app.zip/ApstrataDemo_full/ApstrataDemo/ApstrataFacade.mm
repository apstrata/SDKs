//
//  ApstrataFacade.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 10/25/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "ApstrataFacade.h"
#import "Concert.h"
#import "ApstrataConcertListParser.h"
#import "BuyTicketParser.h"
#import "PhotoGalleryParser.h"
#import "TweetRequestParser.h"

@interface ApstrataFacade()

@end


@implementation ApstrataFacade

@synthesize client;

-(id) init{
    self=[super init];
    if (self){
        NSString *url = @"https://sandbox.apstrata.com/apsdb/rest";
        NSString *authKey = @"EFE51D5160";
        NSString *secret = @"RA28C7EE1E6BA038570FDB48A867A99B";
        client = [[ApstrataiPhoneClient alloc] initWithURL:url key:authKey secret:secret authMode: SIMPLE];
    }
    return self;
}


-(NSArray *)concerts{
    NSDictionary *params=[NSDictionary dictionaryWithObjectsAndKeys:@"apsdb.schema=\"concert\"",@"apsdb.query",
                          @"title,ticketPriceLL,picture,description,date,apsdb.documentKey",@"apsdb.queryFields",nil];
    NSString *ret=[client callAPIMethod:@"Query" parameters:params files:nil];
    ApstrataConcertListParser *l=[[ApstrataConcertListParser alloc] initWithData:[ret dataUsingEncoding:NSUTF8StringEncoding] fromClient:client];
    return [l getConcerts];
}


-(NSString *) buyTicket:(int)n forConcert:(Concert *)c{
    NSDictionary *params=[NSDictionary dictionaryWithObjectsAndKeys:
                          @"app.buyTickets",@"apsdb.scriptName",
                          [NSString stringWithFormat:@"%d",n],@"quantity",
                          c.title,@"concertTitle",
                          [NSString stringWithFormat:@"%.0f",c.price],@"unitPrice",
                          @"My name",@"name",
                          @"70010030",@"msisdn",
                          nil];
    NSString* buyTicketResponse=[client callAPIMethod:@"RunScript" parameters:params files:nil];
    NSLog(@"BuyTicketResponse=%@",buyTicketResponse);
    BuyTicketParser *parser=[[BuyTicketParser alloc] initWithData:[buyTicketResponse dataUsingEncoding:NSUTF8StringEncoding]];
    return parser.requestId;
}

-(bool) uploadImage:(UIImage *) image called:(NSString*) name forConcert:(Concert *)c{
    
    NSDictionary *params=[NSDictionary dictionaryWithObjectsAndKeys:
                          @"concert_image",@"apsdb.schema",
                          c.key, @"concert",
                          name,@"title",
                          @"My view point",@"description",
                          @"Put my tags here",@"tags",nil];
    NamedFileData* namedFileDataImg = [[NamedFileData alloc] init];
    [namedFileDataImg setFileData:[NSData dataWithData: UIImagePNGRepresentation(image)]];
    [namedFileDataImg setFileName:name];
                          // Create an array of NamedFileInstances that will contain the files to upload
    NSDictionary *files=[NSDictionary dictionaryWithObject:[NSMutableArray arrayWithObject:namedFileDataImg]
                                                    forKey:@"picture"];
                          // Call the SaveDocument API through the iOS SDK
    NSString *result=[client callAPIMethod:@"SaveDocument" parameters:params files:files];
    NSLog(@"Result=%@",result);
    return true;
}

-(NSArray *)photoGalery:(Concert *) c{
    NSDictionary *params=[NSDictionary dictionaryWithObjectsAndKeys:
                          [NSString stringWithFormat:@"concert=\"%@\"",c.key],@"apsdb.query",
                          @"picture",@"apsdb.queryFields", nil];
    NSString *result=[client callAPIMethod:@"Query" parameters:params files:nil];
    PhotoGalleryParser *parser=[[PhotoGalleryParser alloc] initWithData:[result dataUsingEncoding:NSUTF8StringEncoding]];
    if ([parser parse]){
        NSArray *names=[parser pictures];
        NSArray *keys=[parser documentKey];
        NSMutableArray *pictures=[[NSMutableArray alloc] initWithCapacity:names.count];
        NSString *fileName;
        for(int i=0;i<names.count;++i){
            fileName=[(NSString *)[names objectAtIndex:i] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
            [parameters setObject:[keys objectAtIndex:i]
                           forKey: @"apsdb.documentKey"];
            [parameters setObject:[fileName
              stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]
                           forKey: @"apsdb.fileName"];
            [parameters setObject: @"picture" forKey: @"apsdb.fieldName"];
            NSData *data=[client callAPIFile:@"GetFile" params:parameters path:nil];
            [pictures addObject:[UIImage imageWithData:data]];
        }
        return pictures;
    }
    return nil;
}
-(NSString*) authorizationURL{
    NSString *response=
    [client callAPIMethod:@"RunScript"
               parameters:[NSDictionary dictionaryWithObjectsAndKeys:
                           @"social.twitter.integrate",@"apsdb.scriptName"
                           ,@"getRequestToken",@"command"
                           ,@"70010030",@"requester", nil]
                    files:nil];
    TweetRequestParser *parser=[[TweetRequestParser alloc] initWithData:[response dataUsingEncoding:NSUTF8StringEncoding]];
    if ([parser parse]){
        return [parser getAuthorizationUrl];
    }
    return nil;
}

-(bool) Tweet:(NSString *)s{
    NSString *response=[client callAPIJson:@"Query"
                                  params:[NSDictionary dictionaryWithObjectsAndKeys:@"apsdb.documentKey=\"twitter_70010030\"",@"apsdb.query",
                                              @"token_VZSaDoqSgDSzAOQjnnDhw, secret_VZSaDoqSgDSzAOQjnnDhw",@"apsdb.queryFields",nil]
                                       files:nil];
    NSError *error;
    NSMutableDictionary *obj=(NSMutableDictionary *)[NSJSONSerialization
                                                     JSONObjectWithData:[response dataUsingEncoding:NSUTF8StringEncoding]
                                                     options:NSJSONReadingMutableContainers
                                                     error:&error];
    obj=(NSMutableDictionary*) [obj objectForKey:@"response"];
    obj=(NSMutableDictionary*) [obj objectForKey:@"result"];
    NSArray *doc=(NSArray*) [obj objectForKey:@"documents"];
    obj=(NSMutableDictionary*)[doc objectAtIndex:0];
    NSString *token=[obj objectForKey:@"token_VZSaDoqSgDSzAOQjnnDhw"];
    NSString *secret=[obj objectForKey:@"secret_VZSaDoqSgDSzAOQjnnDhw"];
    response=[client callAPIMethod:@"RunScript"
                   parameters:[NSDictionary dictionaryWithObjectsAndKeys:
                               @"social.twitter.api",@"apsdb.scriptName",
                               @"VZSaDoqSgDSzAOQjnnDhw",@"consumerKey",
                               @"nUjEPLTwaAiWjFgC5x6SrilI4yW86Fy6RnI0V3o",@"consumerSecret",
                               token,@"accessToken",
                               secret,@"accessTokenSecret",
                               s,@"tweetString",
                               @"tweet",@"command",nil]
                        files:nil];
        NSLog(@"Response=%@",response);
        return true;
}

@end

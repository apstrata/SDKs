//
//  ConcertViewController.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/24/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Concert.h"

@interface ConcertViewController : UIViewController

@property(nonatomic,assign) Concert* concert;


@end

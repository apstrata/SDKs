//
//  PhotoGalleryParser.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/24/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "PhotoGalleryParser.h"

@interface PhotoGalleryParser()
@property(nonatomic,strong) NSMutableArray *_pictures;
@property(nonatomic,strong) NSMutableString *_data;
@property(nonatomic,strong) NSMutableArray *_keys;
@property(nonatomic,strong) NSString *_documentKey;
@end

@implementation PhotoGalleryParser

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    if ([elementName isEqualToString:@"value"])
        self._data=[[NSMutableString alloc] init];
    if ([elementName isEqualToString:@"document"]){
        self._documentKey=[attributeDict objectForKey:@"key"];
    }
}

-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    [self._data appendString:string];
}

-(void)parser:(NSXMLParser *)parser foundCDATA:(NSData *)CDATABlock{
    [self parser:parser foundCharacters:[[NSString alloc] initWithData:CDATABlock encoding:NSUTF8StringEncoding]];
}

-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    if (self._data){
        [self._pictures addObject:self._data];
        [self._keys addObject:self._documentKey];
        self._data=nil;
    }
}

-(BOOL) parse{
    self._pictures=[[NSMutableArray alloc] init];
    self._keys=[[NSMutableArray alloc] init];
    self._data=nil;
    self._documentKey=nil;
    self.delegate=self;
    return [super parse];
}

-(NSArray*)documentKey{
    return self._keys;
}

-(NSArray *)pictures{
    return [NSArray arrayWithArray:self._pictures];
}

@end

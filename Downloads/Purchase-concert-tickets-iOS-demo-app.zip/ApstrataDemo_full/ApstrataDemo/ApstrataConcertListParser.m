//
//  ApstrataConcertListParser.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/1/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "ApstrataConcertListParser.h"
#import "Concert.h"

@interface ApstrataConcertListParser()
@property(nonatomic, strong) Concert *currentConcert;
@property(nonatomic, strong) NSString *fieldName;
@property(nonatomic, strong) NSMutableString *value;
@property(nonatomic, strong) NSMutableArray *_concerts;
@property(nonatomic, assign) ApstrataiPhoneClient *client;

@end

@implementation ApstrataConcertListParser

@synthesize currentConcert;
@synthesize fieldName;
@synthesize value;
@synthesize _concerts;
@synthesize client;

-(id)initWithData:(NSData *)data fromClient:(ApstrataiPhoneClient *)_client{
    self=[super initWithData:data];
    if (self){
        self.client=_client;
        self.delegate=self;
        self.currentConcert=nil;
        self.fieldName=nil;
        self.value=nil;
        self._concerts=[[NSMutableArray alloc] init];
        if (![self parse]){
            _concerts=nil;
        }
    }
    return self;
}

-(NSArray*) getConcerts{
    return [NSArray arrayWithArray:_concerts];
}

#pragma NSXMLParser specific functions

-(void) parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    if ([elementName isEqualToString:@"document"]){
        self.currentConcert=[[Concert alloc] init];
        self.currentConcert.key=(NSString *)[attributeDict objectForKey:@"key"];
    }
    if ([elementName isEqualToString:@"field"]){
        self.fieldName=(NSString *)[attributeDict objectForKey:@"name"];
    }
    if ([elementName isEqualToString:@"value"]){
        self.value=[[NSMutableString alloc] init];
    }
}

-(void) parser:(NSXMLParser *)parser foundCDATA:(NSData *)CDATABlock{
    if (self.value!=nil)
        [self.value appendString:[[NSString alloc] initWithData:CDATABlock encoding:NSUTF8StringEncoding]];
}

-(void) parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    [self parser:parser foundCDATA:[string dataUsingEncoding:NSUTF8StringEncoding]];
}

-(void) parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    if ([elementName isEqualToString:@"document"]){
        [self._concerts addObject:self.currentConcert];
        self.currentConcert=nil;
    }
    if ([elementName isEqualToString:@"value"]){
        if ([self.fieldName isEqualToString:@"title"])
            self.currentConcert.title=self.value;
        if ([self.fieldName isEqualToString:@"ticketPriceLL"])
            self.currentConcert.price=[self.value floatValue];
        if ([self.fieldName isEqualToString:@"description"])
            self.currentConcert.description=self.value;
        if ([self.fieldName isEqualToString:@"date"]){
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            [df setDateFormat:@"yyyy-MM-dd"];
            NSRange range;
            range.location=0;
            range.length=10;
            self.currentConcert.date = [df dateFromString:[self.value substringWithRange:range]];
            NSLog(@"Date=%@, string=%@",self.currentConcert.date,self.value);
        }
        if ([self.fieldName isEqualToString:@"picture"]){
            
            NSLog(@"Requesting picture from server, parameters are:");
            NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
            [parameters setObject:
             [self.currentConcert.key
              stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]
                           forKey: @"apsdb.documentKey"];
            [parameters setObject:
             [self.value
              stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]
                           forKey: @"apsdb.fileName"];
            [parameters setObject: @"picture" forKey: @"apsdb.fieldName"];
            NSData *data=[client callAPIFile:@"GetFile" params:parameters path:nil];
            currentConcert.picture=[UIImage imageWithData:data];
            
            
        }
        self.value=nil;
    }
}


@end

//
//  PickImage.h
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/2/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Concert.h"

@interface PickImage : UIImagePickerController<UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (nonatomic, assign) Concert *concert;
@end

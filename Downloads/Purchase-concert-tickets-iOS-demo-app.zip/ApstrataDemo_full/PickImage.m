//
//  PickImage.m
//  ApstrataDemo
//
//  Created by Dani Mezher on 11/2/12.
//  Copyright (c) 2012 Dani Mezher. All rights reserved.
//

#import "PickImage.h"
#import "ApstrataFacade.h"
#import "MobileCoreServices/MobileCoreServices.h"

@interface PickImage ()

@end

@implementation PickImage

@synthesize concert;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.delegate=self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    if ([(NSString*)[info objectForKey:UIImagePickerControllerMediaType] isEqualToString:(NSString *)kUTTypeImage]){
        UIImage *img=(UIImage *)[info objectForKey:UIImagePickerControllerOriginalImage];
        ApstrataFacade *facade=[[ApstrataFacade alloc] init];
        [facade uploadImage:img called:@"MyImage" forConcert:self.concert];
    }
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}


@end
